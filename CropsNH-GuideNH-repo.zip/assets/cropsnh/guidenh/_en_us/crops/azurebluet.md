---
navigation:
  icon: 'cropsnh:genericSeed{crop:"cropsnh:azureBluet"}'
  title: Azure Bluet
  parent: /crops.md
  position: 18
---

# Azure Bluet

**Tier:** 2  
**Soil:** [Dirt / Grass](/mechanics/soil-and-blocks.md) — Dirt, Grass, Mycelium variants  
**Likes biomes:** HILLS, FOREST, LUSH  
**Alternate seed:** yes — plantable without breeding  
**Pools:** `FLOWER`, `WHITE`  

## Breeding setup

Full breeding setup — a cross-crop stick in the center on Dirt / Grass, with the parents planted in a line through it (**Poppy** (north), **Potato** (south)):

<GameScene zoom={4} interactive={true}>
  <Block id="minecraft:dirt" x="0" y="0" z="0" />
  <Block id="minecraft:dirt" x="0" y="1" z="0" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crossCrop:1b}' x="0" y="2" z="0" />
  <Block id="minecraft:dirt" x="0" y="0" z="-1" />
  <Block id="minecraft:dirt" x="0" y="1" z="-1" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crop:{crop:"cropsnh:poppy",amount:1,gr:1b,ga:1b,re:1b,scan:1b},progress:1000}' x="0" y="2" z="-1" />
  <Block id="minecraft:dirt" x="0" y="0" z="1" />
  <Block id="minecraft:farmland" x="0" y="1" z="1" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crop:{crop:"cropsnh:potato",amount:1,gr:1b,ga:1b,re:1b,scan:1b},progress:1000}' x="0" y="2" z="1" />
  <BlockAnnotation pos="0 2 0" color="#80FFAA00" thickness="2" alwaysOnTop="true">Azure Bluet — cross-crop (result grows here)</BlockAnnotation>
  <BlockAnnotation pos="0 2 -1" color="#8044DD66" thickness="2" alwaysOnTop="true">Poppy (parent)</BlockAnnotation>
  <BlockAnnotation pos="0 2 1" color="#8044DD66" thickness="2" alwaysOnTop="true">Potato (parent)</BlockAnnotation>
</GameScene>

## How to obtain

Bred from:

| Parents | Result pools | Notes |
|---------|--------------|-------|
| [Poppy](/crops/poppy.md) + [Potato](/crops/potato.md) | `FLOWER`, `WHITE` | crop-stick cross |

Exact per-tick chance depends on soil and the parents' shared pools — check the [web calculator](https://crops-nh.netlify.app/calculator.html).

## Used to breed

Azure Bluet is a parent in these mutations:

| Produces | With |
|----------|------|
| [Blueberry](/crops/blueberry.md) | [Bonsai Oak](/crops/bonsaioak.md) |
| [Dayflower](/crops/dayflower.md) | [Blue Orchid](/crops/blueorchid.md) |
| [Flax](/crops/flax.md) | [Wheat](/crops/wheat.md) |
| [Oxeye Daisy](/crops/oxeyedaisy.md) | [Dandelion](/crops/dandelion.md) |
| [Plumbshade](/crops/plumbshade.md) | [Malaxia](/crops/malaxia.md) + [Black Granite Lily](/crops/blackgranitelily.md) |


