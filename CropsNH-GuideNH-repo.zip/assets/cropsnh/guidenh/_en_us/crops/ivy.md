---
navigation:
  icon: 'cropsnh:genericSeed{crop:"cropsnh:ivy"}'
  title: Ivy
  parent: /crops.md
  position: 18
---

# Ivy

**Tier:** 2  
**Soil:** [Farmland](/mechanics/soil-and-blocks.md) — Farmland, Enchanted Earth, Ztones Garden Soil, Fertilized Dirt  
**Likes biomes:** NETHER, JUNGLE, MAGICAL, DENSE  
**Alternate seed:** yes — plantable without breeding  
**Pools:** `CLIMBABLE`, `DANGEROUS`, `FLOWER`, `GREEN`, `POISONOUS`, `TENDRILLY`  

BoP req

## Breeding setup

Full breeding setup — a cross-crop stick in the center on Farmland, with the parents planted in a line through it (**Vine** (north), **Bonsai Spruce** (south)):

<GameScene zoom={4} interactive={true}>
  <Block id="minecraft:dirt" x="0" y="0" z="0" />
  <Block id="minecraft:farmland" x="0" y="1" z="0" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crossCrop:1b}' x="0" y="2" z="0" />
  <Block id="minecraft:dirt" x="0" y="0" z="-1" />
  <Block id="minecraft:farmland" x="0" y="1" z="-1" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crop:{crop:"cropsnh:vine",amount:1,gr:1b,ga:1b,re:1b,scan:1b},progress:1000}' x="0" y="2" z="-1" />
  <Block id="minecraft:dirt" x="0" y="0" z="1" />
  <Block id="minecraft:dirt" x="0" y="1" z="1" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crop:{crop:"cropsnh:bonsaiSpruce",amount:1,gr:1b,ga:1b,re:1b,scan:1b},progress:1000}' x="0" y="2" z="1" />
  <BlockAnnotation pos="0 2 0" color="#80FFAA00" thickness="2" alwaysOnTop="true">Ivy — cross-crop (result grows here)</BlockAnnotation>
  <BlockAnnotation pos="0 2 -1" color="#8044DD66" thickness="2" alwaysOnTop="true">Vine (parent)</BlockAnnotation>
  <BlockAnnotation pos="0 2 1" color="#8044DD66" thickness="2" alwaysOnTop="true">Bonsai Spruce (parent)</BlockAnnotation>
</GameScene>

## How to obtain

Bred from:

| Parents | Result pools | Notes |
|---------|--------------|-------|
| [Vine](/crops/vine.md) + [Bonsai Spruce](/crops/bonsaispruce.md) | `CLIMBABLE`, `DANGEROUS`, `FLOWER`, `GREEN`, `POISONOUS`, `TENDRILLY` | crop-stick cross |

Exact per-tick chance depends on soil and the parents' shared pools — check the [web calculator](https://crops-nh.netlify.app/calculator.html).

## Used to breed

Ivy is a parent in these mutations:

| Produces | With |
|----------|------|
| [Flowering Vine](/crops/floweringvine.md) | [Oxeye Daisy](/crops/oxeyedaisy.md) |
| [Moss](/crops/moss.md) | [Flowering Vine](/crops/floweringvine.md) |


