---
navigation:
  icon: 'cropsnh:genericSeed{crop:"cropsnh:blackGraniteLily"}'
  title: Black Granite Lily
  parent: /crops.md
  position: 19
---

# Black Granite Lily

> [!WARNING]
> **Buried block required.** This crop needs a `blackGranite` block two spaces below the cross-crop stick (directly under the soil). Without it the crop won't grow — see the setup scene below.

**Tier:** 1  
**Soil:** [Stone](/mechanics/soil-and-blocks.md) — Stone, Cobblestone, Stone Brick, Mossy Cobble + Chisel variants  
**Block under soil:** `blackGranite`  
**Likes biomes:** MOUNTAIN, HILLS  
**Alternate seed:** no  
**Pools:** `BLACK`, `DARK`, `STONE`  

## Breeding setup

Full breeding setup — a cross-crop stick in the center on Stone over a **blackGranite** block, with the parents planted in a line through it (**Stone Lily** (north), **Basalt Lily** (south)):

<GameScene zoom={4} interactive={true}>
  <Block id="gregtech:gt.blockgranites" meta="0" x="0" y="0" z="0" />
  <Block id="minecraft:stone" x="0" y="1" z="0" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crossCrop:1b}' x="0" y="2" z="0" />
  <Block id="minecraft:stone" x="0" y="0" z="-1" />
  <Block id="minecraft:stone" x="0" y="1" z="-1" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crop:{crop:"cropsnh:stoneLily",amount:1,gr:1b,ga:1b,re:1b,scan:1b},progress:1000}' x="0" y="2" z="-1" />
  <Block id="gregtech:gt.blockstones" meta="8" x="0" y="0" z="1" />
  <Block id="minecraft:stone" x="0" y="1" z="1" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crop:{crop:"cropsnh:basaltLily",amount:1,gr:1b,ga:1b,re:1b,scan:1b},progress:1000}' x="0" y="2" z="1" />
  <BlockAnnotation pos="0 2 0" color="#80FFAA00" thickness="2" alwaysOnTop="true">Black Granite Lily — cross-crop (result grows here)</BlockAnnotation>
  <BlockAnnotation pos="0 2 -1" color="#8044DD66" thickness="2" alwaysOnTop="true">Stone Lily (parent)</BlockAnnotation>
  <BlockAnnotation pos="0 2 1" color="#8044DD66" thickness="2" alwaysOnTop="true">Basalt Lily (parent)</BlockAnnotation>
</GameScene>

## How to obtain

Bred from:

| Parents | Result pools | Notes |
|---------|--------------|-------|
| [Stone Lily](/crops/stonelily.md) + [Basalt Lily](/crops/basaltlily.md) | `BLACK`, `DARK`, `STONE` | crop-stick cross |

Exact per-tick chance depends on soil and the parents' shared pools — check the [web calculator](https://crops-nh.netlify.app/calculator.html).

## Used to breed

Black Granite Lily is a parent in these mutations:

| Produces | With |
|----------|------|
| [Deepslate Lily](/crops/deepslatelily.md) | [Tuff Lily](/crops/tufflily.md) |
| [Ferrofern](/crops/ferrofern.md) | [Stone Lily](/crops/stonelily.md) |
| [Granite Lily](/crops/granitelily.md) | [Red Granite Lily](/crops/redgranitelily.md) |
| [Plumbshade](/crops/plumbshade.md) | [Azure Bluet](/crops/azurebluet.md) + [Malaxia](/crops/malaxia.md) |
| [Tuff Lily](/crops/tufflily.md) | [Andesite Lily](/crops/andesitelily.md) |
| [Withereed](/crops/withereed.md) | [Basalt Lily](/crops/basaltlily.md) |


