---
navigation:
  icon: 'cropsnh:genericSeed{crop:"cropsnh:godOfThunder"}'
  title: God of Thunder
  parent: /crops.md
  position: 11
---

# God of Thunder

> [!NOTE]
> **Machine-only.** Produced by a machine process, not by breeding on crop sticks.

> [!WARNING]
> **Buried block required.** This crop needs a `thorium` block two spaces below the cross-crop stick (directly under the soil). Without it the crop won't grow — see the setup scene below.

**Tier:** 9  
**Soil:** [Stone](/mechanics/soil-and-blocks.md) — Stone, Cobblestone, Stone Brick, Mossy Cobble + Chisel variants  
**Block under soil:** `thorium`  
**Likes biomes:** WASTELAND, SPARSE  
**Alternate seed:** no  

Crop Synthesizer only. Requires thorium block y-2. Extreme rarity crop.

## Breeding setup

Full breeding setup — a cross-crop stick in the center on Stone over a **thorium** block, with the parents planted in a line through it (**BobsYerUncleRanks** (north), **Withereed** (south)):

<GameScene zoom={4} interactive={true}>
  <Block id="gregtech:gt.blockmetal7" meta="5" x="0" y="0" z="0" />
  <Block id="minecraft:stone" x="0" y="1" z="0" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crossCrop:1b}' x="0" y="2" z="0" />
  <Block id="minecraft:emerald_block" x="0" y="0" z="-1" />
  <Block id="minecraft:stone" x="0" y="1" z="-1" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crop:{crop:"cropsnh:bobsYerUncleRanks",amount:1,gr:1b,ga:1b,re:1b,scan:1b},progress:1000}' x="0" y="2" z="-1" />
  <Block id="minecraft:coal_block" x="0" y="0" z="1" />
  <Block id="minecraft:stone" x="0" y="1" z="1" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crop:{crop:"cropsnh:withereed",amount:1,gr:1b,ga:1b,re:1b,scan:1b},progress:1000}' x="0" y="2" z="1" />
  <BlockAnnotation pos="0 2 0" color="#80FFAA00" thickness="2" alwaysOnTop="true">God of Thunder — cross-crop (result grows here)</BlockAnnotation>
  <BlockAnnotation pos="0 2 -1" color="#8044DD66" thickness="2" alwaysOnTop="true">BobsYerUncleRanks (parent)</BlockAnnotation>
  <BlockAnnotation pos="0 2 1" color="#8044DD66" thickness="2" alwaysOnTop="true">Withereed (parent)</BlockAnnotation>
</GameScene>

## How to obtain

Bred from:

| Parents | Result pools | Notes |
|---------|--------------|-------|
| [BobsYerUncleRanks](/crops/bobsyeruncleranks.md) + [Withereed](/crops/withereed.md) | `STONE` | machine recipe |

Exact per-tick chance depends on soil and the parents' shared pools — check the [web calculator](https://crops-nh.netlify.app/calculator.html).

## Used to breed

God of Thunder is a parent in these mutations:

| Produces | With |
|----------|------|
| [Reactoria](/crops/reactoria.md) | [Titania](/crops/titania.md) |
| [Star Wart](/crops/starwart.md) | [Withereed](/crops/withereed.md) + [Titania](/crops/titania.md) |


