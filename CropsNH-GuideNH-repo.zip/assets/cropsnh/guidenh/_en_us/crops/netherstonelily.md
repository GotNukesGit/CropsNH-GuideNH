---
navigation:
  icon: 'cropsnh:genericSeed{crop:"cropsnh:netherStoneLily"}'
  title: Nether Stone Lily
  parent: /crops.md
  position: 19
---

# Nether Stone Lily

> [!WARNING]
> **Buried block required.** This crop needs a `netherrack` block two spaces below the cross-crop stick (directly under the soil). Without it the crop won't grow — see the setup scene below.

**Tier:** 1  
**Soil:** [Stone](/mechanics/soil-and-blocks.md) — Stone, Cobblestone, Stone Brick, Mossy Cobble + Chisel variants  
**Block under soil:** `netherrack`  
**Likes biomes:** NETHER, HOT, DRY  
**Alternate seed:** no  
**Pools:** `NETHER`, `RED`, `STONE`  

## Breeding setup

Full breeding setup — a cross-crop stick in the center on Stone over a **netherrack** block, with the parents planted in a line through it (**Stone Lily** (north), **Nether Wart** (south)):

<GameScene zoom={4} interactive={true}>
  <Block id="minecraft:netherrack" x="0" y="0" z="0" />
  <Block id="minecraft:stone" x="0" y="1" z="0" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crossCrop:1b}' x="0" y="2" z="0" />
  <Block id="minecraft:stone" x="0" y="0" z="-1" />
  <Block id="minecraft:stone" x="0" y="1" z="-1" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crop:{crop:"cropsnh:stoneLily",amount:1,gr:1b,ga:1b,re:1b,scan:1b},progress:1000}' x="0" y="2" z="-1" />
  <Block id="minecraft:soul_sand" x="0" y="0" z="1" />
  <Block id="minecraft:soul_sand" x="0" y="1" z="1" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crop:{crop:"cropsnh:netherwart",amount:1,gr:1b,ga:1b,re:1b,scan:1b},progress:1000}' x="0" y="2" z="1" />
  <BlockAnnotation pos="0 2 0" color="#80FFAA00" thickness="2" alwaysOnTop="true">Nether Stone Lily — cross-crop (result grows here)</BlockAnnotation>
  <BlockAnnotation pos="0 2 -1" color="#8044DD66" thickness="2" alwaysOnTop="true">Stone Lily (parent)</BlockAnnotation>
  <BlockAnnotation pos="0 2 1" color="#8044DD66" thickness="2" alwaysOnTop="true">Nether Wart (parent)</BlockAnnotation>
</GameScene>

## How to obtain

Bred from:

| Parents | Result pools | Notes |
|---------|--------------|-------|
| [Stone Lily](/crops/stonelily.md) + [Nether Wart](/crops/netherwart.md) | `NETHER`, `RED`, `STONE` | crop-stick cross |

Exact per-tick chance depends on soil and the parents' shared pools — check the [web calculator](https://crops-nh.netlify.app/calculator.html).

## Used to breed

Nether Stone Lily is a parent in these mutations:

| Produces | With |
|----------|------|
| [Ardite Ore Berry](/crops/arditeoreberry.md) | [Coppon](/crops/coppon.md) + [Copper Ore Berry](/crops/copperoreberry.md) + [Malaxia](/crops/malaxia.md) |
| [Cobalt Ore Berry](/crops/cobaltoreberry.md) | [Ardite Ore Berry](/crops/arditeoreberry.md) + [Lazulia](/crops/lazulia.md) + [Gold Ore Berry](/crops/goldoreberry.md) |
| [Coppon](/crops/coppon.md) | [Stone Lily](/crops/stonelily.md) |
| [Creeperweed](/crops/creeperweed.md) | [Withereed](/crops/withereed.md) + [Salty Root](/crops/saltyroot.md) |
| [Evil Ore](/crops/evilore.md) | [Soul Sand Lily](/crops/soulsandlily.md) |
| [Eyebulb](/crops/eyebulb.md) | [Red Tulip](/crops/redtulip.md) |
| [Glowflower](/crops/glowflower.md) | [Dandelion](/crops/dandelion.md) |
| [Red Straw](/crops/redstraw.md) | [Wheat](/crops/wheat.md) |
| [Soul Sand Lily](/crops/soulsandlily.md) | [Sand Lily](/crops/sandlily.md) |
| [Tearstalks](/crops/tearstalks.md) | [Goldfish](/crops/goldfish.md) + [Soul Sand Lily](/crops/soulsandlily.md) |


