---
navigation:
  icon: 'cropsnh:genericSeed{crop:"cropsnh:tuffLily"}'
  title: Tuff Lily
  parent: /crops.md
  position: 19
---

# Tuff Lily

> [!WARNING]
> **Buried block required.** This crop needs a `tuff` block two spaces below the cross-crop stick (directly under the soil). Without it the crop won't grow — see the setup scene below.

**Tier:** 1  
**Soil:** [Stone](/mechanics/soil-and-blocks.md) — Stone, Cobblestone, Stone Brick, Mossy Cobble + Chisel variants  
**Block under soil:** `tuff`  
**Likes biomes:** MOUNTAIN, HILLS  
**Alternate seed:** no  
**Pools:** `DARK`, `GRAY`, `STONE`  

EtFuturum req

## Breeding setup

Full breeding setup — a cross-crop stick in the center on Stone over a **tuff** block, with the parents planted in a line through it (**Black Granite Lily** (north), **Andesite Lily** (south)):

<GameScene zoom={4} interactive={true}>
  <Block id="etfuturum:tuff" x="0" y="0" z="0" />
  <Block id="minecraft:stone" x="0" y="1" z="0" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crossCrop:1b}' x="0" y="2" z="0" />
  <Block id="gregtech:gt.blockgranites" meta="0" x="0" y="0" z="-1" />
  <Block id="minecraft:stone" x="0" y="1" z="-1" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crop:{crop:"cropsnh:blackGraniteLily",amount:1,gr:1b,ga:1b,re:1b,scan:1b},progress:1000}' x="0" y="2" z="-1" />
  <Block id="chisel:andesite" x="0" y="0" z="1" />
  <Block id="minecraft:stone" x="0" y="1" z="1" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crop:{crop:"cropsnh:andesiteLily",amount:1,gr:1b,ga:1b,re:1b,scan:1b},progress:1000}' x="0" y="2" z="1" />
  <BlockAnnotation pos="0 2 0" color="#80FFAA00" thickness="2" alwaysOnTop="true">Tuff Lily — cross-crop (result grows here)</BlockAnnotation>
  <BlockAnnotation pos="0 2 -1" color="#8044DD66" thickness="2" alwaysOnTop="true">Black Granite Lily (parent)</BlockAnnotation>
  <BlockAnnotation pos="0 2 1" color="#8044DD66" thickness="2" alwaysOnTop="true">Andesite Lily (parent)</BlockAnnotation>
</GameScene>

## How to obtain

Bred from:

| Parents | Result pools | Notes |
|---------|--------------|-------|
| [Black Granite Lily](/crops/blackgranitelily.md) + [Andesite Lily](/crops/andesitelily.md) | `DARK`, `GRAY`, `STONE` | crop-stick cross |

Exact per-tick chance depends on soil and the parents' shared pools — check the [web calculator](https://crops-nh.netlify.app/calculator.html).

## Used to breed

Tuff Lily is a parent in these mutations:

| Produces | With |
|----------|------|
| [Deepslate Lily](/crops/deepslatelily.md) | [Black Granite Lily](/crops/blackgranitelily.md) |


