---
navigation:
  icon: 'cropsnh:genericSeed{crop:"cropsnh:thauminiteOreBerry"}'
  title: Thauminite Ore Berry
  parent: /crops.md
  position: 13
---

# Thauminite Ore Berry

> [!WARNING]
> **Buried block required.** This crop needs a `thauminite` block two spaces below the cross-crop stick (directly under the soil). Without it the crop won't grow — see the setup scene below.

**Tier:** 7  
**Soil:** [Stone](/mechanics/soil-and-blocks.md) — Stone, Cobblestone, Stone Brick, Mossy Cobble + Chisel variants  
**Block under soil:** `thauminite`  
**Likes biomes:** MAGICAL, FOREST  
**Alternate seed:** no  
**Pools:** `BLUE`, `DANGEROUS`, `MAGICAL`, `METALLIC`, `ORE_BERRY`, `VOID_TOUCHED`  

TiC+TC+ThaumicBases req

## Breeding setup

Full breeding setup — a cross-crop stick in the center on Stone over a **thauminite** block, with the parents planted in a line through it (**Thaumium Ore Berry** (north), **Mana Bean** (south)):

<GameScene zoom={4} interactive={true}>
  <Block id="thaumicbases:thauminiteBlock" x="0" y="0" z="0" />
  <Block id="minecraft:stone" x="0" y="1" z="0" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crossCrop:1b}' x="0" y="2" z="0" />
  <Block id="gregtech:gt.blockmetal7" meta="4" x="0" y="0" z="-1" />
  <Block id="minecraft:stone" x="0" y="1" z="-1" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crop:{crop:"cropsnh:thaumiumOreBerry",amount:1,gr:1b,ga:1b,re:1b,scan:1b},progress:1000}' x="0" y="2" z="-1" />
  <Block id="Thaumcraft:blockCrystal" meta="6" x="0" y="0" z="1" />
  <Block id="minecraft:log" x="0" y="1" z="1" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crop:{crop:"cropsnh:manaBean",amount:1,gr:1b,ga:1b,re:1b,scan:1b},progress:1000}' x="0" y="2" z="1" />
  <BlockAnnotation pos="0 2 0" color="#80FFAA00" thickness="2" alwaysOnTop="true">Thauminite Ore Berry — cross-crop (result grows here)</BlockAnnotation>
  <BlockAnnotation pos="0 2 -1" color="#8044DD66" thickness="2" alwaysOnTop="true">Thaumium Ore Berry (parent)</BlockAnnotation>
  <BlockAnnotation pos="0 2 1" color="#8044DD66" thickness="2" alwaysOnTop="true">Mana Bean (parent)</BlockAnnotation>
</GameScene>

## How to obtain

Bred from:

| Parents | Result pools | Notes |
|---------|--------------|-------|
| [Thaumium Ore Berry](/crops/thaumiumoreberry.md) + [Mana Bean](/crops/manabean.md) | `BLUE`, `DANGEROUS`, `MAGICAL`, `METALLIC`, `ORE_BERRY`, `VOID_TOUCHED` | crop-stick cross |

Exact per-tick chance depends on soil and the parents' shared pools — check the [web calculator](https://crops-nh.netlify.app/calculator.html).


