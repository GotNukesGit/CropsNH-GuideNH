---
navigation:
  icon: 'cropsnh:genericSeed{crop:"cropsnh:micadia"}'
  title: Micadia
  parent: /crops.md
  position: 11
---

# Micadia

> [!NOTE]
> **Machine-only.** Produced by a machine process, not by breeding on crop sticks.

> [!WARNING]
> **Buried block required.** This crop needs a `mica` block two spaces below the cross-crop stick (directly under the soil). Without it the crop won't grow — see the setup scene below.

**Tier:** 9  
**Soil:** [Stone](/mechanics/soil-and-blocks.md) — Stone, Cobblestone, Stone Brick, Mossy Cobble + Chisel variants  
**Block under soil:** `mica`  
**Likes biomes:** HILLS, SPARSE  
**Alternate seed:** no  

Crop Synthesizer only. Requires mica block y-2.

## Breeding setup

Full breeding setup — a cross-crop stick in the center on Stone over a **mica** block, with the parents planted in a line through it (**Tine** (north), **Bauxia** (south)):

<GameScene zoom={4} interactive={true}>
  <Block id="gregtech:gt.blockcasings5" meta="0" x="0" y="0" z="0" />
  <Block id="minecraft:stone" x="0" y="1" z="0" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crossCrop:1b}' x="0" y="2" z="0" />
  <Block id="gregtech:gt.blockmetal7" meta="7" x="0" y="0" z="-1" />
  <Block id="minecraft:stone" x="0" y="1" z="-1" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crop:{crop:"cropsnh:tine",amount:1,gr:1b,ga:1b,re:1b,scan:1b},progress:1000}' x="0" y="2" z="-1" />
  <Block id="gregtech:gt.blockmetal1" meta="1" x="0" y="0" z="1" />
  <Block id="minecraft:stone" x="0" y="1" z="1" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crop:{crop:"cropsnh:bauxia",amount:1,gr:1b,ga:1b,re:1b,scan:1b},progress:1000}' x="0" y="2" z="1" />
  <BlockAnnotation pos="0 2 0" color="#80FFAA00" thickness="2" alwaysOnTop="true">Micadia — cross-crop (result grows here)</BlockAnnotation>
  <BlockAnnotation pos="0 2 -1" color="#8044DD66" thickness="2" alwaysOnTop="true">Tine (parent)</BlockAnnotation>
  <BlockAnnotation pos="0 2 1" color="#8044DD66" thickness="2" alwaysOnTop="true">Bauxia (parent)</BlockAnnotation>
</GameScene>

## How to obtain

Bred from:

| Parents | Result pools | Notes |
|---------|--------------|-------|
| [Tine](/crops/tine.md) + [Bauxia](/crops/bauxia.md) | `STONE` | machine recipe |

Exact per-tick chance depends on soil and the parents' shared pools — check the [web calculator](https://crops-nh.netlify.app/calculator.html).


