---
navigation:
  icon: 'cropsnh:genericSeed{crop:"cropsnh:platina"}'
  title: Platina
  parent: /crops.md
  position: 9
---

# Platina

> [!NOTE]
> **Machine-only.** Produced by a machine process, not by breeding on crop sticks.

> [!WARNING]
> **Buried block required.** This crop needs a `platinum` block two spaces below the cross-crop stick (directly under the soil). Without it the crop won't grow — see the setup scene below.

**Tier:** 11  
**Soil:** [Stone](/mechanics/soil-and-blocks.md) — Stone, Cobblestone, Stone Brick, Mossy Cobble + Chisel variants  
**Block under soil:** `platinum`  
**Likes biomes:** HOT, SANDY  
**Alternate seed:** no  

Crop Synthesizer only. Requires platinum block y-2. EV+ machine tier.

## Breeding setup

Full breeding setup — a cross-crop stick in the center on Stone over a **platinum** block, with the parents planted in a line through it (**Diareed** (north), **Rubyne** (south)):

<GameScene zoom={4} interactive={true}>
  <Block id="gregtech:gt.blockmetal5" meta="12" x="0" y="0" z="0" />
  <Block id="minecraft:stone" x="0" y="1" z="0" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crossCrop:1b}' x="0" y="2" z="0" />
  <Block id="minecraft:diamond_block" x="0" y="0" z="-1" />
  <Block id="minecraft:stone" x="0" y="1" z="-1" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crop:{crop:"cropsnh:diareed",amount:1,gr:1b,ga:1b,re:1b,scan:1b},progress:1000}' x="0" y="2" z="-1" />
  <Block id="gregtech:gt.blockgem2" meta="11" x="0" y="0" z="1" />
  <Block id="minecraft:farmland" x="0" y="1" z="1" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crop:{crop:"cropsnh:rubyne",amount:1,gr:1b,ga:1b,re:1b,scan:1b},progress:1000}' x="0" y="2" z="1" />
  <BlockAnnotation pos="0 2 0" color="#80FFAA00" thickness="2" alwaysOnTop="true">Platina — cross-crop (result grows here)</BlockAnnotation>
  <BlockAnnotation pos="0 2 -1" color="#8044DD66" thickness="2" alwaysOnTop="true">Diareed (parent)</BlockAnnotation>
  <BlockAnnotation pos="0 2 1" color="#8044DD66" thickness="2" alwaysOnTop="true">Rubyne (parent)</BlockAnnotation>
</GameScene>

## How to obtain

Bred from:

| Parents | Result pools | Notes |
|---------|--------------|-------|
| [Diareed](/crops/diareed.md) + [Rubyne](/crops/rubyne.md) | `STONE` | machine recipe |

Exact per-tick chance depends on soil and the parents' shared pools — check the [web calculator](https://crops-nh.netlify.app/calculator.html).

## Used to breed

Platina is a parent in these mutations:

| Produces | With |
|----------|------|
| [Iridine](/crops/iridine.md) | [Scheelinium](/crops/scheelinium.md) |
| [Osmianth](/crops/osmianth.md) | [Scheelinium](/crops/scheelinium.md) |


