---
navigation:
  icon: 'cropsnh:genericSeed{crop:"cropsnh:cassitine"}'
  title: Cassitine
  parent: /crops.md
  position: 14
---

# Cassitine

> [!WARNING]
> **Buried block required.** This crop needs a `tin` block two spaces below the cross-crop stick (directly under the soil). Without it the crop won't grow — see the setup scene below.

**Tier:** 6  
**Soil:** [Stone](/mechanics/soil-and-blocks.md) — Stone, Cobblestone, Stone Brick, Mossy Cobble + Chisel variants  
**Block under soil:** `tin`  
**Likes biomes:** COLD, SPARSE, DRY  
**Alternate seed:** no  
**Pools:** `BUSH`, `GRAY`, `LEAFY`, `METALLIC`, `SHINY`, `TIN`  

## Breeding setup

Full breeding setup — a cross-crop stick in the center on Stone over a **tin** block, with the parents planted around it (**Malaxia** (north), **Stone Lily** (south), **Marble Lily** (east)):

<GameScene zoom={4} interactive={true}>
  <Block id="gregtech:gt.blockmetal7" meta="7" x="0" y="0" z="0" />
  <Block id="minecraft:stone" x="0" y="1" z="0" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crossCrop:1b}' x="0" y="2" z="0" />
  <Block id="gregtech:gt.blockmetal2" meta="7" x="0" y="0" z="-1" />
  <Block id="minecraft:stone" x="0" y="1" z="-1" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crop:{crop:"cropsnh:malaxia",amount:1,gr:1b,ga:1b,re:1b,scan:1b},progress:1000}' x="0" y="2" z="-1" />
  <Block id="minecraft:stone" x="0" y="0" z="1" />
  <Block id="minecraft:stone" x="0" y="1" z="1" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crop:{crop:"cropsnh:stoneLily",amount:1,gr:1b,ga:1b,re:1b,scan:1b},progress:1000}' x="0" y="2" z="1" />
  <Block id="gregtech:gt.blockstones" meta="0" x="1" y="0" z="0" />
  <Block id="minecraft:stone" x="1" y="1" z="0" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crop:{crop:"cropsnh:marbleLily",amount:1,gr:1b,ga:1b,re:1b,scan:1b},progress:1000}' x="1" y="2" z="0" />
  <BlockAnnotation pos="0 2 0" color="#80FFAA00" thickness="2" alwaysOnTop="true">Cassitine — cross-crop (result grows here)</BlockAnnotation>
  <BlockAnnotation pos="0 2 -1" color="#8044DD66" thickness="2" alwaysOnTop="true">Malaxia (parent)</BlockAnnotation>
  <BlockAnnotation pos="0 2 1" color="#8044DD66" thickness="2" alwaysOnTop="true">Stone Lily (parent)</BlockAnnotation>
  <BlockAnnotation pos="1 2 0" color="#8044DD66" thickness="2" alwaysOnTop="true">Marble Lily (parent)</BlockAnnotation>
</GameScene>

## How to obtain

Bred from:

| Parents | Result pools | Notes |
|---------|--------------|-------|
| [Malaxia](/crops/malaxia.md) + [Stone Lily](/crops/stonelily.md) + [Marble Lily](/crops/marblelily.md) | `BUSH`, `GRAY`, `LEAFY`, `METALLIC`, `SHINY`, `TIN` | crop-stick cross |

Exact per-tick chance depends on soil and the parents' shared pools — check the [web calculator](https://crops-nh.netlify.app/calculator.html).

## Used to breed

Cassitine is a parent in these mutations:

| Produces | With |
|----------|------|
| [Silviscus](/crops/silviscus.md) | [Malaxia](/crops/malaxia.md) + [Marble Lily](/crops/marblelily.md) |
| [Tin Ore Berry](/crops/tinoreberry.md) | [BoP Berry](/crops/bopberry.md) + [Stone Lily](/crops/stonelily.md) |


