---
navigation:
  icon: 'cropsnh:genericSeed{crop:"cropsnh:evilOre"}'
  title: Evil Ore
  parent: /crops.md
  position: 12
---

# Evil Ore

**Tier:** 8  
**Soil:** [Netherrack](/mechanics/soil-and-blocks.md) — Netherrack, TiC Nether Bricks, Chisel Netherrack  
**Likes biomes:** HOT, DRY, NETHER  
**Alternate seed:** no  
**Pools:** `CRYSTALLINE`, `EVIL`, `FIERY`, `NETHER`, `WHITE`  

## Breeding setup

Full breeding setup — a cross-crop stick in the center on Netherrack, with the parents planted in a line through it (**Nether Stone Lily** (north), **Soul Sand Lily** (south)):

<GameScene zoom={4} interactive={true}>
  <Block id="minecraft:netherrack" x="0" y="0" z="0" />
  <Block id="minecraft:netherrack" x="0" y="1" z="0" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crossCrop:1b}' x="0" y="2" z="0" />
  <Block id="minecraft:netherrack" x="0" y="0" z="-1" />
  <Block id="minecraft:stone" x="0" y="1" z="-1" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crop:{crop:"cropsnh:netherStoneLily",amount:1,gr:1b,ga:1b,re:1b,scan:1b},progress:1000}' x="0" y="2" z="-1" />
  <Block id="minecraft:soul_sand" x="0" y="0" z="1" />
  <Block id="minecraft:stone" x="0" y="1" z="1" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crop:{crop:"cropsnh:soulSandLily",amount:1,gr:1b,ga:1b,re:1b,scan:1b},progress:1000}' x="0" y="2" z="1" />
  <BlockAnnotation pos="0 2 0" color="#80FFAA00" thickness="2" alwaysOnTop="true">Evil Ore — cross-crop (result grows here)</BlockAnnotation>
  <BlockAnnotation pos="0 2 -1" color="#8044DD66" thickness="2" alwaysOnTop="true">Nether Stone Lily (parent)</BlockAnnotation>
  <BlockAnnotation pos="0 2 1" color="#8044DD66" thickness="2" alwaysOnTop="true">Soul Sand Lily (parent)</BlockAnnotation>
</GameScene>

## How to obtain

Bred from:

| Parents | Result pools | Notes |
|---------|--------------|-------|
| [Nether Stone Lily](/crops/netherstonelily.md) + [Soul Sand Lily](/crops/soulsandlily.md) | `CRYSTALLINE`, `EVIL`, `FIERY`, `NETHER`, `WHITE` | crop-stick cross |

Exact per-tick chance depends on soil and the parents' shared pools — check the [web calculator](https://crops-nh.netlify.app/calculator.html).

## Used to breed

Evil Ore is a parent in these mutations:

| Produces | With |
|----------|------|
| [Diareed](/crops/diareed.md) | [Withereed](/crops/withereed.md) |
| [Sapphirum](/crops/sapphirum.md) | [Lazulia](/crops/lazulia.md) |
| [Olivia](/crops/olivia.md) | [End Stone Lily](/crops/endstonelily.md) |


