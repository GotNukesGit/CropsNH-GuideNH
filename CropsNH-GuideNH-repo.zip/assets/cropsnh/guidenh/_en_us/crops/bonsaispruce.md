---
navigation:
  icon: 'cropsnh:genericSeed{crop:"cropsnh:bonsaiSpruce"}'
  title: Bonsai Spruce
  parent: /crops.md
  position: 19
---

# Bonsai Spruce

**Tier:** 1  
**Soil:** [Dirt / Grass](/mechanics/soil-and-blocks.md) — Dirt, Grass, Mycelium variants  
**Likes biomes:** CONIFEROUS, FOREST, MOUNTAIN  
**Alternate seed:** no  
**Pools:** `BROWN`, `TREE`, `WOODEN`  

## Breeding setup

Full breeding setup — a cross-crop stick in the center on Dirt / Grass, with the parents planted in a line through it (**Bonsai Oak** (north), **Pumpkin** (south)):

<GameScene zoom={4} interactive={true}>
  <Block id="minecraft:dirt" x="0" y="0" z="0" />
  <Block id="minecraft:dirt" x="0" y="1" z="0" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crossCrop:1b}' x="0" y="2" z="0" />
  <Block id="minecraft:dirt" x="0" y="0" z="-1" />
  <Block id="minecraft:dirt" x="0" y="1" z="-1" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crop:{crop:"cropsnh:bonsaiOak",amount:1,gr:1b,ga:1b,re:1b,scan:1b},progress:1000}' x="0" y="2" z="-1" />
  <Block id="minecraft:dirt" x="0" y="0" z="1" />
  <Block id="minecraft:farmland" x="0" y="1" z="1" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crop:{crop:"cropsnh:pumpkin",amount:1,gr:1b,ga:1b,re:1b,scan:1b},progress:1000}' x="0" y="2" z="1" />
  <BlockAnnotation pos="0 2 0" color="#80FFAA00" thickness="2" alwaysOnTop="true">Bonsai Spruce — cross-crop (result grows here)</BlockAnnotation>
  <BlockAnnotation pos="0 2 -1" color="#8044DD66" thickness="2" alwaysOnTop="true">Bonsai Oak (parent)</BlockAnnotation>
  <BlockAnnotation pos="0 2 1" color="#8044DD66" thickness="2" alwaysOnTop="true">Pumpkin (parent)</BlockAnnotation>
</GameScene>

## How to obtain

Bred from:

| Parents | Result pools | Notes |
|---------|--------------|-------|
| [Bonsai Oak](/crops/bonsaioak.md) + [Pumpkin](/crops/pumpkin.md) | `BROWN`, `TREE`, `WOODEN` | crop-stick cross |

Exact per-tick chance depends on soil and the parents' shared pools — check the [web calculator](https://crops-nh.netlify.app/calculator.html).

## Used to breed

Bonsai Spruce is a parent in these mutations:

| Produces | With |
|----------|------|
| [Bonsai Dark Oak](/crops/bonsaidarkoak.md) | [Bonsai Oak](/crops/bonsaioak.md) |
| [Bonsai Rubber](/crops/bonsairubber.md) | [Bonsai Jungle](/crops/bonsaijungle.md) |
| [Ivy](/crops/ivy.md) | [Vine](/crops/vine.md) |
| [Tine](/crops/tine.md) | [Stone Lily](/crops/stonelily.md) |


