---
navigation:
  icon: 'cropsnh:genericSeed{crop:"cropsnh:bonsaiSlimy"}'
  title: Bonsai Slimy
  parent: /crops.md
  position: 19
---

# Bonsai Slimy

**Tier:** 1  
**Soil:** [Slimy Dirt/Grass](/mechanics/soil-and-blocks.md) — Dirt, Grass + all Slimy Soil variants (CompoundSoilList)  
**Likes biomes:** WET, SWAMP  
**Alternate seed:** no  

Crop Breeder only: BonsaiJungle + BonsaiRubber + Slimeplant.

## Breeding setup

Full breeding setup — a cross-crop stick in the center on Slimy Dirt/Grass, with the parents planted around it (**Slimeplant** (north), **Bonsai Jungle** (south), **Bonsai Rubber** (east)):

<GameScene zoom={4} interactive={true}>
  <Block id="minecraft:dirt" x="0" y="0" z="0" />
  <Block id="minecraft:dirt" x="0" y="1" z="0" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crossCrop:1b}' x="0" y="2" z="0" />
  <Block id="minecraft:dirt" x="0" y="0" z="-1" />
  <Block id="minecraft:dirt" x="0" y="1" z="-1" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crop:{crop:"cropsnh:slimeplant",amount:1,gr:1b,ga:1b,re:1b,scan:1b},progress:1000}' x="0" y="2" z="-1" />
  <Block id="minecraft:dirt" x="0" y="0" z="1" />
  <Block id="minecraft:dirt" x="0" y="1" z="1" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crop:{crop:"cropsnh:bonsaiJungle",amount:1,gr:1b,ga:1b,re:1b,scan:1b},progress:1000}' x="0" y="2" z="1" />
  <Block id="minecraft:dirt" x="1" y="0" z="0" />
  <Block id="minecraft:dirt" x="1" y="1" z="0" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crop:{crop:"cropsnh:bonsaiRubber",amount:1,gr:1b,ga:1b,re:1b,scan:1b},progress:1000}' x="1" y="2" z="0" />
  <BlockAnnotation pos="0 2 0" color="#80FFAA00" thickness="2" alwaysOnTop="true">Bonsai Slimy — cross-crop (result grows here)</BlockAnnotation>
  <BlockAnnotation pos="0 2 -1" color="#8044DD66" thickness="2" alwaysOnTop="true">Slimeplant (parent)</BlockAnnotation>
  <BlockAnnotation pos="0 2 1" color="#8044DD66" thickness="2" alwaysOnTop="true">Bonsai Jungle (parent)</BlockAnnotation>
  <BlockAnnotation pos="1 2 0" color="#8044DD66" thickness="2" alwaysOnTop="true">Bonsai Rubber (parent)</BlockAnnotation>
</GameScene>

## How to obtain

Bred from:

| Parents | Result pools | Notes |
|---------|--------------|-------|
| [Slimeplant](/crops/slimeplant.md) + [Bonsai Jungle](/crops/bonsaijungle.md) + [Bonsai Rubber](/crops/bonsairubber.md) | `STICKY`, `TREE`, `WOODEN` | machine recipe |

Exact per-tick chance depends on soil and the parents' shared pools — check the [web calculator](https://crops-nh.netlify.app/calculator.html).


