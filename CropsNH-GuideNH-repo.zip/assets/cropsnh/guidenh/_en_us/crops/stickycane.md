---
navigation:
  icon: 'cropsnh:genericSeed{crop:"cropsnh:stickyCane"}'
  title: Sticky Cane
  parent: /crops.md
  position: 16
---

# Sticky Cane

**Tier:** 4  
**Soil:** [Sugarcane Soil](/mechanics/soil-and-blocks.md) — Sand, Sandstone, Dirt, Grass (CompoundSoilList)  
**Likes biomes:** WET, HOT, SANDY  
**Alternate seed:** no  
**Pools:** `GREEN`, `REED`, `STICKY`  

## Breeding setup

Full breeding setup — a cross-crop stick in the center on Sugarcane Soil, with the parents planted in a line through it (**Bonsai Jungle** (north), **Sugar Cane** (south)):

<GameScene zoom={4} interactive={true}>
  <Block id="minecraft:sand" x="0" y="0" z="0" />
  <Block id="minecraft:sand" x="0" y="1" z="0" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crossCrop:1b}' x="0" y="2" z="0" />
  <Block id="minecraft:dirt" x="0" y="0" z="-1" />
  <Block id="minecraft:dirt" x="0" y="1" z="-1" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crop:{crop:"cropsnh:bonsaiJungle",amount:1,gr:1b,ga:1b,re:1b,scan:1b},progress:1000}' x="0" y="2" z="-1" />
  <Block id="minecraft:sand" x="0" y="0" z="1" />
  <Block id="minecraft:sand" x="0" y="1" z="1" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crop:{crop:"cropsnh:sugarCane",amount:1,gr:1b,ga:1b,re:1b,scan:1b},progress:1000}' x="0" y="2" z="1" />
  <BlockAnnotation pos="0 2 0" color="#80FFAA00" thickness="2" alwaysOnTop="true">Sticky Cane — cross-crop (result grows here)</BlockAnnotation>
  <BlockAnnotation pos="0 2 -1" color="#8044DD66" thickness="2" alwaysOnTop="true">Bonsai Jungle (parent)</BlockAnnotation>
  <BlockAnnotation pos="0 2 1" color="#8044DD66" thickness="2" alwaysOnTop="true">Sugar Cane (parent)</BlockAnnotation>
</GameScene>

## How to obtain

Bred from:

| Parents | Result pools | Notes |
|---------|--------------|-------|
| [Bonsai Jungle](/crops/bonsaijungle.md) + [Sugar Cane](/crops/sugarcane.md) | `GREEN`, `REED`, `STICKY` | crop-stick cross |

Exact per-tick chance depends on soil and the parents' shared pools — check the [web calculator](https://crops-nh.netlify.app/calculator.html).


