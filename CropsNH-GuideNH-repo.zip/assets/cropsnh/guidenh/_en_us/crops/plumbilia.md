---
navigation:
  icon: 'cropsnh:genericSeed{crop:"cropsnh:plumbilia"}'
  title: Plumbilia
  parent: /crops.md
  position: 14
---

# Plumbilia

> [!WARNING]
> **Buried block required.** This crop needs a `lead` block two spaces below the cross-crop stick (directly under the soil). Without it the crop won't grow — see the setup scene below.

**Tier:** 6  
**Soil:** [Stone](/mechanics/soil-and-blocks.md) — Stone, Cobblestone, Stone Brick, Mossy Cobble + Chisel variants  
**Block under soil:** `lead`  
**Likes biomes:** SAVANNA, PLAINS  
**Alternate seed:** no  
**Pools:** `DENSE`, `LEAD`, `METALLIC`, `REED`  

## Breeding setup

Full breeding setup — a cross-crop stick in the center on Stone over a **lead** block, with the parents planted in a line through it (**Coppon** (north), **Withereed** (south)):

<GameScene zoom={4} interactive={true}>
  <Block id="gregtech:gt.blockmetal4" meta="2" x="0" y="0" z="0" />
  <Block id="minecraft:stone" x="0" y="1" z="0" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crossCrop:1b}' x="0" y="2" z="0" />
  <Block id="gregtech:gt.blockmetal2" meta="7" x="0" y="0" z="-1" />
  <Block id="minecraft:stone" x="0" y="1" z="-1" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crop:{crop:"cropsnh:coppon",amount:1,gr:1b,ga:1b,re:1b,scan:1b},progress:1000}' x="0" y="2" z="-1" />
  <Block id="minecraft:coal_block" x="0" y="0" z="1" />
  <Block id="minecraft:stone" x="0" y="1" z="1" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crop:{crop:"cropsnh:withereed",amount:1,gr:1b,ga:1b,re:1b,scan:1b},progress:1000}' x="0" y="2" z="1" />
  <BlockAnnotation pos="0 2 0" color="#80FFAA00" thickness="2" alwaysOnTop="true">Plumbilia — cross-crop (result grows here)</BlockAnnotation>
  <BlockAnnotation pos="0 2 -1" color="#8044DD66" thickness="2" alwaysOnTop="true">Coppon (parent)</BlockAnnotation>
  <BlockAnnotation pos="0 2 1" color="#8044DD66" thickness="2" alwaysOnTop="true">Withereed (parent)</BlockAnnotation>
</GameScene>

## How to obtain

Bred from:

| Parents | Result pools | Notes |
|---------|--------------|-------|
| [Coppon](/crops/coppon.md) + [Withereed](/crops/withereed.md) | `DENSE`, `LEAD`, `METALLIC`, `REED` | crop-stick cross |

Exact per-tick chance depends on soil and the parents' shared pools — check the [web calculator](https://crops-nh.netlify.app/calculator.html).

## Used to breed

Plumbilia is a parent in these mutations:

| Produces | With |
|----------|------|
| [Argentia](/crops/argentia.md) | [Tine](/crops/tine.md) |
| [Auronia](/crops/auronia.md) | [Coppon](/crops/coppon.md) |
| [Thiosulfine](/crops/thiosulfine.md) | [Galvania](/crops/galvania.md) |


