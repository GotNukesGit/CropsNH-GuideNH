---
navigation:
  icon: 'cropsnh:genericSeed{crop:"cropsnh:spidernip"}'
  title: Spidernip
  parent: /crops.md
  position: 16
---

# Spidernip

**Tier:** 4  
**Soil:** [Farmland](/mechanics/soil-and-blocks.md) — Farmland, Enchanted Earth, Ztones Garden Soil, Fertilized Dirt  
**Likes biomes:** WET, LUSH  
**Alternate seed:** no  
**Pools:** `ADDICTIVE`, `EDIBLE`, `EVIL`, `POISONOUS`, `POTION_INGREDIENT`, `SILK`, `WHITE`  

## Breeding setup

Full breeding setup — a cross-crop stick in the center on Farmland, with the parents planted around it (**Flax** (north), **Hemp** (south), **Zomplant** (east)):

<GameScene zoom={4} interactive={true}>
  <Block id="minecraft:dirt" x="0" y="0" z="0" />
  <Block id="minecraft:farmland" x="0" y="1" z="0" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crossCrop:1b}' x="0" y="2" z="0" />
  <Block id="minecraft:dirt" x="0" y="0" z="-1" />
  <Block id="minecraft:farmland" x="0" y="1" z="-1" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crop:{crop:"cropsnh:flax",amount:1,gr:1b,ga:1b,re:1b,scan:1b},progress:1000}' x="0" y="2" z="-1" />
  <Block id="minecraft:dirt" x="0" y="0" z="1" />
  <Block id="minecraft:farmland" x="0" y="1" z="1" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crop:{crop:"cropsnh:hemp",amount:1,gr:1b,ga:1b,re:1b,scan:1b},progress:1000}' x="0" y="2" z="1" />
  <Block id="tconstruct:CraftedSoil" meta="3" x="1" y="0" z="0" />
  <Block id="tconstruct:CraftedSoil" meta="3" x="1" y="1" z="0" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crop:{crop:"cropsnh:zomplant",amount:1,gr:1b,ga:1b,re:1b,scan:1b},progress:1000}' x="1" y="2" z="0" />
  <BlockAnnotation pos="0 2 0" color="#80FFAA00" thickness="2" alwaysOnTop="true">Spidernip — cross-crop (result grows here)</BlockAnnotation>
  <BlockAnnotation pos="0 2 -1" color="#8044DD66" thickness="2" alwaysOnTop="true">Flax (parent)</BlockAnnotation>
  <BlockAnnotation pos="0 2 1" color="#8044DD66" thickness="2" alwaysOnTop="true">Hemp (parent)</BlockAnnotation>
  <BlockAnnotation pos="1 2 0" color="#8044DD66" thickness="2" alwaysOnTop="true">Zomplant (parent)</BlockAnnotation>
</GameScene>

## How to obtain

Bred from:

| Parents | Result pools | Notes |
|---------|--------------|-------|
| [Flax](/crops/flax.md) + [Hemp](/crops/hemp.md) + [Zomplant](/crops/zomplant.md) | `ADDICTIVE`, `EDIBLE`, `EVIL`, `POISONOUS`, `POTION_INGREDIENT`, `SILK`, `WHITE` | crop-stick cross |

Exact per-tick chance depends on soil and the parents' shared pools — check the [web calculator](https://crops-nh.netlify.app/calculator.html).

## Used to breed

Spidernip is a parent in these mutations:

| Produces | With |
|----------|------|
| [Essence Ore Berry](/crops/essenceoreberry.md) | [Creeperweed](/crops/creeperweed.md) + [Zomplant](/crops/zomplant.md) + [Tearstalks](/crops/tearstalks.md) |
| [Necrobloom](/crops/necrobloom.md) | [Purple Tulip](/crops/purpletulip.md) |


