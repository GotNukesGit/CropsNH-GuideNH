---
navigation:
  icon: 'cropsnh:genericSeed{crop:"cropsnh:soulSandLily"}'
  title: Soul Sand Lily
  parent: /crops.md
  position: 18
---

# Soul Sand Lily

> [!WARNING]
> **Buried block required.** This crop needs a `soulSand` block two spaces below the cross-crop stick (directly under the soil). Without it the crop won't grow — see the setup scene below.

**Tier:** 2  
**Soil:** [Stone](/mechanics/soil-and-blocks.md) — Stone, Cobblestone, Stone Brick, Mossy Cobble + Chisel variants  
**Block under soil:** `soulSand`  
**Likes biomes:** NETHER, SPOOKY, SANDY  
**Alternate seed:** no  
**Pools:** `BROWN`, `DANGEROUS`, `NETHER`, `OIL`, `STONE`  

## Breeding setup

Full breeding setup — a cross-crop stick in the center on Stone over a **soulSand** block, with the parents planted in a line through it (**Nether Stone Lily** (north), **Sand Lily** (south)):

<GameScene zoom={4} interactive={true}>
  <Block id="minecraft:soul_sand" x="0" y="0" z="0" />
  <Block id="minecraft:stone" x="0" y="1" z="0" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crossCrop:1b}' x="0" y="2" z="0" />
  <Block id="minecraft:netherrack" x="0" y="0" z="-1" />
  <Block id="minecraft:stone" x="0" y="1" z="-1" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crop:{crop:"cropsnh:netherStoneLily",amount:1,gr:1b,ga:1b,re:1b,scan:1b},progress:1000}' x="0" y="2" z="-1" />
  <Block id="minecraft:sand" x="0" y="0" z="1" />
  <Block id="minecraft:stone" x="0" y="1" z="1" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crop:{crop:"cropsnh:sandLily",amount:1,gr:1b,ga:1b,re:1b,scan:1b},progress:1000}' x="0" y="2" z="1" />
  <BlockAnnotation pos="0 2 0" color="#80FFAA00" thickness="2" alwaysOnTop="true">Soul Sand Lily — cross-crop (result grows here)</BlockAnnotation>
  <BlockAnnotation pos="0 2 -1" color="#8044DD66" thickness="2" alwaysOnTop="true">Nether Stone Lily (parent)</BlockAnnotation>
  <BlockAnnotation pos="0 2 1" color="#8044DD66" thickness="2" alwaysOnTop="true">Sand Lily (parent)</BlockAnnotation>
</GameScene>

## How to obtain

Bred from:

| Parents | Result pools | Notes |
|---------|--------------|-------|
| [Nether Stone Lily](/crops/netherstonelily.md) + [Sand Lily](/crops/sandlily.md) | `BROWN`, `DANGEROUS`, `NETHER`, `OIL`, `STONE` | crop-stick cross |

Exact per-tick chance depends on soil and the parents' shared pools — check the [web calculator](https://crops-nh.netlify.app/calculator.html).

## Used to breed

Soul Sand Lily is a parent in these mutations:

| Produces | With |
|----------|------|
| [Evil Ore](/crops/evilore.md) | [Nether Stone Lily](/crops/netherstonelily.md) |
| [Tearstalks](/crops/tearstalks.md) | [Goldfish](/crops/goldfish.md) + [Nether Stone Lily](/crops/netherstonelily.md) |
| [Oil Berry](/crops/oilberry.md) | [Withereed](/crops/withereed.md) |


