---
navigation:
  icon: 'cropsnh:genericSeed{crop:"cropsnh:cactus"}'
  title: Cactus
  parent: /crops.md
  position: 17
---

# Cactus

**Tier:** 3  
**Soil:** [Sand](/mechanics/soil-and-blocks.md) — Sand, Sandstone  
**Likes biomes:** SANDY, HOT, DRY  
**Alternate seed:** yes — plantable without breeding  
**Pools:** `CACTUS`, `DANGEROUS`, `GREEN`  

## Breeding setup

Full breeding setup — a cross-crop stick in the center on Sand, with the parents planted in a line through it (**Sugar Cane** (north), **Potato** (south)):

<GameScene zoom={4} interactive={true}>
  <Block id="minecraft:sand" x="0" y="0" z="0" />
  <Block id="minecraft:sand" x="0" y="1" z="0" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crossCrop:1b}' x="0" y="2" z="0" />
  <Block id="minecraft:sand" x="0" y="0" z="-1" />
  <Block id="minecraft:sand" x="0" y="1" z="-1" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crop:{crop:"cropsnh:sugarCane",amount:1,gr:1b,ga:1b,re:1b,scan:1b},progress:1000}' x="0" y="2" z="-1" />
  <Block id="minecraft:dirt" x="0" y="0" z="1" />
  <Block id="minecraft:farmland" x="0" y="1" z="1" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crop:{crop:"cropsnh:potato",amount:1,gr:1b,ga:1b,re:1b,scan:1b},progress:1000}' x="0" y="2" z="1" />
  <BlockAnnotation pos="0 2 0" color="#80FFAA00" thickness="2" alwaysOnTop="true">Cactus — cross-crop (result grows here)</BlockAnnotation>
  <BlockAnnotation pos="0 2 -1" color="#8044DD66" thickness="2" alwaysOnTop="true">Sugar Cane (parent)</BlockAnnotation>
  <BlockAnnotation pos="0 2 1" color="#8044DD66" thickness="2" alwaysOnTop="true">Potato (parent)</BlockAnnotation>
</GameScene>

## How to obtain

Bred from:

| Parents | Result pools | Notes |
|---------|--------------|-------|
| [Sugar Cane](/crops/sugarcane.md) + [Potato](/crops/potato.md) | `CACTUS`, `DANGEROUS`, `GREEN` | crop-stick cross |

Exact per-tick chance depends on soil and the parents' shared pools — check the [web calculator](https://crops-nh.netlify.app/calculator.html).

## Used to breed

Cactus is a parent in these mutations:

| Produces | With |
|----------|------|
| [Bonsai Acacia](/crops/bonsaiacacia.md) | [Bonsai Oak](/crops/bonsaioak.md) |
| [Chilly](/crops/chilly.md) | [Cocoa](/crops/cocoa.md) |
| [Green Glowshroom](/crops/greenglowshroom.md) | [Glowflower](/crops/glowflower.md) |
| [Saguaro Cactus](/crops/saguarocactus.md) | [Sand Lily](/crops/sandlily.md) |
| [Sand Lily](/crops/sandlily.md) | [Stone Lily](/crops/stonelily.md) |
| [Thornvine](/crops/thornvine.md) | [Vine](/crops/vine.md) |


