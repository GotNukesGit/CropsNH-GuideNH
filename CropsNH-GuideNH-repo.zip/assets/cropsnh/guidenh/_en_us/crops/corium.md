---
navigation:
  icon: 'cropsnh:genericSeed{crop:"cropsnh:corium"}'
  title: Corium
  parent: /crops.md
  position: 14
---

# Corium

**Tier:** 6  
**Soil:** [Farmland](/mechanics/soil-and-blocks.md) — Farmland, Enchanted Earth, Ztones Garden Soil, Fertilized Dirt  
**Likes biomes:** PLAINS, FOREST  
**Alternate seed:** no  
**Pools:** `COW`, `SILK`, `TENDRILLY`  

## Breeding setup

Full breeding setup — a cross-crop stick in the center on Farmland, with the parents planted in a line through it (**Wheat** (north), **Cocoa** (south)):

<GameScene zoom={4} interactive={true}>
  <Block id="minecraft:dirt" x="0" y="0" z="0" />
  <Block id="minecraft:farmland" x="0" y="1" z="0" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crossCrop:1b}' x="0" y="2" z="0" />
  <Block id="minecraft:dirt" x="0" y="0" z="-1" />
  <Block id="minecraft:farmland" x="0" y="1" z="-1" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crop:{crop:"cropsnh:wheat",amount:1,gr:1b,ga:1b,re:1b,scan:1b},progress:1000}' x="0" y="2" z="-1" />
  <Block id="minecraft:dirt" x="0" y="0" z="1" />
  <Block id="minecraft:farmland" x="0" y="1" z="1" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crop:{crop:"cropsnh:cocoa",amount:1,gr:1b,ga:1b,re:1b,scan:1b},progress:1000}' x="0" y="2" z="1" />
  <BlockAnnotation pos="0 2 0" color="#80FFAA00" thickness="2" alwaysOnTop="true">Corium — cross-crop (result grows here)</BlockAnnotation>
  <BlockAnnotation pos="0 2 -1" color="#8044DD66" thickness="2" alwaysOnTop="true">Wheat (parent)</BlockAnnotation>
  <BlockAnnotation pos="0 2 1" color="#8044DD66" thickness="2" alwaysOnTop="true">Cocoa (parent)</BlockAnnotation>
</GameScene>

## How to obtain

Bred from:

| Parents | Result pools | Notes |
|---------|--------------|-------|
| [Wheat](/crops/wheat.md) + [Cocoa](/crops/cocoa.md) | `COW`, `SILK`, `TENDRILLY` | crop-stick cross |

Exact per-tick chance depends on soil and the parents' shared pools — check the [web calculator](https://crops-nh.netlify.app/calculator.html).

## Used to breed

Corium is a parent in these mutations:

| Produces | With |
|----------|------|
| [Egg Plant](/crops/eggplant.md) | [Oxeye Daisy](/crops/oxeyedaisy.md) |
| [Fertilia](/crops/fertilia.md) | [Corpseplant](/crops/corpseplant.md) |
| [Meatrose](/crops/meatrose.md) | [Goldfish](/crops/goldfish.md) + [Egg Plant](/crops/eggplant.md) |
| [Milk Wart](/crops/milkwart.md) | [Nether Wart](/crops/netherwart.md) |
| [Papyrus](/crops/papyrus.md) | [Bonsai Birch](/crops/bonsaibirch.md) |


