---
navigation:
  icon: 'cropsnh:genericSeed{crop:"cropsnh:withereed"}'
  title: Withereed
  parent: /crops.md
  position: 12
---

# Withereed

> [!WARNING]
> **Buried block required.** This crop needs a `coal` block two spaces below the cross-crop stick (directly under the soil). Without it the crop won't grow — see the setup scene below.

**Tier:** 8  
**Soil:** [Stone](/mechanics/soil-and-blocks.md) — Stone, Cobblestone, Stone Brick, Mossy Cobble + Chisel variants  
**Block under soil:** `coal`  
**Likes biomes:** DEAD, SPOOKY  
**Alternate seed:** no  
**Pools:** `COAL`, `FIERY`, `REED`, `STEM`, `SULFUR`, `UNDEAD`  

## Breeding setup

Full breeding setup — a cross-crop stick in the center on Stone over a **coal** block, with the parents planted in a line through it (**Basalt Lily** (north), **Black Granite Lily** (south)):

<GameScene zoom={4} interactive={true}>
  <Block id="minecraft:coal_block" x="0" y="0" z="0" />
  <Block id="minecraft:stone" x="0" y="1" z="0" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crossCrop:1b}' x="0" y="2" z="0" />
  <Block id="gregtech:gt.blockstones" meta="8" x="0" y="0" z="-1" />
  <Block id="minecraft:stone" x="0" y="1" z="-1" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crop:{crop:"cropsnh:basaltLily",amount:1,gr:1b,ga:1b,re:1b,scan:1b},progress:1000}' x="0" y="2" z="-1" />
  <Block id="gregtech:gt.blockgranites" meta="0" x="0" y="0" z="1" />
  <Block id="minecraft:stone" x="0" y="1" z="1" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crop:{crop:"cropsnh:blackGraniteLily",amount:1,gr:1b,ga:1b,re:1b,scan:1b},progress:1000}' x="0" y="2" z="1" />
  <BlockAnnotation pos="0 2 0" color="#80FFAA00" thickness="2" alwaysOnTop="true">Withereed — cross-crop (result grows here)</BlockAnnotation>
  <BlockAnnotation pos="0 2 -1" color="#8044DD66" thickness="2" alwaysOnTop="true">Basalt Lily (parent)</BlockAnnotation>
  <BlockAnnotation pos="0 2 1" color="#8044DD66" thickness="2" alwaysOnTop="true">Black Granite Lily (parent)</BlockAnnotation>
</GameScene>

## How to obtain

Bred from:

| Parents | Result pools | Notes |
|---------|--------------|-------|
| [Basalt Lily](/crops/basaltlily.md) + [Black Granite Lily](/crops/blackgranitelily.md) | `COAL`, `FIERY`, `REED`, `STEM`, `SULFUR`, `UNDEAD` | crop-stick cross |

Exact per-tick chance depends on soil and the parents' shared pools — check the [web calculator](https://crops-nh.netlify.app/calculator.html).

## Used to breed

Withereed is a parent in these mutations:

| Produces | With |
|----------|------|
| [Creeperweed](/crops/creeperweed.md) | [Nether Stone Lily](/crops/netherstonelily.md) + [Salty Root](/crops/saltyroot.md) |
| [Diareed](/crops/diareed.md) | [Evil Ore](/crops/evilore.md) |
| [Plumbilia](/crops/plumbilia.md) | [Coppon](/crops/coppon.md) |
| [Zomplant](/crops/zomplant.md) | [Eyebulb](/crops/eyebulb.md) |
| [God of Thunder](/crops/godofthunder.md) | [BobsYerUncleRanks](/crops/bobsyeruncleranks.md) |
| [Oil Berry](/crops/oilberry.md) | [Soul Sand Lily](/crops/soulsandlily.md) |
| [Star Wart](/crops/starwart.md) | [Titania](/crops/titania.md) + [God of Thunder](/crops/godofthunder.md) |


