---
navigation:
  icon: 'cropsnh:genericSeed{crop:"cropsnh:oxeyeDaisy"}'
  title: Oxeye Daisy
  parent: /crops.md
  position: 18
---

# Oxeye Daisy

**Tier:** 2  
**Soil:** [Dirt / Grass](/mechanics/soil-and-blocks.md) — Dirt, Grass, Mycelium variants  
**Likes biomes:** PLAINS, FOREST  
**Alternate seed:** yes — plantable without breeding  
**Pools:** `FLOWER`, `WHITE`  

## Breeding setup

Full breeding setup — a cross-crop stick in the center on Dirt / Grass, with the parents planted in a line through it (**Azure Bluet** (north), **Dandelion** (south)):

<GameScene zoom={4} interactive={true}>
  <Block id="minecraft:dirt" x="0" y="0" z="0" />
  <Block id="minecraft:dirt" x="0" y="1" z="0" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crossCrop:1b}' x="0" y="2" z="0" />
  <Block id="minecraft:dirt" x="0" y="0" z="-1" />
  <Block id="minecraft:dirt" x="0" y="1" z="-1" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crop:{crop:"cropsnh:azureBluet",amount:1,gr:1b,ga:1b,re:1b,scan:1b},progress:1000}' x="0" y="2" z="-1" />
  <Block id="minecraft:dirt" x="0" y="0" z="1" />
  <Block id="minecraft:dirt" x="0" y="1" z="1" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crop:{crop:"cropsnh:dandelion",amount:1,gr:1b,ga:1b,re:1b,scan:1b},progress:1000}' x="0" y="2" z="1" />
  <BlockAnnotation pos="0 2 0" color="#80FFAA00" thickness="2" alwaysOnTop="true">Oxeye Daisy — cross-crop (result grows here)</BlockAnnotation>
  <BlockAnnotation pos="0 2 -1" color="#8044DD66" thickness="2" alwaysOnTop="true">Azure Bluet (parent)</BlockAnnotation>
  <BlockAnnotation pos="0 2 1" color="#8044DD66" thickness="2" alwaysOnTop="true">Dandelion (parent)</BlockAnnotation>
</GameScene>

## How to obtain

Bred from:

| Parents | Result pools | Notes |
|---------|--------------|-------|
| [Azure Bluet](/crops/azurebluet.md) + [Dandelion](/crops/dandelion.md) | `FLOWER`, `WHITE` | crop-stick cross |

Exact per-tick chance depends on soil and the parents' shared pools — check the [web calculator](https://crops-nh.netlify.app/calculator.html).

## Used to breed

Oxeye Daisy is a parent in these mutations:

| Produces | With |
|----------|------|
| [Canola](/crops/canola.md) | [Wheat](/crops/wheat.md) |
| [Egg Plant](/crops/eggplant.md) | [Corium](/crops/corium.md) |
| [Flowering Vine](/crops/floweringvine.md) | [Ivy](/crops/ivy.md) |
| [Marble Lily](/crops/marblelily.md) | [Stone Lily](/crops/stonelily.md) |
| [Raspberry](/crops/raspberry.md) | [Red Tulip](/crops/redtulip.md) |
| [White Tulip](/crops/whitetulip.md) | [Pink Tulip](/crops/pinktulip.md) |


