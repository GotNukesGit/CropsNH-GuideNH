---
navigation:
  icon: 'cropsnh:genericSeed{crop:"cropsnh:glowheat"}'
  title: Glowheat
  parent: /crops.md
  position: 16
---

# Glowheat

> [!WARNING]
> **Buried block required.** This crop needs a `glowstone` block two spaces below the cross-crop stick (directly under the soil). Without it the crop won't grow — see the setup scene below.

**Tier:** 4  
**Soil:** [Netherrack](/mechanics/soil-and-blocks.md) — Netherrack, TiC Nether Bricks, Chisel Netherrack  
**Block under soil:** `glowstone`  
**Likes biomes:** PLAINS, HOT, NETHER  
**Alternate seed:** no  
**Pools:** `CRYSTALLINE`, `EMISSIVE`, `POTION_INGREDIENT`, `SHINY`, `WHEAT`  

## Breeding setup

Full breeding setup — a cross-crop stick in the center on Netherrack over a **glowstone** block, with the parents planted in a line through it (**Glowflower** (north), **Wheat** (south)):

<GameScene zoom={4} interactive={true}>
  <Block id="minecraft:glowstone" x="0" y="0" z="0" />
  <Block id="minecraft:netherrack" x="0" y="1" z="0" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crossCrop:1b}' x="0" y="2" z="0" />
  <Block id="minecraft:dirt" x="0" y="0" z="-1" />
  <Block id="minecraft:dirt" x="0" y="1" z="-1" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crop:{crop:"cropsnh:glowflower",amount:1,gr:1b,ga:1b,re:1b,scan:1b},progress:1000}' x="0" y="2" z="-1" />
  <Block id="minecraft:dirt" x="0" y="0" z="1" />
  <Block id="minecraft:farmland" x="0" y="1" z="1" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crop:{crop:"cropsnh:wheat",amount:1,gr:1b,ga:1b,re:1b,scan:1b},progress:1000}' x="0" y="2" z="1" />
  <BlockAnnotation pos="0 2 0" color="#80FFAA00" thickness="2" alwaysOnTop="true">Glowheat — cross-crop (result grows here)</BlockAnnotation>
  <BlockAnnotation pos="0 2 -1" color="#8044DD66" thickness="2" alwaysOnTop="true">Glowflower (parent)</BlockAnnotation>
  <BlockAnnotation pos="0 2 1" color="#8044DD66" thickness="2" alwaysOnTop="true">Wheat (parent)</BlockAnnotation>
</GameScene>

## How to obtain

Bred from:

| Parents | Result pools | Notes |
|---------|--------------|-------|
| [Glowflower](/crops/glowflower.md) + [Wheat](/crops/wheat.md) | `CRYSTALLINE`, `EMISSIVE`, `POTION_INGREDIENT`, `SHINY`, `WHEAT` | crop-stick cross |

Exact per-tick chance depends on soil and the parents' shared pools — check the [web calculator](https://crops-nh.netlify.app/calculator.html).


