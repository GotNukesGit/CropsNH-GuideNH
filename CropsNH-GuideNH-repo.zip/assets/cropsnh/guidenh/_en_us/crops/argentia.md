---
navigation:
  icon: 'cropsnh:genericSeed{crop:"cropsnh:argentia"}'
  title: Argentia
  parent: /crops.md
  position: 13
---

# Argentia

> [!WARNING]
> **Buried block required.** This crop needs a `silver` block two spaces below the cross-crop stick (directly under the soil). Without it the crop won't grow — see the setup scene below.

**Tier:** 7  
**Soil:** [Stone](/mechanics/soil-and-blocks.md) — Stone, Cobblestone, Stone Brick, Mossy Cobble + Chisel variants  
**Block under soil:** `silver`  
**Likes biomes:** MOUNTAIN, HOT  
**Alternate seed:** no  
**Pools:** `METALLIC`, `SHINY`, `SILVER`, `TENDRILLY`, `WHITE`  

## Breeding setup

Full breeding setup — a cross-crop stick in the center on Stone over a **silver** block, with the parents planted in a line through it (**Plumbilia** (north), **Tine** (south)):

<GameScene zoom={4} interactive={true}>
  <Block id="gregtech:gt.blockmetal6" meta="10" x="0" y="0" z="0" />
  <Block id="minecraft:stone" x="0" y="1" z="0" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crossCrop:1b}' x="0" y="2" z="0" />
  <Block id="gregtech:gt.blockmetal4" meta="2" x="0" y="0" z="-1" />
  <Block id="minecraft:stone" x="0" y="1" z="-1" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crop:{crop:"cropsnh:plumbilia",amount:1,gr:1b,ga:1b,re:1b,scan:1b},progress:1000}' x="0" y="2" z="-1" />
  <Block id="gregtech:gt.blockmetal7" meta="7" x="0" y="0" z="1" />
  <Block id="minecraft:stone" x="0" y="1" z="1" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crop:{crop:"cropsnh:tine",amount:1,gr:1b,ga:1b,re:1b,scan:1b},progress:1000}' x="0" y="2" z="1" />
  <BlockAnnotation pos="0 2 0" color="#80FFAA00" thickness="2" alwaysOnTop="true">Argentia — cross-crop (result grows here)</BlockAnnotation>
  <BlockAnnotation pos="0 2 -1" color="#8044DD66" thickness="2" alwaysOnTop="true">Plumbilia (parent)</BlockAnnotation>
  <BlockAnnotation pos="0 2 1" color="#8044DD66" thickness="2" alwaysOnTop="true">Tine (parent)</BlockAnnotation>
</GameScene>

## How to obtain

Bred from:

| Parents | Result pools | Notes |
|---------|--------------|-------|
| [Plumbilia](/crops/plumbilia.md) + [Tine](/crops/tine.md) | `METALLIC`, `SHINY`, `SILVER`, `TENDRILLY`, `WHITE` | crop-stick cross |

Exact per-tick chance depends on soil and the parents' shared pools — check the [web calculator](https://crops-nh.netlify.app/calculator.html).


