---
navigation:
  icon: 'cropsnh:genericSeed{crop:"cropsnh:poppy"}'
  title: Poppy
  parent: /crops.md
  position: 18
---

# Poppy

**Tier:** 2  
**Soil:** [Dirt / Grass](/mechanics/soil-and-blocks.md) — Dirt, Grass, Mycelium variants  
**Likes biomes:** PLAINS, HILLS  
**Alternate seed:** yes — plantable without breeding  
**Pools:** `FLOWER`, `RED`  

## Breeding setup

Full breeding setup — a cross-crop stick in the center on Dirt / Grass, with the parents planted in a line through it (**Blue Orchid** (north), **Waterlily** (south)):

<GameScene zoom={4} interactive={true}>
  <Block id="minecraft:dirt" x="0" y="0" z="0" />
  <Block id="minecraft:dirt" x="0" y="1" z="0" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crossCrop:1b}' x="0" y="2" z="0" />
  <Block id="minecraft:dirt" x="0" y="0" z="-1" />
  <Block id="minecraft:dirt" x="0" y="1" z="-1" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crop:{crop:"cropsnh:blueOrchid",amount:1,gr:1b,ga:1b,re:1b,scan:1b},progress:1000}' x="0" y="2" z="-1" />
  <Block id="minecraft:dirt" x="0" y="0" z="1" />
  <Block id="minecraft:farmland" x="0" y="1" z="1" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crop:{crop:"cropsnh:waterLily",amount:1,gr:1b,ga:1b,re:1b,scan:1b},progress:1000}' x="0" y="2" z="1" />
  <BlockAnnotation pos="0 2 0" color="#80FFAA00" thickness="2" alwaysOnTop="true">Poppy — cross-crop (result grows here)</BlockAnnotation>
  <BlockAnnotation pos="0 2 -1" color="#8044DD66" thickness="2" alwaysOnTop="true">Blue Orchid (parent)</BlockAnnotation>
  <BlockAnnotation pos="0 2 1" color="#8044DD66" thickness="2" alwaysOnTop="true">Waterlily (parent)</BlockAnnotation>
</GameScene>

## How to obtain

Bred from:

| Parents | Result pools | Notes |
|---------|--------------|-------|
| [Blue Orchid](/crops/blueorchid.md) + [Waterlily](/crops/waterlily.md) | `FLOWER`, `RED` | crop-stick cross |

Exact per-tick chance depends on soil and the parents' shared pools — check the [web calculator](https://crops-nh.netlify.app/calculator.html).

## Used to breed

Poppy is a parent in these mutations:

| Produces | With |
|----------|------|
| [Azure Bluet](/crops/azurebluet.md) | [Potato](/crops/potato.md) |
| [Blue Orchid](/crops/blueorchid.md) | [Waterlily](/crops/waterlily.md) |
| [BoP Berry](/crops/bopberry.md) | [Blackberry](/crops/blackberry.md) |
| [Red Granite Lily](/crops/redgranitelily.md) | [Stone Lily](/crops/stonelily.md) |
| [Red Mushroom](/crops/redmushroom.md) | [Pumpkin](/crops/pumpkin.md) |
| [Red Tulip](/crops/redtulip.md) | [White Tulip](/crops/whitetulip.md) |


