---
navigation:
  icon: 'cropsnh:genericSeed{crop:"cropsnh:goldfish"}'
  title: Goldfish
  parent: /crops.md
  position: 16
---

# Goldfish

**Tier:** 4  
**Soil:** [Farmland](/mechanics/soil-and-blocks.md) — Farmland, Enchanted Earth, Ztones Garden Soil, Fertilized Dirt  
**Likes biomes:** RIVER, WET, SPOOKY  
**Alternate seed:** no  
**Pools:** `ADDICTIVE`, `DANGEROUS`, `EDIBLE`, `FISH`, `NETHER`, `WATERY`  

## Breeding setup

Full breeding setup — a cross-crop stick in the center on Farmland, with the parents planted around it (**Waterlily** (north), **Water Artichoke** (south), **Mandrake** (east)):

<GameScene zoom={4} interactive={true}>
  <Block id="minecraft:dirt" x="0" y="0" z="0" />
  <Block id="minecraft:farmland" x="0" y="1" z="0" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crossCrop:1b}' x="0" y="2" z="0" />
  <Block id="minecraft:dirt" x="0" y="0" z="-1" />
  <Block id="minecraft:farmland" x="0" y="1" z="-1" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crop:{crop:"cropsnh:waterLily",amount:1,gr:1b,ga:1b,re:1b,scan:1b},progress:1000}' x="0" y="2" z="-1" />
  <Block id="minecraft:dirt" x="0" y="0" z="1" />
  <Block id="minecraft:farmland" x="0" y="1" z="1" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crop:{crop:"cropsnh:waterArtichoke",amount:1,gr:1b,ga:1b,re:1b,scan:1b},progress:1000}' x="0" y="2" z="1" />
  <Block id="minecraft:dirt" x="1" y="0" z="0" />
  <Block id="minecraft:farmland" x="1" y="1" z="0" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crop:{crop:"cropsnh:mandrake",amount:1,gr:1b,ga:1b,re:1b,scan:1b},progress:1000}' x="1" y="2" z="0" />
  <BlockAnnotation pos="0 2 0" color="#80FFAA00" thickness="2" alwaysOnTop="true">Goldfish — cross-crop (result grows here)</BlockAnnotation>
  <BlockAnnotation pos="0 2 -1" color="#8044DD66" thickness="2" alwaysOnTop="true">Waterlily (parent)</BlockAnnotation>
  <BlockAnnotation pos="0 2 1" color="#8044DD66" thickness="2" alwaysOnTop="true">Water Artichoke (parent)</BlockAnnotation>
  <BlockAnnotation pos="1 2 0" color="#8044DD66" thickness="2" alwaysOnTop="true">Mandrake (parent)</BlockAnnotation>
</GameScene>

## How to obtain

Bred from:

| Parents | Result pools | Notes |
|---------|--------------|-------|
| [Waterlily](/crops/waterlily.md) + [Water Artichoke](/crops/waterartichoke.md) + [Mandrake](/crops/mandrake.md) | `ADDICTIVE`, `DANGEROUS`, `EDIBLE`, `FISH`, `NETHER`, `WATERY` | crop-stick cross |

Exact per-tick chance depends on soil and the parents' shared pools — check the [web calculator](https://crops-nh.netlify.app/calculator.html).

## Used to breed

Goldfish is a parent in these mutations:

| Produces | With |
|----------|------|
| [Ink Bloom](/crops/inkbloom.md) | [Blackberry](/crops/blackberry.md) |
| [Meatrose](/crops/meatrose.md) | [Egg Plant](/crops/eggplant.md) + [Corium](/crops/corium.md) |
| [Tearstalks](/crops/tearstalks.md) | [Soul Sand Lily](/crops/soulsandlily.md) + [Nether Stone Lily](/crops/netherstonelily.md) |


