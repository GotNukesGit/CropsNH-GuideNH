---
navigation:
  icon: 'cropsnh:genericSeed{crop:"cropsnh:brownMushroom"}'
  title: Brown Mushroom
  parent: /crops.md
  position: 19
---

# Brown Mushroom

**Tier:** 1  
**Soil:** [Mushroom Soil](/mechanics/soil-and-blocks.md) — Stone, Dirt/Grass, Mycelium  
**Likes biomes:** MUSHROOM, WET, SWAMP  
**Alternate seed:** yes — plantable without breeding  
**Pools:** `BROWN`, `EDIBLE`, `MUSHROOM`  

## Breeding setup

Full breeding setup — a cross-crop stick in the center on Mushroom Soil, with the parents planted in a line through it (**Cocoa** (north), **Red Mushroom** (south)):

<GameScene zoom={4} interactive={true}>
  <Block id="minecraft:stone" x="0" y="0" z="0" />
  <Block id="minecraft:stone" x="0" y="1" z="0" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crossCrop:1b}' x="0" y="2" z="0" />
  <Block id="minecraft:dirt" x="0" y="0" z="-1" />
  <Block id="minecraft:farmland" x="0" y="1" z="-1" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crop:{crop:"cropsnh:cocoa",amount:1,gr:1b,ga:1b,re:1b,scan:1b},progress:1000}' x="0" y="2" z="-1" />
  <Block id="minecraft:stone" x="0" y="0" z="1" />
  <Block id="minecraft:stone" x="0" y="1" z="1" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crop:{crop:"cropsnh:redMushroom",amount:1,gr:1b,ga:1b,re:1b,scan:1b},progress:1000}' x="0" y="2" z="1" />
  <BlockAnnotation pos="0 2 0" color="#80FFAA00" thickness="2" alwaysOnTop="true">Brown Mushroom — cross-crop (result grows here)</BlockAnnotation>
  <BlockAnnotation pos="0 2 -1" color="#8044DD66" thickness="2" alwaysOnTop="true">Cocoa (parent)</BlockAnnotation>
  <BlockAnnotation pos="0 2 1" color="#8044DD66" thickness="2" alwaysOnTop="true">Red Mushroom (parent)</BlockAnnotation>
</GameScene>

## How to obtain

Bred from:

| Parents | Result pools | Notes |
|---------|--------------|-------|
| [Cocoa](/crops/cocoa.md) + [Red Mushroom](/crops/redmushroom.md) | `BROWN`, `EDIBLE`, `MUSHROOM` | crop-stick cross |

Exact per-tick chance depends on soil and the parents' shared pools — check the [web calculator](https://crops-nh.netlify.app/calculator.html).

## Used to breed

Brown Mushroom is a parent in these mutations:

| Produces | With |
|----------|------|
| [Bonsai Oak](/crops/bonsaioak.md) | [Wheat](/crops/wheat.md) |
| [Nether Wart](/crops/netherwart.md) | [Red Mushroom](/crops/redmushroom.md) |


