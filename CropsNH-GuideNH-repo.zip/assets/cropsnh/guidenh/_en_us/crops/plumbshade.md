---
navigation:
  icon: 'cropsnh:genericSeed{crop:"cropsnh:plumbshade"}'
  title: Plumbshade
  parent: /crops.md
  position: 14
---

# Plumbshade

> [!WARNING]
> **Buried block required.** This crop needs a `lead` block two spaces below the cross-crop stick (directly under the soil). Without it the crop won't grow — see the setup scene below.

**Tier:** 6  
**Soil:** [Stone](/mechanics/soil-and-blocks.md) — Stone, Cobblestone, Stone Brick, Mossy Cobble + Chisel variants  
**Block under soil:** `lead`  
**Likes biomes:** HOT, WET  
**Alternate seed:** no  
**Pools:** `BUSH`, `DENSE`, `LEAD`, `LEAFY`, `METALLIC`, `PURPLE`  

## Breeding setup

Full breeding setup — a cross-crop stick in the center on Stone over a **lead** block, with the parents planted around it (**Azure Bluet** (north), **Malaxia** (south), **Black Granite Lily** (east)):

<GameScene zoom={4} interactive={true}>
  <Block id="gregtech:gt.blockmetal4" meta="2" x="0" y="0" z="0" />
  <Block id="minecraft:stone" x="0" y="1" z="0" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crossCrop:1b}' x="0" y="2" z="0" />
  <Block id="minecraft:dirt" x="0" y="0" z="-1" />
  <Block id="minecraft:dirt" x="0" y="1" z="-1" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crop:{crop:"cropsnh:azureBluet",amount:1,gr:1b,ga:1b,re:1b,scan:1b},progress:1000}' x="0" y="2" z="-1" />
  <Block id="gregtech:gt.blockmetal2" meta="7" x="0" y="0" z="1" />
  <Block id="minecraft:stone" x="0" y="1" z="1" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crop:{crop:"cropsnh:malaxia",amount:1,gr:1b,ga:1b,re:1b,scan:1b},progress:1000}' x="0" y="2" z="1" />
  <Block id="gregtech:gt.blockgranites" meta="0" x="1" y="0" z="0" />
  <Block id="minecraft:stone" x="1" y="1" z="0" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crop:{crop:"cropsnh:blackGraniteLily",amount:1,gr:1b,ga:1b,re:1b,scan:1b},progress:1000}' x="1" y="2" z="0" />
  <BlockAnnotation pos="0 2 0" color="#80FFAA00" thickness="2" alwaysOnTop="true">Plumbshade — cross-crop (result grows here)</BlockAnnotation>
  <BlockAnnotation pos="0 2 -1" color="#8044DD66" thickness="2" alwaysOnTop="true">Azure Bluet (parent)</BlockAnnotation>
  <BlockAnnotation pos="0 2 1" color="#8044DD66" thickness="2" alwaysOnTop="true">Malaxia (parent)</BlockAnnotation>
  <BlockAnnotation pos="1 2 0" color="#8044DD66" thickness="2" alwaysOnTop="true">Black Granite Lily (parent)</BlockAnnotation>
</GameScene>

## How to obtain

Bred from:

| Parents | Result pools | Notes |
|---------|--------------|-------|
| [Azure Bluet](/crops/azurebluet.md) + [Malaxia](/crops/malaxia.md) + [Black Granite Lily](/crops/blackgranitelily.md) | `BUSH`, `DENSE`, `LEAD`, `LEAFY`, `METALLIC`, `PURPLE` | crop-stick cross |

Exact per-tick chance depends on soil and the parents' shared pools — check the [web calculator](https://crops-nh.netlify.app/calculator.html).


