---
navigation:
  icon: 'cropsnh:genericSeed{crop:"cropsnh:steeleafranks"}'
  title: Steeleafranks
  parent: /crops.md
  position: 10
---

# Steeleafranks

> [!WARNING]
> **Buried block required.** This crop needs a `steeleaf` block two spaces below the cross-crop stick (directly under the soil). Without it the crop won't grow — see the setup scene below.

**Tier:** 10  
**Soil:** [Stone](/mechanics/soil-and-blocks.md) — Stone, Cobblestone, Stone Brick, Mossy Cobble + Chisel variants  
**Block under soil:** `steeleaf`  
**Likes biomes:** SPOOKY, DEAD  
**Alternate seed:** no  
**Pools:** `GREEN`, `IRON`, `METALLIC`, `TENDRILLY`, `TWILIGHT_FOREST`  

TwilightForest req

## Breeding setup

Full breeding setup — a cross-crop stick in the center on Stone over a **steeleaf** block, with the parents planted in a line through it (**Torchberry** (north), **Knightmetal Berry** (south)):

<GameScene zoom={4} interactive={true}>
  <Block id="gregtech:gt.blockmetal8" meta="12" x="0" y="0" z="0" />
  <Block id="minecraft:stone" x="0" y="1" z="0" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crossCrop:1b}' x="0" y="2" z="0" />
  <Block id="minecraft:dirt" x="0" y="0" z="-1" />
  <Block id="minecraft:farmland" x="0" y="1" z="-1" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crop:{crop:"cropsnh:torchberry",amount:1,gr:1b,ga:1b,re:1b,scan:1b},progress:1000}' x="0" y="2" z="-1" />
  <Block id="gregtech:gt.blockmetal4" meta="0" x="0" y="0" z="1" />
  <Block id="minecraft:stone" x="0" y="1" z="1" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crop:{crop:"cropsnh:knightmetalBerry",amount:1,gr:1b,ga:1b,re:1b,scan:1b},progress:1000}' x="0" y="2" z="1" />
  <BlockAnnotation pos="0 2 0" color="#80FFAA00" thickness="2" alwaysOnTop="true">Steeleafranks — cross-crop (result grows here)</BlockAnnotation>
  <BlockAnnotation pos="0 2 -1" color="#8044DD66" thickness="2" alwaysOnTop="true">Torchberry (parent)</BlockAnnotation>
  <BlockAnnotation pos="0 2 1" color="#8044DD66" thickness="2" alwaysOnTop="true">Knightmetal Berry (parent)</BlockAnnotation>
</GameScene>

## How to obtain

Bred from:

| Parents | Result pools | Notes |
|---------|--------------|-------|
| [Torchberry](/crops/torchberry.md) + [Knightmetal Berry](/crops/knightmetalberry.md) | `GREEN`, `IRON`, `METALLIC`, `TENDRILLY`, `TWILIGHT_FOREST` | crop-stick cross |

Exact per-tick chance depends on soil and the parents' shared pools — check the [web calculator](https://crops-nh.netlify.app/calculator.html).


