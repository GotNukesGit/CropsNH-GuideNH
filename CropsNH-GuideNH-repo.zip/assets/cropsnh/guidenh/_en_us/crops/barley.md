---
navigation:
  icon: 'cropsnh:genericSeed{crop:"cropsnh:barley"}'
  title: Barley
  parent: /crops.md
  position: 18
---

# Barley

**Tier:** 2  
**Soil:** [Farmland](/mechanics/soil-and-blocks.md) — Farmland, Enchanted Earth, Ztones Garden Soil, Fertilized Dirt  
**Likes biomes:** PLAINS, DRY  
**Alternate seed:** yes — plantable without breeding  
**Pools:** `EDIBLE`, `GREEN`, `WHEAT`  

Natura+BoP req

## Breeding setup

Full breeding setup — a cross-crop stick in the center on Farmland, with the parents planted in a line through it (**Bamboo** (north), **Wheat** (south)):

<GameScene zoom={4} interactive={true}>
  <Block id="minecraft:dirt" x="0" y="0" z="0" />
  <Block id="minecraft:farmland" x="0" y="1" z="0" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crossCrop:1b}' x="0" y="2" z="0" />
  <Block id="minecraft:dirt" x="0" y="0" z="-1" />
  <Block id="minecraft:dirt" x="0" y="1" z="-1" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crop:{crop:"cropsnh:bamboo",amount:1,gr:1b,ga:1b,re:1b,scan:1b},progress:1000}' x="0" y="2" z="-1" />
  <Block id="minecraft:dirt" x="0" y="0" z="1" />
  <Block id="minecraft:farmland" x="0" y="1" z="1" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crop:{crop:"cropsnh:wheat",amount:1,gr:1b,ga:1b,re:1b,scan:1b},progress:1000}' x="0" y="2" z="1" />
  <BlockAnnotation pos="0 2 0" color="#80FFAA00" thickness="2" alwaysOnTop="true">Barley — cross-crop (result grows here)</BlockAnnotation>
  <BlockAnnotation pos="0 2 -1" color="#8044DD66" thickness="2" alwaysOnTop="true">Bamboo (parent)</BlockAnnotation>
  <BlockAnnotation pos="0 2 1" color="#8044DD66" thickness="2" alwaysOnTop="true">Wheat (parent)</BlockAnnotation>
</GameScene>

## How to obtain

Bred from:

| Parents | Result pools | Notes |
|---------|--------------|-------|
| [Bamboo](/crops/bamboo.md) + [Wheat](/crops/wheat.md) | `EDIBLE`, `GREEN`, `WHEAT` | crop-stick cross |

Exact per-tick chance depends on soil and the parents' shared pools — check the [web calculator](https://crops-nh.netlify.app/calculator.html).


