---
navigation:
  icon: 'cropsnh:genericSeed{crop:"cropsnh:shimmerleaf"}'
  title: Shimmerleaf
  parent: /crops.md
  position: 15
---

# Shimmerleaf

> [!WARNING]
> **Buried block required.** This crop needs a `quicksilver` block two spaces below the cross-crop stick (directly under the soil). Without it the crop won't grow — see the setup scene below.

**Tier:** 5  
**Soil:** [Dirt / Grass](/mechanics/soil-and-blocks.md) — Dirt, Grass, Mycelium variants  
**Block under soil:** `quicksilver`  
**Likes biomes:** MAGICAL, LUSH  
**Alternate seed:** yes — plantable without breeding  
**Pools:** `EMISSIVE`, `GRAY`, `MAGICAL`, `POISONOUS`, `SILVER`  

TC req

## Breeding setup

Full breeding setup — a cross-crop stick in the center on Dirt / Grass over a **quicksilver** block, with the parents planted in a line through it (**White Tulip** (north), **Red Straw** (south)):

<GameScene zoom={4} interactive={true}>
  <Block id="thaumicbases:quicksilverBlock" x="0" y="0" z="0" />
  <Block id="minecraft:dirt" x="0" y="1" z="0" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crossCrop:1b}' x="0" y="2" z="0" />
  <Block id="minecraft:dirt" x="0" y="0" z="-1" />
  <Block id="minecraft:dirt" x="0" y="1" z="-1" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crop:{crop:"cropsnh:whiteTulip",amount:1,gr:1b,ga:1b,re:1b,scan:1b},progress:1000}' x="0" y="2" z="-1" />
  <Block id="minecraft:redstone_block" x="0" y="0" z="1" />
  <Block id="minecraft:farmland" x="0" y="1" z="1" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crop:{crop:"cropsnh:redstraw",amount:1,gr:1b,ga:1b,re:1b,scan:1b},progress:1000}' x="0" y="2" z="1" />
  <BlockAnnotation pos="0 2 0" color="#80FFAA00" thickness="2" alwaysOnTop="true">Shimmerleaf — cross-crop (result grows here)</BlockAnnotation>
  <BlockAnnotation pos="0 2 -1" color="#8044DD66" thickness="2" alwaysOnTop="true">White Tulip (parent)</BlockAnnotation>
  <BlockAnnotation pos="0 2 1" color="#8044DD66" thickness="2" alwaysOnTop="true">Red Straw (parent)</BlockAnnotation>
</GameScene>

## How to obtain

Bred from:

| Parents | Result pools | Notes |
|---------|--------------|-------|
| [White Tulip](/crops/whitetulip.md) + [Red Straw](/crops/redstraw.md) | `EMISSIVE`, `GRAY`, `MAGICAL`, `POISONOUS`, `SILVER` | crop-stick cross |

Exact per-tick chance depends on soil and the parents' shared pools — check the [web calculator](https://crops-nh.netlify.app/calculator.html).

## Used to breed

Shimmerleaf is a parent in these mutations:

| Produces | With |
|----------|------|
| [Mana Bean](/crops/manabean.md) | [Cocoa](/crops/cocoa.md) + [Cinderpearl](/crops/cinderpearl.md) |
| [Magical Nightshade](/crops/magicalnightshade.md) | [Primordial Berry](/crops/primordialberry.md) + [Mana Bean](/crops/manabean.md) + [Cinderpearl](/crops/cinderpearl.md) |


