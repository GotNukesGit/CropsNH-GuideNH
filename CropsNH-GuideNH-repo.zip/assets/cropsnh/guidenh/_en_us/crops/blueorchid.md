---
navigation:
  icon: 'cropsnh:genericSeed{crop:"cropsnh:blueOrchid"}'
  title: Blue Orchid
  parent: /crops.md
  position: 18
---

# Blue Orchid

**Tier:** 2  
**Soil:** [Dirt / Grass](/mechanics/soil-and-blocks.md) — Dirt, Grass, Mycelium variants  
**Likes biomes:** WET, SWAMP  
**Alternate seed:** yes — plantable without breeding  
**Pools:** `BLUE`, `FLOWER`  

## Breeding setup

Full breeding setup — a cross-crop stick in the center on Dirt / Grass, with the parents planted in a line through it (**Poppy** (north), **Waterlily** (south)):

<GameScene zoom={4} interactive={true}>
  <Block id="minecraft:dirt" x="0" y="0" z="0" />
  <Block id="minecraft:dirt" x="0" y="1" z="0" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crossCrop:1b}' x="0" y="2" z="0" />
  <Block id="minecraft:dirt" x="0" y="0" z="-1" />
  <Block id="minecraft:dirt" x="0" y="1" z="-1" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crop:{crop:"cropsnh:poppy",amount:1,gr:1b,ga:1b,re:1b,scan:1b},progress:1000}' x="0" y="2" z="-1" />
  <Block id="minecraft:dirt" x="0" y="0" z="1" />
  <Block id="minecraft:farmland" x="0" y="1" z="1" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crop:{crop:"cropsnh:waterLily",amount:1,gr:1b,ga:1b,re:1b,scan:1b},progress:1000}' x="0" y="2" z="1" />
  <BlockAnnotation pos="0 2 0" color="#80FFAA00" thickness="2" alwaysOnTop="true">Blue Orchid — cross-crop (result grows here)</BlockAnnotation>
  <BlockAnnotation pos="0 2 -1" color="#8044DD66" thickness="2" alwaysOnTop="true">Poppy (parent)</BlockAnnotation>
  <BlockAnnotation pos="0 2 1" color="#8044DD66" thickness="2" alwaysOnTop="true">Waterlily (parent)</BlockAnnotation>
</GameScene>

## How to obtain

Bred from:

| Parents | Result pools | Notes |
|---------|--------------|-------|
| [Poppy](/crops/poppy.md) + [Waterlily](/crops/waterlily.md) | — | crop-stick cross |

Exact per-tick chance depends on soil and the parents' shared pools — check the [web calculator](https://crops-nh.netlify.app/calculator.html).

## Used to breed

Blue Orchid is a parent in these mutations:

| Produces | With |
|----------|------|
| [Dayflower](/crops/dayflower.md) | [Azure Bluet](/crops/azurebluet.md) |
| [Indigo](/crops/indigo.md) | [Dayflower](/crops/dayflower.md) |
| [Poppy](/crops/poppy.md) | [Waterlily](/crops/waterlily.md) |
| [Purple Glowshroom](/crops/purpleglowshroom.md) | [Blue Glowshroom](/crops/blueglowshroom.md) + [Glowflower](/crops/glowflower.md) |
| [Purple Tulip](/crops/purpletulip.md) | [Red Tulip](/crops/redtulip.md) |
| [Slimeplant](/crops/slimeplant.md) | [Clay Lily](/crops/claylily.md) |
| [Vine](/crops/vine.md) | [Pumpkin](/crops/pumpkin.md) |


