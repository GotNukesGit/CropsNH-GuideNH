---
navigation:
  icon: 'cropsnh:genericSeed{crop:"cropsnh:thaumiumOreBerry"}'
  title: Thaumium Ore Berry
  parent: /crops.md
  position: 13
---

# Thaumium Ore Berry

> [!NOTE]
> **Directly obtainable.** No breeding recipe — plant it from a seed you can get by other means

> [!WARNING]
> **Buried block required.** This crop needs a `thaumium` block two spaces below the cross-crop stick (directly under the soil). Without it the crop won't grow — see the setup scene below.

**Tier:** 7  
**Soil:** [Stone](/mechanics/soil-and-blocks.md) — Stone, Cobblestone, Stone Brick, Mossy Cobble + Chisel variants  
**Block under soil:** `thaumium`  
**Likes biomes:** MAGICAL, SPOOKY  
**Alternate seed:** no  
**Pools:** `DANGEROUS`, `MAGICAL`, `METALLIC`, `ORE_BERRY`, `PURPLE`, `VOID_TOUCHED`  

TiC+TC req

## Setup

Grow **Thaumium Ore Berry** on Stone with a **thaumium** block two spaces below the crop stick:

<GameScene zoom={4} interactive={true}>
  <Block id="gregtech:gt.blockmetal7" meta="4" x="0" y="0" z="0" />
  <Block id="minecraft:stone" x="0" y="1" z="0" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crop:{crop:"cropsnh:thaumiumOreBerry",amount:1,gr:1b,ga:1b,re:1b,scan:1b},progress:1000}' x="0" y="2" z="0" />
  <BlockAnnotation pos="0 2 0" color="#8044DD66" thickness="2" alwaysOnTop="true">Thaumium Ore Berry</BlockAnnotation>
</GameScene>

## How to obtain

No breeding recipe — obtain the seed directly.

## Used to breed

Thaumium Ore Berry is a parent in these mutations:

| Produces | With |
|----------|------|
| [Thauminite Ore Berry](/crops/thauminiteoreberry.md) | [Mana Bean](/crops/manabean.md) |
| [Void Ore Berry](/crops/voidoreberry.md) | [Stone Lily](/crops/stonelily.md) + [Gold Ore Berry](/crops/goldoreberry.md) |


