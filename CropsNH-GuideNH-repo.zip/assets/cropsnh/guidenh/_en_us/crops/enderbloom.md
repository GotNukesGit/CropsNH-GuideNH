---
navigation:
  icon: 'cropsnh:genericSeed{crop:"cropsnh:enderbloom"}'
  title: Enderbloom
  parent: /crops.md
  position: 10
---

# Enderbloom

> [!WARNING]
> **Buried block required.** This crop needs a `endStone` block two spaces below the cross-crop stick (directly under the soil). Without it the crop won't grow — see the setup scene below.

**Tier:** 10  
**Soil:** [Farmland](/mechanics/soil-and-blocks.md) — Farmland, Enchanted Earth, Ztones Garden Soil, Fertilized Dirt  
**Block under soil:** `endStone`  
**Likes biomes:** END, COLD  
**Alternate seed:** no  
**Pools:** `ALIEN`, `FLOWER`, `MAGICAL`, `SHINY`  

## Breeding setup

Full breeding setup — a cross-crop stick in the center on Farmland over a **endStone** block, with the parents planted in a line through it (**End Stone Lily** (north), **Creeperweed** (south)):

<GameScene zoom={4} interactive={true}>
  <Block id="minecraft:end_stone" x="0" y="0" z="0" />
  <Block id="minecraft:farmland" x="0" y="1" z="0" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crossCrop:1b}' x="0" y="2" z="0" />
  <Block id="minecraft:end_stone" x="0" y="0" z="-1" />
  <Block id="minecraft:stone" x="0" y="1" z="-1" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crop:{crop:"cropsnh:endStoneLily",amount:1,gr:1b,ga:1b,re:1b,scan:1b},progress:1000}' x="0" y="2" z="-1" />
  <Block id="minecraft:dirt" x="0" y="0" z="1" />
  <Block id="minecraft:farmland" x="0" y="1" z="1" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crop:{crop:"cropsnh:creeperweed",amount:1,gr:1b,ga:1b,re:1b,scan:1b},progress:1000}' x="0" y="2" z="1" />
  <BlockAnnotation pos="0 2 0" color="#80FFAA00" thickness="2" alwaysOnTop="true">Enderbloom — cross-crop (result grows here)</BlockAnnotation>
  <BlockAnnotation pos="0 2 -1" color="#8044DD66" thickness="2" alwaysOnTop="true">End Stone Lily (parent)</BlockAnnotation>
  <BlockAnnotation pos="0 2 1" color="#8044DD66" thickness="2" alwaysOnTop="true">Creeperweed (parent)</BlockAnnotation>
</GameScene>

## How to obtain

Bred from:

| Parents | Result pools | Notes |
|---------|--------------|-------|
| [End Stone Lily](/crops/endstonelily.md) + [Creeperweed](/crops/creeperweed.md) | `ALIEN`, `FLOWER`, `MAGICAL`, `SHINY` | crop-stick cross |

Exact per-tick chance depends on soil and the parents' shared pools — check the [web calculator](https://crops-nh.netlify.app/calculator.html).

## Used to breed

Enderbloom is a parent in these mutations:

| Produces | With |
|----------|------|
| [End Stone Lily](/crops/endstonelily.md) | [Stone Lily](/crops/stonelily.md) |


