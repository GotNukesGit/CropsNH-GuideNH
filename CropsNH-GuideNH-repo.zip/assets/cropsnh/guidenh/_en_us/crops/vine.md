---
navigation:
  icon: 'cropsnh:genericSeed{crop:"cropsnh:vine"}'
  title: Vine
  parent: /crops.md
  position: 18
---

# Vine

**Tier:** 2  
**Soil:** [Farmland](/mechanics/soil-and-blocks.md) — Farmland, Enchanted Earth, Ztones Garden Soil, Fertilized Dirt  
**Likes biomes:** LUSH, JUNGLE, WET  
**Alternate seed:** yes — plantable without breeding  
**Pools:** `CLIMBABLE`, `GREEN`, `TENDRILLY`  

## Breeding setup

Full breeding setup — a cross-crop stick in the center on Farmland, with the parents planted in a line through it (**Pumpkin** (north), **Blue Orchid** (south)):

<GameScene zoom={4} interactive={true}>
  <Block id="minecraft:dirt" x="0" y="0" z="0" />
  <Block id="minecraft:farmland" x="0" y="1" z="0" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crossCrop:1b}' x="0" y="2" z="0" />
  <Block id="minecraft:dirt" x="0" y="0" z="-1" />
  <Block id="minecraft:farmland" x="0" y="1" z="-1" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crop:{crop:"cropsnh:pumpkin",amount:1,gr:1b,ga:1b,re:1b,scan:1b},progress:1000}' x="0" y="2" z="-1" />
  <Block id="minecraft:dirt" x="0" y="0" z="1" />
  <Block id="minecraft:dirt" x="0" y="1" z="1" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crop:{crop:"cropsnh:blueOrchid",amount:1,gr:1b,ga:1b,re:1b,scan:1b},progress:1000}' x="0" y="2" z="1" />
  <BlockAnnotation pos="0 2 0" color="#80FFAA00" thickness="2" alwaysOnTop="true">Vine — cross-crop (result grows here)</BlockAnnotation>
  <BlockAnnotation pos="0 2 -1" color="#8044DD66" thickness="2" alwaysOnTop="true">Pumpkin (parent)</BlockAnnotation>
  <BlockAnnotation pos="0 2 1" color="#8044DD66" thickness="2" alwaysOnTop="true">Blue Orchid (parent)</BlockAnnotation>
</GameScene>

## How to obtain

Bred from:

| Parents | Result pools | Notes |
|---------|--------------|-------|
| [Pumpkin](/crops/pumpkin.md) + [Blue Orchid](/crops/blueorchid.md) | `CLIMBABLE`, `GREEN`, `TENDRILLY` | crop-stick cross |

Exact per-tick chance depends on soil and the parents' shared pools — check the [web calculator](https://crops-nh.netlify.app/calculator.html).

## Used to breed

Vine is a parent in these mutations:

| Produces | With |
|----------|------|
| [Bamboo](/crops/bamboo.md) | [Bonsai Jungle](/crops/bonsaijungle.md) |
| [Bonsai Jungle](/crops/bonsaijungle.md) | [Bonsai Oak](/crops/bonsaioak.md) |
| [Glint Weed](/crops/glintweed.md) | [Ember Moss](/crops/embermoss.md) |
| [Ivy](/crops/ivy.md) | [Bonsai Spruce](/crops/bonsaispruce.md) |
| [Stone Lily](/crops/stonelily.md) | [Pumpkin](/crops/pumpkin.md) |
| [Thornvine](/crops/thornvine.md) | [Cactus](/crops/cactus.md) |
| [Waterlily](/crops/waterlily.md) | [Sugar Cane](/crops/sugarcane.md) |


