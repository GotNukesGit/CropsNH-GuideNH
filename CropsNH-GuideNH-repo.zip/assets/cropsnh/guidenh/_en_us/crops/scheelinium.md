---
navigation:
  icon: 'cropsnh:genericSeed{crop:"cropsnh:scheelinium"}'
  title: Scheelinium
  parent: /crops.md
  position: 8
---

# Scheelinium

> [!NOTE]
> **Machine-only.** Produced by a machine process, not by breeding on crop sticks.

> [!WARNING]
> **Buried block required.** This crop needs a `tungsten` block two spaces below the cross-crop stick (directly under the soil). Without it the crop won't grow — see the setup scene below.

**Tier:** 12  
**Soil:** [Stone](/mechanics/soil-and-blocks.md) — Stone, Cobblestone, Stone Brick, Mossy Cobble + Chisel variants  
**Block under soil:** `tungsten`  
**Likes biomes:** OCEAN, WET, COLD  
**Alternate seed:** no  

Crop Synthesizer only. Requires tungsten block y-2. EV+ machine tier.

## Breeding setup

Full breeding setup — a cross-crop stick in the center on Stone over a **tungsten** block, with the parents planted around it (**Titania** (north), **Pyrolusium** (south), **End Stone Lily** (east)):

<GameScene zoom={4} interactive={true}>
  <Block id="gregtech:gt.blockmetal7" meta="11" x="0" y="0" z="0" />
  <Block id="minecraft:stone" x="0" y="1" z="0" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crossCrop:1b}' x="0" y="2" z="0" />
  <Block id="gregtech:gt.blockmetal7" meta="9" x="0" y="0" z="-1" />
  <Block id="minecraft:stone" x="0" y="1" z="-1" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crop:{crop:"cropsnh:titania",amount:1,gr:1b,ga:1b,re:1b,scan:1b},progress:1000}' x="0" y="2" z="-1" />
  <Block id="gregtech:gt.blockmetal4" meta="6" x="0" y="0" z="1" />
  <Block id="minecraft:stone" x="0" y="1" z="1" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crop:{crop:"cropsnh:pyrolusium",amount:1,gr:1b,ga:1b,re:1b,scan:1b},progress:1000}' x="0" y="2" z="1" />
  <Block id="minecraft:end_stone" x="1" y="0" z="0" />
  <Block id="minecraft:stone" x="1" y="1" z="0" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crop:{crop:"cropsnh:endStoneLily",amount:1,gr:1b,ga:1b,re:1b,scan:1b},progress:1000}' x="1" y="2" z="0" />
  <BlockAnnotation pos="0 2 0" color="#80FFAA00" thickness="2" alwaysOnTop="true">Scheelinium — cross-crop (result grows here)</BlockAnnotation>
  <BlockAnnotation pos="0 2 -1" color="#8044DD66" thickness="2" alwaysOnTop="true">Titania (parent)</BlockAnnotation>
  <BlockAnnotation pos="0 2 1" color="#8044DD66" thickness="2" alwaysOnTop="true">Pyrolusium (parent)</BlockAnnotation>
  <BlockAnnotation pos="1 2 0" color="#8044DD66" thickness="2" alwaysOnTop="true">End Stone Lily (parent)</BlockAnnotation>
</GameScene>

## How to obtain

Bred from:

| Parents | Result pools | Notes |
|---------|--------------|-------|
| [Titania](/crops/titania.md) + [Pyrolusium](/crops/pyrolusium.md) + [End Stone Lily](/crops/endstonelily.md) | `STONE` | machine recipe |

Exact per-tick chance depends on soil and the parents' shared pools — check the [web calculator](https://crops-nh.netlify.app/calculator.html).

## Used to breed

Scheelinium is a parent in these mutations:

| Produces | With |
|----------|------|
| [Iridine](/crops/iridine.md) | [Platina](/crops/platina.md) |
| [Osmianth](/crops/osmianth.md) | [Platina](/crops/platina.md) |


