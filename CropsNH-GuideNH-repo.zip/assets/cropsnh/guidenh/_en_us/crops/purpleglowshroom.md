---
navigation:
  icon: 'cropsnh:genericSeed{crop:"cropsnh:purpleGlowshroom"}'
  title: Purple Glowshroom
  parent: /crops.md
  position: 17
---

# Purple Glowshroom

**Tier:** 3  
**Soil:** [Nether Mushroom Soil](/mechanics/soil-and-blocks.md) — Stone, Dirt, Mycelium, Netherrack  
**Alternate seed:** no  
**Pools:** `EDIBLE`, `EMISSIVE`, `MUSHROOM`, `NETHER`, `POTION_INGREDIENT`, `PURPLE`  

Natura req

## Breeding setup

Full breeding setup — a cross-crop stick in the center on Nether Mushroom Soil, with the parents planted around it (**Blue Glowshroom** (north), **Blue Orchid** (south), **Glowflower** (east)):

<GameScene zoom={4} interactive={true}>
  <Block id="minecraft:netherrack" x="0" y="0" z="0" />
  <Block id="minecraft:netherrack" x="0" y="1" z="0" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crossCrop:1b}' x="0" y="2" z="0" />
  <Block id="minecraft:netherrack" x="0" y="0" z="-1" />
  <Block id="minecraft:netherrack" x="0" y="1" z="-1" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crop:{crop:"cropsnh:blueGlowshroom",amount:1,gr:1b,ga:1b,re:1b,scan:1b},progress:1000}' x="0" y="2" z="-1" />
  <Block id="minecraft:dirt" x="0" y="0" z="1" />
  <Block id="minecraft:dirt" x="0" y="1" z="1" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crop:{crop:"cropsnh:blueOrchid",amount:1,gr:1b,ga:1b,re:1b,scan:1b},progress:1000}' x="0" y="2" z="1" />
  <Block id="minecraft:dirt" x="1" y="0" z="0" />
  <Block id="minecraft:dirt" x="1" y="1" z="0" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crop:{crop:"cropsnh:glowflower",amount:1,gr:1b,ga:1b,re:1b,scan:1b},progress:1000}' x="1" y="2" z="0" />
  <BlockAnnotation pos="0 2 0" color="#80FFAA00" thickness="2" alwaysOnTop="true">Purple Glowshroom — cross-crop (result grows here)</BlockAnnotation>
  <BlockAnnotation pos="0 2 -1" color="#8044DD66" thickness="2" alwaysOnTop="true">Blue Glowshroom (parent)</BlockAnnotation>
  <BlockAnnotation pos="0 2 1" color="#8044DD66" thickness="2" alwaysOnTop="true">Blue Orchid (parent)</BlockAnnotation>
  <BlockAnnotation pos="1 2 0" color="#8044DD66" thickness="2" alwaysOnTop="true">Glowflower (parent)</BlockAnnotation>
</GameScene>

## How to obtain

Bred from:

| Parents | Result pools | Notes |
|---------|--------------|-------|
| [Blue Glowshroom](/crops/blueglowshroom.md) + [Blue Orchid](/crops/blueorchid.md) + [Glowflower](/crops/glowflower.md) | `EDIBLE`, `EMISSIVE`, `MUSHROOM`, `NETHER`, `POTION_INGREDIENT`, `PURPLE` | crop-stick cross |

Exact per-tick chance depends on soil and the parents' shared pools — check the [web calculator](https://crops-nh.netlify.app/calculator.html).

## Used to breed

Purple Glowshroom is a parent in these mutations:

| Produces | With |
|----------|------|
| [Glowshroom](/crops/glowshroom.md) | [Blue Glowshroom](/crops/blueglowshroom.md) + [Green Glowshroom](/crops/greenglowshroom.md) |


