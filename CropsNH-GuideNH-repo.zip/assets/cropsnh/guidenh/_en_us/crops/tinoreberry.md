---
navigation:
  icon: 'cropsnh:genericSeed{crop:"cropsnh:tinOreBerry"}'
  title: Tin Ore Berry
  parent: /crops.md
  position: 16
---

# Tin Ore Berry

> [!WARNING]
> **Buried block required.** This crop needs a `tin` block two spaces below the cross-crop stick (directly under the soil). Without it the crop won't grow — see the setup scene below.

**Tier:** 4  
**Soil:** [Stone](/mechanics/soil-and-blocks.md) — Stone, Cobblestone, Stone Brick, Mossy Cobble + Chisel variants  
**Block under soil:** `tin`  
**Likes biomes:** MOUNTAIN, HILLS  
**Alternate seed:** yes — plantable without breeding  
**Pools:** `DANGEROUS`, `METALLIC`, `ORE_BERRY`, `SHINY`, `TIN`, `WHITE`  

TiC req

## Breeding setup

Full breeding setup — a cross-crop stick in the center on Stone over a **tin** block, with the parents planted around it (**Cassitine** (north), **BoP Berry** (south), **Stone Lily** (east)):

<GameScene zoom={4} interactive={true}>
  <Block id="gregtech:gt.blockmetal7" meta="7" x="0" y="0" z="0" />
  <Block id="minecraft:stone" x="0" y="1" z="0" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crossCrop:1b}' x="0" y="2" z="0" />
  <Block id="gregtech:gt.blockmetal7" meta="7" x="0" y="0" z="-1" />
  <Block id="minecraft:stone" x="0" y="1" z="-1" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crop:{crop:"cropsnh:cassitine",amount:1,gr:1b,ga:1b,re:1b,scan:1b},progress:1000}' x="0" y="2" z="-1" />
  <Block id="minecraft:dirt" x="0" y="0" z="1" />
  <Block id="minecraft:farmland" x="0" y="1" z="1" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crop:{crop:"cropsnh:bopBerry",amount:1,gr:1b,ga:1b,re:1b,scan:1b},progress:1000}' x="0" y="2" z="1" />
  <Block id="minecraft:stone" x="1" y="0" z="0" />
  <Block id="minecraft:stone" x="1" y="1" z="0" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crop:{crop:"cropsnh:stoneLily",amount:1,gr:1b,ga:1b,re:1b,scan:1b},progress:1000}' x="1" y="2" z="0" />
  <BlockAnnotation pos="0 2 0" color="#80FFAA00" thickness="2" alwaysOnTop="true">Tin Ore Berry — cross-crop (result grows here)</BlockAnnotation>
  <BlockAnnotation pos="0 2 -1" color="#8044DD66" thickness="2" alwaysOnTop="true">Cassitine (parent)</BlockAnnotation>
  <BlockAnnotation pos="0 2 1" color="#8044DD66" thickness="2" alwaysOnTop="true">BoP Berry (parent)</BlockAnnotation>
  <BlockAnnotation pos="1 2 0" color="#8044DD66" thickness="2" alwaysOnTop="true">Stone Lily (parent)</BlockAnnotation>
</GameScene>

## How to obtain

Bred from:

| Parents | Result pools | Notes |
|---------|--------------|-------|
| [Cassitine](/crops/cassitine.md) + [BoP Berry](/crops/bopberry.md) + [Stone Lily](/crops/stonelily.md) | `DANGEROUS`, `METALLIC`, `ORE_BERRY`, `SHINY`, `TIN`, `WHITE` | crop-stick cross |

Exact per-tick chance depends on soil and the parents' shared pools — check the [web calculator](https://crops-nh.netlify.app/calculator.html).

## Used to breed

Tin Ore Berry is a parent in these mutations:

| Produces | With |
|----------|------|
| [Gold Ore Berry](/crops/goldoreberry.md) | [Copper Ore Berry](/crops/copperoreberry.md) + [Iron Ore Berry](/crops/ironoreberry.md) |
| [Iron Ore Berry](/crops/ironoreberry.md) | [Stone Lily](/crops/stonelily.md) |


