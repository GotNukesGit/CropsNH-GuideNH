---
navigation:
  icon: 'cropsnh:genericSeed{crop:"cropsnh:emberMoss"}'
  title: Ember Moss
  parent: /crops.md
  position: 13
---

# Ember Moss

**Tier:** 7  
**Soil:** [Farmland](/mechanics/soil-and-blocks.md) — Farmland, Enchanted Earth, Ztones Garden Soil, Fertilized Dirt  
**Likes biomes:** HOT, DRY  
**Alternate seed:** yes — plantable without breeding  
**Pools:** `CLIMBABLE`, `DANGEROUS`, `FIERY`, `POTION_INGREDIENT`, `RED`, `TENDRILLY`  

Witchery req

## Breeding setup

Full breeding setup — a cross-crop stick in the center on Farmland, with the parents planted in a line through it (**Red Tulip** (north), **Moss** (south)):

<GameScene zoom={4} interactive={true}>
  <Block id="minecraft:dirt" x="0" y="0" z="0" />
  <Block id="minecraft:farmland" x="0" y="1" z="0" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crossCrop:1b}' x="0" y="2" z="0" />
  <Block id="minecraft:dirt" x="0" y="0" z="-1" />
  <Block id="minecraft:dirt" x="0" y="1" z="-1" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crop:{crop:"cropsnh:redTulip",amount:1,gr:1b,ga:1b,re:1b,scan:1b},progress:1000}' x="0" y="2" z="-1" />
  <Block id="minecraft:dirt" x="0" y="0" z="1" />
  <Block id="minecraft:farmland" x="0" y="1" z="1" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crop:{crop:"cropsnh:moss",amount:1,gr:1b,ga:1b,re:1b,scan:1b},progress:1000}' x="0" y="2" z="1" />
  <BlockAnnotation pos="0 2 0" color="#80FFAA00" thickness="2" alwaysOnTop="true">Ember Moss — cross-crop (result grows here)</BlockAnnotation>
  <BlockAnnotation pos="0 2 -1" color="#8044DD66" thickness="2" alwaysOnTop="true">Red Tulip (parent)</BlockAnnotation>
  <BlockAnnotation pos="0 2 1" color="#8044DD66" thickness="2" alwaysOnTop="true">Moss (parent)</BlockAnnotation>
</GameScene>

## How to obtain

Bred from:

| Parents | Result pools | Notes |
|---------|--------------|-------|
| [Red Tulip](/crops/redtulip.md) + [Moss](/crops/moss.md) | `CLIMBABLE`, `DANGEROUS`, `FIERY`, `POTION_INGREDIENT`, `RED`, `TENDRILLY` | crop-stick cross |

Exact per-tick chance depends on soil and the parents' shared pools — check the [web calculator](https://crops-nh.netlify.app/calculator.html).

## Used to breed

Ember Moss is a parent in these mutations:

| Produces | With |
|----------|------|
| [Cinderpearl](/crops/cinderpearl.md) | [Glint Weed](/crops/glintweed.md) |
| [Glint Weed](/crops/glintweed.md) | [Vine](/crops/vine.md) |
| [Spanish Moss](/crops/spanishmoss.md) | [Moss](/crops/moss.md) |


