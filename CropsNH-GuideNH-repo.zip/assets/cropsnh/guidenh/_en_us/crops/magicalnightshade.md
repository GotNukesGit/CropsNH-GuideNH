---
navigation:
  icon: 'cropsnh:genericSeed{crop:"cropsnh:magicalNightshade"}'
  title: Magical Nightshade
  parent: /crops.md
  position: 7
---

# Magical Nightshade

> [!NOTE]
> **Machine-only.** Produced by a machine process, not by breeding on crop sticks.

> [!WARNING]
> **Buried block required.** This crop needs a `shadowmetal` block two spaces below the cross-crop stick (directly under the soil). Without it the crop won't grow — see the setup scene below.

**Tier:** 13  
**Soil:** [Farmland](/mechanics/soil-and-blocks.md) — Farmland, Enchanted Earth, Ztones Garden Soil, Fertilized Dirt  
**Block under soil:** `shadowmetal`  
**Likes biomes:** MAGICAL, COLD  
**Alternate seed:** yes — plantable without breeding  

Has alternate seed (CropsNH magic essence item). Also obtainable via Crop Breeder. Requires shadowmetal block y-2. Magical + Cold biomes.

## Breeding setup

Full breeding setup — a cross-crop stick in the center on Farmland over a **shadowmetal** block, with the parents planted around it (**Primordial Berry** (north), **Mana Bean** (south), **Cinderpearl** (east), **Shimmerleaf** (west)):

<GameScene zoom={4} interactive={true}>
  <Block id="gregtech:gt.blockmetal8" meta="15" x="0" y="0" z="0" />
  <Block id="minecraft:farmland" x="0" y="1" z="0" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crossCrop:1b}' x="0" y="2" z="0" />
  <Block id="minecraft:dirt" x="0" y="0" z="-1" />
  <Block id="minecraft:farmland" x="0" y="1" z="-1" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crop:{crop:"cropsnh:primordialBerry",amount:1,gr:1b,ga:1b,re:1b,scan:1b},progress:1000}' x="0" y="2" z="-1" />
  <Block id="Thaumcraft:blockCrystal" meta="6" x="0" y="0" z="1" />
  <Block id="minecraft:log" x="0" y="1" z="1" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crop:{crop:"cropsnh:manaBean",amount:1,gr:1b,ga:1b,re:1b,scan:1b},progress:1000}' x="0" y="2" z="1" />
  <Block id="gregtech:gt.blockgem3" meta="5" x="1" y="0" z="0" />
  <Block id="minecraft:dirt" x="1" y="1" z="0" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crop:{crop:"cropsnh:cinderpearl",amount:1,gr:1b,ga:1b,re:1b,scan:1b},progress:1000}' x="1" y="2" z="0" />
  <Block id="thaumicbases:quicksilverBlock" x="-1" y="0" z="0" />
  <Block id="minecraft:dirt" x="-1" y="1" z="0" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crop:{crop:"cropsnh:shimmerleaf",amount:1,gr:1b,ga:1b,re:1b,scan:1b},progress:1000}' x="-1" y="2" z="0" />
  <BlockAnnotation pos="0 2 0" color="#80FFAA00" thickness="2" alwaysOnTop="true">Magical Nightshade — cross-crop (result grows here)</BlockAnnotation>
  <BlockAnnotation pos="0 2 -1" color="#8044DD66" thickness="2" alwaysOnTop="true">Primordial Berry (parent)</BlockAnnotation>
  <BlockAnnotation pos="0 2 1" color="#8044DD66" thickness="2" alwaysOnTop="true">Mana Bean (parent)</BlockAnnotation>
  <BlockAnnotation pos="1 2 0" color="#8044DD66" thickness="2" alwaysOnTop="true">Cinderpearl (parent)</BlockAnnotation>
  <BlockAnnotation pos="-1 2 0" color="#8044DD66" thickness="2" alwaysOnTop="true">Shimmerleaf (parent)</BlockAnnotation>
</GameScene>

## How to obtain

Bred from:

| Parents | Result pools | Notes |
|---------|--------------|-------|
| [Primordial Berry](/crops/primordialberry.md) + [Mana Bean](/crops/manabean.md) + [Cinderpearl](/crops/cinderpearl.md) + [Shimmerleaf](/crops/shimmerleaf.md) | `MAGICAL` | machine recipe |

Exact per-tick chance depends on soil and the parents' shared pools — check the [web calculator](https://crops-nh.netlify.app/calculator.html).


