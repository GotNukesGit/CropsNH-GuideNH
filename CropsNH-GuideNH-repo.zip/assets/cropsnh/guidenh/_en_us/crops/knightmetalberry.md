---
navigation:
  icon: 'cropsnh:genericSeed{crop:"cropsnh:knightmetalBerry"}'
  title: Knightmetal Berry
  parent: /crops.md
  position: 12
---

# Knightmetal Berry

> [!WARNING]
> **Buried block required.** This crop needs a `knightmetal` block two spaces below the cross-crop stick (directly under the soil). Without it the crop won't grow — see the setup scene below.

**Tier:** 8  
**Soil:** [Stone](/mechanics/soil-and-blocks.md) — Stone, Cobblestone, Stone Brick, Mossy Cobble + Chisel variants  
**Block under soil:** `knightmetal`  
**Likes biomes:** SPOOKY, DEAD  
**Alternate seed:** no  
**Pools:** `DANGEROUS`, `GRAY`, `METALLIC`, `ORE_BERRY`, `TWILIGHT_FOREST`  

TiC+TF req

## Breeding setup

Full breeding setup — a cross-crop stick in the center on Stone over a **knightmetal** block, with the parents planted around it (**Iron Ore Berry** (north), **Torchberry** (south), **Bonsai Dark Oak** (east)):

<GameScene zoom={4} interactive={true}>
  <Block id="gregtech:gt.blockmetal4" meta="0" x="0" y="0" z="0" />
  <Block id="minecraft:stone" x="0" y="1" z="0" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crossCrop:1b}' x="0" y="2" z="0" />
  <Block id="minecraft:iron_block" x="0" y="0" z="-1" />
  <Block id="minecraft:stone" x="0" y="1" z="-1" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crop:{crop:"cropsnh:ironOreBerry",amount:1,gr:1b,ga:1b,re:1b,scan:1b},progress:1000}' x="0" y="2" z="-1" />
  <Block id="minecraft:dirt" x="0" y="0" z="1" />
  <Block id="minecraft:farmland" x="0" y="1" z="1" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crop:{crop:"cropsnh:torchberry",amount:1,gr:1b,ga:1b,re:1b,scan:1b},progress:1000}' x="0" y="2" z="1" />
  <Block id="minecraft:dirt" x="1" y="0" z="0" />
  <Block id="minecraft:dirt" x="1" y="1" z="0" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crop:{crop:"cropsnh:bonsaiDarkOak",amount:1,gr:1b,ga:1b,re:1b,scan:1b},progress:1000}' x="1" y="2" z="0" />
  <BlockAnnotation pos="0 2 0" color="#80FFAA00" thickness="2" alwaysOnTop="true">Knightmetal Berry — cross-crop (result grows here)</BlockAnnotation>
  <BlockAnnotation pos="0 2 -1" color="#8044DD66" thickness="2" alwaysOnTop="true">Iron Ore Berry (parent)</BlockAnnotation>
  <BlockAnnotation pos="0 2 1" color="#8044DD66" thickness="2" alwaysOnTop="true">Torchberry (parent)</BlockAnnotation>
  <BlockAnnotation pos="1 2 0" color="#8044DD66" thickness="2" alwaysOnTop="true">Bonsai Dark Oak (parent)</BlockAnnotation>
</GameScene>

## How to obtain

Bred from:

| Parents | Result pools | Notes |
|---------|--------------|-------|
| [Iron Ore Berry](/crops/ironoreberry.md) + [Torchberry](/crops/torchberry.md) + [Bonsai Dark Oak](/crops/bonsaidarkoak.md) | `DANGEROUS`, `GRAY`, `METALLIC`, `ORE_BERRY`, `TWILIGHT_FOREST` | crop-stick cross |

Exact per-tick chance depends on soil and the parents' shared pools — check the [web calculator](https://crops-nh.netlify.app/calculator.html).

## Used to breed

Knightmetal Berry is a parent in these mutations:

| Produces | With |
|----------|------|
| [Steeleafranks](/crops/steeleafranks.md) | [Torchberry](/crops/torchberry.md) |


