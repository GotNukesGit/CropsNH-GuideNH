---
navigation:
  icon: 'cropsnh:genericSeed{crop:"cropsnh:saltyRoot"}'
  title: Salty Root
  parent: /crops.md
  position: 16
---

# Salty Root

**Tier:** 4  
**Soil:** [Farmland](/mechanics/soil-and-blocks.md) — Farmland, Enchanted Earth, Ztones Garden Soil, Fertilized Dirt  
**Likes biomes:** DRY, SANDY, DEAD  
**Alternate seed:** no  
**Pools:** `GRAY`, `ROOT`, `SALTPETER`  

## Breeding setup

Full breeding setup — a cross-crop stick in the center on Farmland, with the parents planted in a line through it (**Sugar Beet** (north), **Canola** (south)):

<GameScene zoom={4} interactive={true}>
  <Block id="minecraft:dirt" x="0" y="0" z="0" />
  <Block id="minecraft:farmland" x="0" y="1" z="0" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crossCrop:1b}' x="0" y="2" z="0" />
  <Block id="minecraft:dirt" x="0" y="0" z="-1" />
  <Block id="minecraft:farmland" x="0" y="1" z="-1" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crop:{crop:"cropsnh:sugarBeet",amount:1,gr:1b,ga:1b,re:1b,scan:1b},progress:1000}' x="0" y="2" z="-1" />
  <Block id="minecraft:dirt" x="0" y="0" z="1" />
  <Block id="minecraft:farmland" x="0" y="1" z="1" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crop:{crop:"cropsnh:canola",amount:1,gr:1b,ga:1b,re:1b,scan:1b},progress:1000}' x="0" y="2" z="1" />
  <BlockAnnotation pos="0 2 0" color="#80FFAA00" thickness="2" alwaysOnTop="true">Salty Root — cross-crop (result grows here)</BlockAnnotation>
  <BlockAnnotation pos="0 2 -1" color="#8044DD66" thickness="2" alwaysOnTop="true">Sugar Beet (parent)</BlockAnnotation>
  <BlockAnnotation pos="0 2 1" color="#8044DD66" thickness="2" alwaysOnTop="true">Canola (parent)</BlockAnnotation>
</GameScene>

## How to obtain

Bred from:

| Parents | Result pools | Notes |
|---------|--------------|-------|
| [Sugar Beet](/crops/sugarbeet.md) + [Canola](/crops/canola.md) | `GRAY`, `ROOT`, `SALTPETER` | crop-stick cross |

Exact per-tick chance depends on soil and the parents' shared pools — check the [web calculator](https://crops-nh.netlify.app/calculator.html).

## Used to breed

Salty Root is a parent in these mutations:

| Produces | With |
|----------|------|
| [Creeperweed](/crops/creeperweed.md) | [Nether Stone Lily](/crops/netherstonelily.md) + [Withereed](/crops/withereed.md) |


