---
navigation:
  icon: 'cropsnh:genericSeed{crop:"cropsnh:marbleLily"}'
  title: Marble Lily
  parent: /crops.md
  position: 19
---

# Marble Lily

> [!WARNING]
> **Buried block required.** This crop needs a `marble` block two spaces below the cross-crop stick (directly under the soil). Without it the crop won't grow — see the setup scene below.

**Tier:** 1  
**Soil:** [Stone](/mechanics/soil-and-blocks.md) — Stone, Cobblestone, Stone Brick, Mossy Cobble + Chisel variants  
**Block under soil:** `marble`  
**Likes biomes:** MOUNTAIN, HILLS  
**Alternate seed:** no  
**Pools:** `STONE`, `WHITE`  

## Breeding setup

Full breeding setup — a cross-crop stick in the center on Stone over a **marble** block, with the parents planted in a line through it (**Stone Lily** (north), **Oxeye Daisy** (south)):

<GameScene zoom={4} interactive={true}>
  <Block id="gregtech:gt.blockstones" meta="0" x="0" y="0" z="0" />
  <Block id="minecraft:stone" x="0" y="1" z="0" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crossCrop:1b}' x="0" y="2" z="0" />
  <Block id="minecraft:stone" x="0" y="0" z="-1" />
  <Block id="minecraft:stone" x="0" y="1" z="-1" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crop:{crop:"cropsnh:stoneLily",amount:1,gr:1b,ga:1b,re:1b,scan:1b},progress:1000}' x="0" y="2" z="-1" />
  <Block id="minecraft:dirt" x="0" y="0" z="1" />
  <Block id="minecraft:dirt" x="0" y="1" z="1" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crop:{crop:"cropsnh:oxeyeDaisy",amount:1,gr:1b,ga:1b,re:1b,scan:1b},progress:1000}' x="0" y="2" z="1" />
  <BlockAnnotation pos="0 2 0" color="#80FFAA00" thickness="2" alwaysOnTop="true">Marble Lily — cross-crop (result grows here)</BlockAnnotation>
  <BlockAnnotation pos="0 2 -1" color="#8044DD66" thickness="2" alwaysOnTop="true">Stone Lily (parent)</BlockAnnotation>
  <BlockAnnotation pos="0 2 1" color="#8044DD66" thickness="2" alwaysOnTop="true">Oxeye Daisy (parent)</BlockAnnotation>
</GameScene>

## How to obtain

Bred from:

| Parents | Result pools | Notes |
|---------|--------------|-------|
| [Stone Lily](/crops/stonelily.md) + [Oxeye Daisy](/crops/oxeyedaisy.md) | `STONE`, `WHITE` | crop-stick cross |

Exact per-tick chance depends on soil and the parents' shared pools — check the [web calculator](https://crops-nh.netlify.app/calculator.html).

## Used to breed

Marble Lily is a parent in these mutations:

| Produces | With |
|----------|------|
| [Cassitine](/crops/cassitine.md) | [Malaxia](/crops/malaxia.md) + [Stone Lily](/crops/stonelily.md) |
| [Diorite Lily](/crops/dioritelily.md) | [Stone Lily](/crops/stonelily.md) |
| [Silviscus](/crops/silviscus.md) | [Cassitine](/crops/cassitine.md) + [Malaxia](/crops/malaxia.md) |


