---
navigation:
  icon: 'cropsnh:genericSeed{crop:"cropsnh:oilBerry"}'
  title: Oil Berry
  parent: /crops.md
  position: 16
---

# Oil Berry

> [!NOTE]
> **Machine-only.** Produced by a machine process, not by breeding on crop sticks.

**Tier:** 4  
**Soil:** [Oil Soil](/mechanics/soil-and-blocks.md) — Sand, Gravel, Soul Sand, Oil Sands (OilBerry compound)  
**Likes biomes:** HOT, WASTELAND  
**Alternate seed:** no  

Crop Breeder only: SoulSandLily + Withereed. Requires oil soil.

## Breeding setup

Full breeding setup — a cross-crop stick in the center on Oil Soil, with the parents planted in a line through it (**Soul Sand Lily** (north), **Withereed** (south)):

<GameScene zoom={4} interactive={true}>
  <Block id="minecraft:sand" x="0" y="0" z="0" />
  <Block id="minecraft:sand" x="0" y="1" z="0" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crossCrop:1b}' x="0" y="2" z="0" />
  <Block id="minecraft:soul_sand" x="0" y="0" z="-1" />
  <Block id="minecraft:stone" x="0" y="1" z="-1" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crop:{crop:"cropsnh:soulSandLily",amount:1,gr:1b,ga:1b,re:1b,scan:1b},progress:1000}' x="0" y="2" z="-1" />
  <Block id="minecraft:coal_block" x="0" y="0" z="1" />
  <Block id="minecraft:stone" x="0" y="1" z="1" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crop:{crop:"cropsnh:withereed",amount:1,gr:1b,ga:1b,re:1b,scan:1b},progress:1000}' x="0" y="2" z="1" />
  <BlockAnnotation pos="0 2 0" color="#80FFAA00" thickness="2" alwaysOnTop="true">Oil Berry — cross-crop (result grows here)</BlockAnnotation>
  <BlockAnnotation pos="0 2 -1" color="#8044DD66" thickness="2" alwaysOnTop="true">Soul Sand Lily (parent)</BlockAnnotation>
  <BlockAnnotation pos="0 2 1" color="#8044DD66" thickness="2" alwaysOnTop="true">Withereed (parent)</BlockAnnotation>
</GameScene>

## How to obtain

Bred from:

| Parents | Result pools | Notes |
|---------|--------------|-------|
| [Soul Sand Lily](/crops/soulsandlily.md) + [Withereed](/crops/withereed.md) | `OIL` | machine recipe |

Exact per-tick chance depends on soil and the parents' shared pools — check the [web calculator](https://crops-nh.netlify.app/calculator.html).


