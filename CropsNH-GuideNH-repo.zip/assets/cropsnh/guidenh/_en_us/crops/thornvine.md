---
navigation:
  icon: 'cropsnh:genericSeed{crop:"cropsnh:thornvine"}'
  title: Thornvine
  parent: /crops.md
  position: 17
---

# Thornvine

**Tier:** 3  
**Soil:** [Netherrack](/mechanics/soil-and-blocks.md) — Netherrack, TiC Nether Bricks, Chisel Netherrack  
**Likes biomes:** NETHER, DRY  
**Alternate seed:** yes — plantable without breeding  
**Pools:** `CLIMBABLE`, `DANGEROUS`, `EMISSIVE`, `NETHER`, `TENDRILLY`, `YELLOW`  

Natura req

## Breeding setup

Full breeding setup — a cross-crop stick in the center on Netherrack, with the parents planted in a line through it (**Vine** (north), **Cactus** (south)):

<GameScene zoom={4} interactive={true}>
  <Block id="minecraft:netherrack" x="0" y="0" z="0" />
  <Block id="minecraft:netherrack" x="0" y="1" z="0" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crossCrop:1b}' x="0" y="2" z="0" />
  <Block id="minecraft:dirt" x="0" y="0" z="-1" />
  <Block id="minecraft:farmland" x="0" y="1" z="-1" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crop:{crop:"cropsnh:vine",amount:1,gr:1b,ga:1b,re:1b,scan:1b},progress:1000}' x="0" y="2" z="-1" />
  <Block id="minecraft:sand" x="0" y="0" z="1" />
  <Block id="minecraft:sand" x="0" y="1" z="1" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crop:{crop:"cropsnh:cactus",amount:1,gr:1b,ga:1b,re:1b,scan:1b},progress:1000}' x="0" y="2" z="1" />
  <BlockAnnotation pos="0 2 0" color="#80FFAA00" thickness="2" alwaysOnTop="true">Thornvine — cross-crop (result grows here)</BlockAnnotation>
  <BlockAnnotation pos="0 2 -1" color="#8044DD66" thickness="2" alwaysOnTop="true">Vine (parent)</BlockAnnotation>
  <BlockAnnotation pos="0 2 1" color="#8044DD66" thickness="2" alwaysOnTop="true">Cactus (parent)</BlockAnnotation>
</GameScene>

## How to obtain

Bred from:

| Parents | Result pools | Notes |
|---------|--------------|-------|
| [Vine](/crops/vine.md) + [Cactus](/crops/cactus.md) | `CLIMBABLE`, `DANGEROUS`, `EMISSIVE`, `NETHER`, `TENDRILLY`, `YELLOW` | crop-stick cross |

Exact per-tick chance depends on soil and the parents' shared pools — check the [web calculator](https://crops-nh.netlify.app/calculator.html).

## Used to breed

Thornvine is a parent in these mutations:

| Produces | With |
|----------|------|
| [Stingberry](/crops/stingberry.md) | [Saguaro Cactus](/crops/saguarocactus.md) |


