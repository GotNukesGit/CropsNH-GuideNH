---
navigation:
  icon: 'cropsnh:genericSeed{crop:"cropsnh:creeperweed"}'
  title: Creeperweed
  parent: /crops.md
  position: 13
---

# Creeperweed

**Tier:** 7  
**Soil:** [Farmland](/mechanics/soil-and-blocks.md) — Farmland, Enchanted Earth, Ztones Garden Soil, Fertilized Dirt  
**Likes biomes:** DEAD, SPOOKY  
**Alternate seed:** no  
**Pools:** `COAL`, `EVIL`, `FIERY`, `POTION_INGREDIENT`, `SALTPETER`, `SULFUR`, `TENDRILLY`  

## Breeding setup

Full breeding setup — a cross-crop stick in the center on Farmland, with the parents planted around it (**Nether Stone Lily** (north), **Withereed** (south), **Salty Root** (east)):

<GameScene zoom={4} interactive={true}>
  <Block id="minecraft:dirt" x="0" y="0" z="0" />
  <Block id="minecraft:farmland" x="0" y="1" z="0" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crossCrop:1b}' x="0" y="2" z="0" />
  <Block id="minecraft:netherrack" x="0" y="0" z="-1" />
  <Block id="minecraft:stone" x="0" y="1" z="-1" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crop:{crop:"cropsnh:netherStoneLily",amount:1,gr:1b,ga:1b,re:1b,scan:1b},progress:1000}' x="0" y="2" z="-1" />
  <Block id="minecraft:coal_block" x="0" y="0" z="1" />
  <Block id="minecraft:stone" x="0" y="1" z="1" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crop:{crop:"cropsnh:withereed",amount:1,gr:1b,ga:1b,re:1b,scan:1b},progress:1000}' x="0" y="2" z="1" />
  <Block id="minecraft:dirt" x="1" y="0" z="0" />
  <Block id="minecraft:farmland" x="1" y="1" z="0" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crop:{crop:"cropsnh:saltyRoot",amount:1,gr:1b,ga:1b,re:1b,scan:1b},progress:1000}' x="1" y="2" z="0" />
  <BlockAnnotation pos="0 2 0" color="#80FFAA00" thickness="2" alwaysOnTop="true">Creeperweed — cross-crop (result grows here)</BlockAnnotation>
  <BlockAnnotation pos="0 2 -1" color="#8044DD66" thickness="2" alwaysOnTop="true">Nether Stone Lily (parent)</BlockAnnotation>
  <BlockAnnotation pos="0 2 1" color="#8044DD66" thickness="2" alwaysOnTop="true">Withereed (parent)</BlockAnnotation>
  <BlockAnnotation pos="1 2 0" color="#8044DD66" thickness="2" alwaysOnTop="true">Salty Root (parent)</BlockAnnotation>
</GameScene>

## How to obtain

Bred from:

| Parents | Result pools | Notes |
|---------|--------------|-------|
| [Nether Stone Lily](/crops/netherstonelily.md) + [Withereed](/crops/withereed.md) + [Salty Root](/crops/saltyroot.md) | `COAL`, `EVIL`, `FIERY`, `POTION_INGREDIENT`, `SALTPETER`, `SULFUR`, `TENDRILLY` | crop-stick cross |

Exact per-tick chance depends on soil and the parents' shared pools — check the [web calculator](https://crops-nh.netlify.app/calculator.html).

## Used to breed

Creeperweed is a parent in these mutations:

| Produces | With |
|----------|------|
| [Enderbloom](/crops/enderbloom.md) | [End Stone Lily](/crops/endstonelily.md) |
| [Essence Ore Berry](/crops/essenceoreberry.md) | [Zomplant](/crops/zomplant.md) + [Spidernip](/crops/spidernip.md) + [Tearstalks](/crops/tearstalks.md) |


