---
navigation:
  icon: 'cropsnh:genericSeed{crop:"cropsnh:rubyne"}'
  title: Rubyne
  parent: /crops.md
  position: 16
---

# Rubyne

> [!WARNING]
> **Buried block required.** This crop needs a `ruby` block two spaces below the cross-crop stick (directly under the soil). Without it the crop won't grow — see the setup scene below.

**Tier:** 4  
**Soil:** [Farmland](/mechanics/soil-and-blocks.md) — Farmland, Enchanted Earth, Ztones Garden Soil, Fertilized Dirt  
**Block under soil:** `ruby`  
**Likes biomes:** MOUNTAIN, RIVER  
**Alternate seed:** no  
**Pools:** `CRYSTALLINE`, `RED`, `SHINY`  

## Breeding setup

Full breeding setup — a cross-crop stick in the center on Farmland over a **ruby** block, with the parents planted in a line through it (**Red Straw** (north), **Diareed** (south)):

<GameScene zoom={4} interactive={true}>
  <Block id="gregtech:gt.blockgem2" meta="11" x="0" y="0" z="0" />
  <Block id="minecraft:farmland" x="0" y="1" z="0" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crossCrop:1b}' x="0" y="2" z="0" />
  <Block id="minecraft:redstone_block" x="0" y="0" z="-1" />
  <Block id="minecraft:farmland" x="0" y="1" z="-1" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crop:{crop:"cropsnh:redstraw",amount:1,gr:1b,ga:1b,re:1b,scan:1b},progress:1000}' x="0" y="2" z="-1" />
  <Block id="minecraft:diamond_block" x="0" y="0" z="1" />
  <Block id="minecraft:stone" x="0" y="1" z="1" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crop:{crop:"cropsnh:diareed",amount:1,gr:1b,ga:1b,re:1b,scan:1b},progress:1000}' x="0" y="2" z="1" />
  <BlockAnnotation pos="0 2 0" color="#80FFAA00" thickness="2" alwaysOnTop="true">Rubyne — cross-crop (result grows here)</BlockAnnotation>
  <BlockAnnotation pos="0 2 -1" color="#8044DD66" thickness="2" alwaysOnTop="true">Red Straw (parent)</BlockAnnotation>
  <BlockAnnotation pos="0 2 1" color="#8044DD66" thickness="2" alwaysOnTop="true">Diareed (parent)</BlockAnnotation>
</GameScene>

## How to obtain

Bred from:

| Parents | Result pools | Notes |
|---------|--------------|-------|
| [Red Straw](/crops/redstraw.md) + [Diareed](/crops/diareed.md) | `CRYSTALLINE`, `RED`, `SHINY` | crop-stick cross |

Exact per-tick chance depends on soil and the parents' shared pools — check the [web calculator](https://crops-nh.netlify.app/calculator.html).

## Used to breed

Rubyne is a parent in these mutations:

| Produces | With |
|----------|------|
| [Platina](/crops/platina.md) | [Diareed](/crops/diareed.md) |


