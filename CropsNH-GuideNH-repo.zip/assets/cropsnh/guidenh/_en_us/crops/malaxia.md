---
navigation:
  icon: 'cropsnh:genericSeed{crop:"cropsnh:malaxia"}'
  title: Malaxia
  parent: /crops.md
  position: 14
---

# Malaxia

> [!WARNING]
> **Buried block required.** This crop needs a `copper` block two spaces below the cross-crop stick (directly under the soil). Without it the crop won't grow — see the setup scene below.

**Tier:** 6  
**Soil:** [Stone](/mechanics/soil-and-blocks.md) — Stone, Cobblestone, Stone Brick, Mossy Cobble + Chisel variants  
**Block under soil:** `copper`  
**Likes biomes:** PLAINS, LUSH  
**Alternate seed:** no  
**Pools:** `BUSH`, `COPPER`, `LEAFY`, `METALLIC`, `ORANGE`  

## Breeding setup

Full breeding setup — a cross-crop stick in the center on Stone over a **copper** block, with the parents planted around it (**Orange Tulip** (north), **Pumpkin** (south), **Stone Lily** (east)):

<GameScene zoom={4} interactive={true}>
  <Block id="gregtech:gt.blockmetal2" meta="7" x="0" y="0" z="0" />
  <Block id="minecraft:stone" x="0" y="1" z="0" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crossCrop:1b}' x="0" y="2" z="0" />
  <Block id="minecraft:dirt" x="0" y="0" z="-1" />
  <Block id="minecraft:dirt" x="0" y="1" z="-1" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crop:{crop:"cropsnh:orangeTulip",amount:1,gr:1b,ga:1b,re:1b,scan:1b},progress:1000}' x="0" y="2" z="-1" />
  <Block id="minecraft:dirt" x="0" y="0" z="1" />
  <Block id="minecraft:farmland" x="0" y="1" z="1" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crop:{crop:"cropsnh:pumpkin",amount:1,gr:1b,ga:1b,re:1b,scan:1b},progress:1000}' x="0" y="2" z="1" />
  <Block id="minecraft:stone" x="1" y="0" z="0" />
  <Block id="minecraft:stone" x="1" y="1" z="0" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crop:{crop:"cropsnh:stoneLily",amount:1,gr:1b,ga:1b,re:1b,scan:1b},progress:1000}' x="1" y="2" z="0" />
  <BlockAnnotation pos="0 2 0" color="#80FFAA00" thickness="2" alwaysOnTop="true">Malaxia — cross-crop (result grows here)</BlockAnnotation>
  <BlockAnnotation pos="0 2 -1" color="#8044DD66" thickness="2" alwaysOnTop="true">Orange Tulip (parent)</BlockAnnotation>
  <BlockAnnotation pos="0 2 1" color="#8044DD66" thickness="2" alwaysOnTop="true">Pumpkin (parent)</BlockAnnotation>
  <BlockAnnotation pos="1 2 0" color="#8044DD66" thickness="2" alwaysOnTop="true">Stone Lily (parent)</BlockAnnotation>
</GameScene>

## How to obtain

Bred from:

| Parents | Result pools | Notes |
|---------|--------------|-------|
| [Orange Tulip](/crops/orangetulip.md) + [Pumpkin](/crops/pumpkin.md) + [Stone Lily](/crops/stonelily.md) | `BUSH`, `COPPER`, `LEAFY`, `METALLIC`, `ORANGE` | crop-stick cross |

Exact per-tick chance depends on soil and the parents' shared pools — check the [web calculator](https://crops-nh.netlify.app/calculator.html).

## Used to breed

Malaxia is a parent in these mutations:

| Produces | With |
|----------|------|
| [Ardite Ore Berry](/crops/arditeoreberry.md) | [Nether Stone Lily](/crops/netherstonelily.md) + [Coppon](/crops/coppon.md) + [Copper Ore Berry](/crops/copperoreberry.md) |
| [Cassitine](/crops/cassitine.md) | [Stone Lily](/crops/stonelily.md) + [Marble Lily](/crops/marblelily.md) |
| [Copper Ore Berry](/crops/copperoreberry.md) | [BoP Berry](/crops/bopberry.md) + [Stone Lily](/crops/stonelily.md) |
| [Plumbshade](/crops/plumbshade.md) | [Azure Bluet](/crops/azurebluet.md) + [Black Granite Lily](/crops/blackgranitelily.md) |
| [Silviscus](/crops/silviscus.md) | [Cassitine](/crops/cassitine.md) + [Marble Lily](/crops/marblelily.md) |


