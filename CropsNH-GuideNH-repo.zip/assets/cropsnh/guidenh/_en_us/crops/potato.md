---
navigation:
  icon: 'cropsnh:genericSeed{crop:"cropsnh:potato"}'
  title: Potato
  parent: /crops.md
  position: 19
---

# Potato

> [!NOTE]
> **Directly obtainable.** No breeding recipe — plant it from a seed you can get by other means.

**Tier:** 1  
**Soil:** [Farmland](/mechanics/soil-and-blocks.md) — Farmland, Enchanted Earth, Ztones Garden Soil, Fertilized Dirt  
**Likes biomes:** PLAINS, COLD  
**Alternate seed:** yes — plantable without breeding  
**Pools:** `EDIBLE`, `ROOT`, `YELLOW`  

## Setup

Grow **Potato** on Farmland:

<GameScene zoom={4} interactive={true}>
  <Block id="minecraft:dirt" x="0" y="0" z="0" />
  <Block id="minecraft:farmland" x="0" y="1" z="0" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crop:{crop:"cropsnh:potato",amount:1,gr:1b,ga:1b,re:1b,scan:1b},progress:1000}' x="0" y="2" z="0" />
  <BlockAnnotation pos="0 2 0" color="#8044DD66" thickness="2" alwaysOnTop="true">Potato</BlockAnnotation>
</GameScene>

## How to obtain

No breeding recipe — obtain the seed directly.

## Used to breed

Potato is a parent in these mutations:

| Produces | With |
|----------|------|
| [Azure Bluet](/crops/azurebluet.md) | [Poppy](/crops/poppy.md) |
| [Cactus](/crops/cactus.md) | [Sugar Cane](/crops/sugarcane.md) |
| [Sugar Cane](/crops/sugarcane.md) | [Carrot](/crops/carrot.md) |
| [Turnip](/crops/turnip.md) | [BoP Berry](/crops/bopberry.md) |


