---
navigation:
  icon: 'cropsnh:genericSeed{crop:"cropsnh:arditeOreBerry"}'
  title: Ardite Ore Berry
  parent: /crops.md
  position: 15
---

# Ardite Ore Berry

> [!WARNING]
> **Buried block required.** This crop needs a `ardite` block two spaces below the cross-crop stick (directly under the soil). Without it the crop won't grow — see the setup scene below.

**Tier:** 5  
**Soil:** [Stone](/mechanics/soil-and-blocks.md) — Stone, Cobblestone, Stone Brick, Mossy Cobble + Chisel variants  
**Block under soil:** `ardite`  
**Likes biomes:** NETHER, HOT  
**Alternate seed:** no  
**Pools:** `DANGEROUS`, `METALLIC`, `ORANGE`, `ORE_BERRY`  

TiC req

## Breeding setup

Full breeding setup — a cross-crop stick in the center on Stone over a **ardite** block, with the parents planted around it (**Nether Stone Lily** (north), **Coppon** (south), **Copper Ore Berry** (east), **Malaxia** (west)):

<GameScene zoom={4} interactive={true}>
  <Block id="TConstruct:decoration.multibrickmetal" meta="1" x="0" y="0" z="0" />
  <Block id="minecraft:stone" x="0" y="1" z="0" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crossCrop:1b}' x="0" y="2" z="0" />
  <Block id="minecraft:netherrack" x="0" y="0" z="-1" />
  <Block id="minecraft:stone" x="0" y="1" z="-1" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crop:{crop:"cropsnh:netherStoneLily",amount:1,gr:1b,ga:1b,re:1b,scan:1b},progress:1000}' x="0" y="2" z="-1" />
  <Block id="gregtech:gt.blockmetal2" meta="7" x="0" y="0" z="1" />
  <Block id="minecraft:stone" x="0" y="1" z="1" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crop:{crop:"cropsnh:coppon",amount:1,gr:1b,ga:1b,re:1b,scan:1b},progress:1000}' x="0" y="2" z="1" />
  <Block id="gregtech:gt.blockmetal2" meta="7" x="1" y="0" z="0" />
  <Block id="minecraft:stone" x="1" y="1" z="0" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crop:{crop:"cropsnh:copperOreBerry",amount:1,gr:1b,ga:1b,re:1b,scan:1b},progress:1000}' x="1" y="2" z="0" />
  <Block id="gregtech:gt.blockmetal2" meta="7" x="-1" y="0" z="0" />
  <Block id="minecraft:stone" x="-1" y="1" z="0" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crop:{crop:"cropsnh:malaxia",amount:1,gr:1b,ga:1b,re:1b,scan:1b},progress:1000}' x="-1" y="2" z="0" />
  <BlockAnnotation pos="0 2 0" color="#80FFAA00" thickness="2" alwaysOnTop="true">Ardite Ore Berry — cross-crop (result grows here)</BlockAnnotation>
  <BlockAnnotation pos="0 2 -1" color="#8044DD66" thickness="2" alwaysOnTop="true">Nether Stone Lily (parent)</BlockAnnotation>
  <BlockAnnotation pos="0 2 1" color="#8044DD66" thickness="2" alwaysOnTop="true">Coppon (parent)</BlockAnnotation>
  <BlockAnnotation pos="1 2 0" color="#8044DD66" thickness="2" alwaysOnTop="true">Copper Ore Berry (parent)</BlockAnnotation>
  <BlockAnnotation pos="-1 2 0" color="#8044DD66" thickness="2" alwaysOnTop="true">Malaxia (parent)</BlockAnnotation>
</GameScene>

## How to obtain

Bred from:

| Parents | Result pools | Notes |
|---------|--------------|-------|
| [Nether Stone Lily](/crops/netherstonelily.md) + [Coppon](/crops/coppon.md) + [Copper Ore Berry](/crops/copperoreberry.md) + [Malaxia](/crops/malaxia.md) | `DANGEROUS`, `METALLIC`, `ORANGE`, `ORE_BERRY` | crop-stick cross |

Exact per-tick chance depends on soil and the parents' shared pools — check the [web calculator](https://crops-nh.netlify.app/calculator.html).

## Used to breed

Ardite Ore Berry is a parent in these mutations:

| Produces | With |
|----------|------|
| [Cobalt Ore Berry](/crops/cobaltoreberry.md) | [Nether Stone Lily](/crops/netherstonelily.md) + [Lazulia](/crops/lazulia.md) + [Gold Ore Berry](/crops/goldoreberry.md) |


