---
navigation:
  icon: 'cropsnh:genericSeed{crop:"cropsnh:flax"}'
  title: Flax
  parent: /crops.md
  position: 18
---

# Flax

**Tier:** 2  
**Soil:** [Farmland](/mechanics/soil-and-blocks.md) — Farmland, Enchanted Earth, Ztones Garden Soil, Fertilized Dirt  
**Likes biomes:** WET, RIVER, BEACH, SANDY  
**Alternate seed:** yes — plantable without breeding  
**Pools:** `ADDICTIVE`, `BLUE`, `SILK`, `WHEAT`  

## Breeding setup

Full breeding setup — a cross-crop stick in the center on Farmland, with the parents planted in a line through it (**Wheat** (north), **Azure Bluet** (south)):

<GameScene zoom={4} interactive={true}>
  <Block id="minecraft:dirt" x="0" y="0" z="0" />
  <Block id="minecraft:farmland" x="0" y="1" z="0" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crossCrop:1b}' x="0" y="2" z="0" />
  <Block id="minecraft:dirt" x="0" y="0" z="-1" />
  <Block id="minecraft:farmland" x="0" y="1" z="-1" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crop:{crop:"cropsnh:wheat",amount:1,gr:1b,ga:1b,re:1b,scan:1b},progress:1000}' x="0" y="2" z="-1" />
  <Block id="minecraft:dirt" x="0" y="0" z="1" />
  <Block id="minecraft:dirt" x="0" y="1" z="1" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crop:{crop:"cropsnh:azureBluet",amount:1,gr:1b,ga:1b,re:1b,scan:1b},progress:1000}' x="0" y="2" z="1" />
  <BlockAnnotation pos="0 2 0" color="#80FFAA00" thickness="2" alwaysOnTop="true">Flax — cross-crop (result grows here)</BlockAnnotation>
  <BlockAnnotation pos="0 2 -1" color="#8044DD66" thickness="2" alwaysOnTop="true">Wheat (parent)</BlockAnnotation>
  <BlockAnnotation pos="0 2 1" color="#8044DD66" thickness="2" alwaysOnTop="true">Azure Bluet (parent)</BlockAnnotation>
</GameScene>

## How to obtain

Bred from:

| Parents | Result pools | Notes |
|---------|--------------|-------|
| [Wheat](/crops/wheat.md) + [Azure Bluet](/crops/azurebluet.md) | `ADDICTIVE`, `BLUE`, `SILK`, `WHEAT` | crop-stick cross |

Exact per-tick chance depends on soil and the parents' shared pools — check the [web calculator](https://crops-nh.netlify.app/calculator.html).

## Used to breed

Flax is a parent in these mutations:

| Produces | With |
|----------|------|
| [Cotton](/crops/cotton.md) | [Hemp](/crops/hemp.md) |
| [Hemp](/crops/hemp.md) | [Papyrus](/crops/papyrus.md) |
| [Spidernip](/crops/spidernip.md) | [Hemp](/crops/hemp.md) + [Zomplant](/crops/zomplant.md) |


