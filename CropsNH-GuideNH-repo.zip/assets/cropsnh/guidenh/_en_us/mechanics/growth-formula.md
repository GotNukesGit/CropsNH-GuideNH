---
navigation:
  icon: 'cropsnh:plantLens'
  title: Growth formula
  parent: /mechanics.md
  position: 0
---

# Growth Formula

> [!TIP]
> **TL;DR.** Every **12.8 s** a crop gains growth points. Higher tiers take longer and need more
> nutrients or they get sick and stop entirely. Sky access, water, fertilizer, and a liked biome
> all raise nutrients → faster growth. If the calculator shows **SICK**, you need more nutrients.

<details summary="The full growth-rate formula">

<Latex formula="\text{scaled} = \text{nutrients}\times 5, \qquad \text{need} = \text{tier}\times 10, \qquad \text{base} = 6 + \text{Growth}" scale="1.05"/>

<Latex formula="\text{rate} = \begin{cases} \text{base}\cdot\frac{100+\text{scaled}-\text{need}}{100} & \text{scaled} \ge \text{need} \\ \max\!\big(0,\ \text{base}\cdot\frac{100-(\text{need}-\text{scaled})\cdot 4}{100}\big) & \text{else} \end{cases}" scale="1.0"/>

A rate of **0** means SICK — it stops growing and spreads sickness. Default growth duration is
**tier × 600** points (the Bonsai family is hardcoded to a flat 1200). Growth is added every
**256 game ticks (12.8 s)**.

</details>

<details summary="How the biome bonus really works (max, not sum)">

Two bonuses, and the game takes the **larger** — they don't stack:

<Latex formula="\text{humidity} = \operatorname{clamp}\!\big(\tfrac{\text{rainfall}-0.5}{0.3},0,1\big)\times 14, \quad \text{liked} = \text{matchedTags}\times 14" scale="1.0"/>

<Latex formula="\text{biomeBonus} = \max(\text{humidity},\ \text{liked})" scale="1.15"/>

So any biome with **rainfall ≥ 0.8** gives +14 to *every* crop unconditionally — Jungle (0.9),
Swampland (0.9), Forest (0.8) all hit the cap. A crop with two liked tags (+28) gains nothing
extra from humidity; the +28 wins.

</details>

> [!NOTE]
> The [Production Calculator](https://crops-nh.netlify.app/calculator.html) does all of this — type
> your biome, pick a crop, and read the exact nutrient score and time-to-mature.

