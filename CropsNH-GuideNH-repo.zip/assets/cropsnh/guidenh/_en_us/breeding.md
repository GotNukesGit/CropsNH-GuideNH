---
navigation:
  icon: 'cropsnh:cropSticksItem'
  title: Breeding
  parent: /index.md
  position: 30
---

# Breeding

How a cross-crop stick turns two parents into a new species: the per-tick roll, spreading vs
mutating, deterministic recipes vs pools, and how to bend the odds.

<SubPages/>

