---
navigation:
  icon: 'cropsnh:cropSticksItem'
  title: Strategy
  parent: /index.md
  position: 20
---

# Strategy

Where to farm, how to fight weeds, what to automate, and what each tier demands.

<SubPages/>

