---
navigation:
  icon: 'cropsnh:genericSeed{crop:"cropsnh:corpseplant"}'
  title: The Graveyard Soil trick
  parent: /breeding.md
  position: 0
---

# The Graveyard Soil Trick

> [!TIP]
> **TL;DR.** Put **TiC Graveyard Soil** under your cross-crop and breed **Corium + Corium**. Corium
> sits in 4 pools with 17 possible pool outputs, but **only Corpseplant needs graveyard soil** —
> everything else is rejected. Median wait ≈ **46 min**.

<details summary="Full probability breakdown">

Corpseplant lives in `aTendrilly`. Corium belongs to four pools (`aCow`, `aMilk`, `aSilk`,
`aTendrilly`); in Corium×Corium all four match and one is picked per attempt:

<Latex formula="P = \frac{1}{3}\cdot\frac{1}{2}\cdot\frac{1}{4\ \text{pools}}\cdot\frac{1}{N_{\text{aTendrilly}}} \approx 0.32\%\,/\text{tick}" scale="1.05"/>

| Metric | Value |
|---|---|
| P(Corpseplant) / tick | ≈ 0.32% |
| P / minute | ≈ 1.49% |
| Median time | ≈ 46 min |
| Mean time | ≈ 67 min |
| 90% confidence | ≈ 153 min |

</details>

> [!NOTE]
> The idea generalizes: any restrictive soil — or a buried block only one pool member accepts —
> turns a noisy pool roll into a near-guaranteed target.

