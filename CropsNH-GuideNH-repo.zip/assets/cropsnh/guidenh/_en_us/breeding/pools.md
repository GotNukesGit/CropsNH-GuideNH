---
navigation:
  icon: 'cropsnh:genericSeed{crop:"cropsnh:corium"}'
  title: Pool reference
  parent: /breeding.md
  position: 2
---

# Pool Reference

Every crop belongs to one or more **pools**. On the pool path the game looks at the pools the two parents **share** and draws the result from there — like the overlap of a Venn diagram:

<img src="/guidenh/img/pool_venn.png" alt="Each parent brings a set of pools; the mutation is drawn from the shared overlap" />

It picks one shared pool at random, then a random member of that pool. So the chance of a specific crop from a pairing:

<Latex formula="P(\text{crop}) = \frac{1}{3}\cdot\frac{1}{2}\cdot\sum_{\text{pools containing it}}\frac{1}{N_{\text{matching pools}}}\cdot\frac{1}{N_{\text{members}}}" scale="1.1"/>

All **66** pools across the 179 crops:

| Pool | Members | Crops |
|------|:------:|-------|
| `ADDICTIVE` | 13 | Blightberry, Cocoa, Coffee, Dayflower, Duskberry, Egg Plant, Flax, Goldfish, Hemp, Skyberry, Spidernip, Stingberry, Sugar Beet |
| `ALIEN` | 2 | End Stone Lily, Enderbloom |
| `BEAN` | 3 | Cocoa, Coffee, Mana Bean |
| `BERRY` | 13 | Blackberry, Blightberry, Blueberry, BoP Berry, BobsYerUncleRanks, Duskberry, Huckleberry, Maloberry, Raspberry, Skyberry, Stingberry, Strawberry, Torchberry |
| `BLACK` | 6 | Basalt Lily, Black Granite Lily, Blackberry, Deepslate Lily, Ink Bloom, Void Ore Berry |
| `BLAZE` | 2 | Blazereed, Cinderpearl |
| `BLUE` | 13 | Blue Glowshroom, Blue Orchid, Blueberry, Cobalt Ore Berry, Dayflower, Diareed, Flax, Glowflower, Indigo, Lazulia, Skyberry, Thauminite Ore Berry, Water Artichoke |
| `BROWN` | 17 | Bonsai Dark Oak, Bonsai Jungle, Bonsai Oak, Bonsai Rubber, Bonsai Spruce, Brown Mushroom, Cocoa, Coffee, Corpseplant, Fertilia, Liveroot, Mana Bean, Mandrake, Onion, Soul Sand Lily, Stingberry, Zomplant |
| `BUSH` | 20 | Blackberry, Blightberry, Blueberry, BoP Berry, Cassitine, Coppon, Duskberry, Galvania, Huckleberry, Malaxia, Maloberry, Plumbshade, Pyrolusium, Raspberry, Silviscus, Skyberry, Slimeplant, Stingberry, Strawberry, Tine |
| `CACTUS` | 2 | Cactus, Saguaro Cactus |
| `CHICKEN` | 2 | Egg Plant, Meatrose |
| `CLIMBABLE` | 8 | Ember Moss, Flowering Vine, Grape, Ivy, Moss, Spanish Moss, Thornvine, Vine |
| `COAL` | 3 | Creeperweed, Diareed, Withereed |
| `COPPER` | 3 | Copper Ore Berry, Coppon, Malaxia |
| `COTTON` | 2 | Coppon, Cotton |
| `COW` | 3 | Corium, Meatrose, Milk Wart |
| `CRYSTALLINE` | 7 | BobsYerUncleRanks, Diareed, Evil Ore, Glowheat, Lazulia, Rubyne, Sapphirum |
| `DANGEROUS` | 27 | Aluminium Ore Berry, Ardite Ore Berry, Bamboo, Blightberry, Cactus, Cobalt Ore Berry, Copper Ore Berry, Duskberry, Ember Moss, Essence Ore Berry, Gold Ore Berry, Goldfish, Iron Ore Berry, Ivy, Knightmetal Berry, Mandrake, Necrobloom, Saguaro Cactus, Skyberry, Soul Sand Lily, Stingberry, Thauminite Ore Berry, Thaumium Ore Berry, Thiosulfine, Thornvine, Tin Ore Berry, Void Ore Berry |
| `DARK` | 5 | Basalt Lily, Black Granite Lily, Bonsai Dark Oak, Deepslate Lily, Tuff Lily |
| `DENSE` | 5 | Auronia, Deepslate Lily, Gold Ore Berry, Plumbilia, Plumbshade |
| `EDIBLE` | 50 | Barley, Blackberry, Blightberry, Blue Glowshroom, Blueberry, BoP Berry, Bonsai Dark Oak, Bonsai Oak, Brown Mushroom, Canola, Carrot, Chilly, Cocoa, Coffee, Corpseplant, Cucumber, Duskberry, Egg Plant, Essence Ore Berry, Garlic, Goldfish, Grape, Green Glowshroom, Hops, Huckleberry, Lemon, Maloberry, Meatrose, Melon, Milk Wart, Onion, Potato, Pumpkin, Purple Glowshroom, Raspberry, Red Mushroom, Saguaro Cactus, Skyberry, Spidernip, Stingberry, Strawberry, Sugar Beet, Sugar Cane, Tea, Tomato, Turnip, Water Artichoke, Wheat, Wild Carrot, Zomplant |
| `EMISSIVE` | 11 | Blue Glowshroom, Glowflower, Glowheat, Glowing Coral, Glowshroom, Green Glowshroom, Purple Glowshroom, Red Straw, Shimmerleaf, Thornvine, Torchberry |
| `EVIL` | 10 | Blazereed, Corpseplant, Creeperweed, Evil Ore, Eyebulb, Mandrake, Slimeplant, Spidernip, Tearstalks, Zomplant |
| `FIERY` | 8 | Blazereed, Chilly, Creeperweed, Diareed, Ember Moss, Evil Ore, Nickelback, Withereed |
| `FISH` | 2 | Goldfish, Meatrose |
| `FLOWER` | 27 | Allium, Azure Bluet, Belladonna, Blue Orchid, Dandelion, Dayflower, Egg Plant, Enderbloom, Flowering Vine, Glint Weed, Indigo, Ink Bloom, Ivy, Mandrake, Meatrose, Necrobloom, Orange Tulip, Oxeye Daisy, Pink Tulip, Poppy, Purple Tulip, Red Tulip, Snowbell, Thiosulfine, Water Artichoke, White Tulip, Wolfsbane |
| `GOLD` | 2 | Auronia, Gold Ore Berry |
| `GRAY` | 11 | Andesite Lily, Cassitine, Clay Lily, Duskberry, Ferrofern, Iron Ore Berry, Knightmetal Berry, Salty Root, Shimmerleaf, Stone Lily, Tuff Lily |
| `GREEN` | 24 | Bamboo, Barley, Blightberry, BobsYerUncleRanks, Cactus, Cucumber, Essence Ore Berry, Flowering Vine, Glowshroom, Green Glowshroom, Hemp, Hops, Ivy, Melon, Moss, Saguaro Cactus, Slimeplant, Spanish Moss, Steeleafranks, Sticky Cane, Sugar Cane, Tea, Vine, Waterlily |
| `HEALING` | 6 | Blightberry, Fertilia, Lazulia, Melon, Milk Wart, Tearstalks |
| `IRON` | 3 | Ferrofern, Iron Ore Berry, Steeleafranks |
| `LEAD` | 2 | Plumbilia, Plumbshade |
| `LEAFY` | 17 | Bamboo, Bonsai Acacia, Bonsai Birch, Bonsai Dark Oak, Bonsai Jungle, Bonsai Oak, Cassitine, Cocoa, Coffee, Grape, Huckleberry, Lemon, Malaxia, Plumbshade, Silviscus, Tea, Tomato |
| `MAGICAL` | 10 | Cinderpearl, Enderbloom, Glint Weed, Mana Bean, Mandrake, Shimmerleaf, Spanish Moss, Thauminite Ore Berry, Thaumium Ore Berry, Void Ore Berry |
| `METALLIC` | 26 | Aluminium Ore Berry, Ardite Ore Berry, Argentia, Auronia, Cassitine, Cobalt Ore Berry, Copper Ore Berry, Coppon, Ferrofern, Galvania, Gold Ore Berry, Iron Ore Berry, Knightmetal Berry, Malaxia, Nickelback, Plumbilia, Plumbshade, Pyrolusium, Sapphirum, Silviscus, Steeleafranks, Thauminite Ore Berry, Thaumium Ore Berry, Tin Ore Berry, Tine, Void Ore Berry |
| `MUSHROOM` | 7 | Blue Glowshroom, Brown Mushroom, Fertilia, Glowshroom, Green Glowshroom, Purple Glowshroom, Red Mushroom |
| `NETHER` | 19 | Blazereed, Blightberry, Blue Glowshroom, Cobalt Ore Berry, Duskberry, Evil Ore, Eyebulb, Glowflower, Glowshroom, Goldfish, Green Glowshroom, Nether Stone Lily, Nether Wart, Purple Glowshroom, Skyberry, Soul Sand Lily, Stingberry, Tearstalks, Thornvine |
| `OIL` | 2 | Canola, Soul Sand Lily |
| `ORANGE` | 10 | Ardite Ore Berry, Bonsai Acacia, Carrot, Cinderpearl, Copper Ore Berry, Coppon, Glint Weed, Malaxia, Orange Tulip, Pumpkin |
| `ORE_BERRY` | 12 | Aluminium Ore Berry, Ardite Ore Berry, Cobalt Ore Berry, Copper Ore Berry, Essence Ore Berry, Gold Ore Berry, Iron Ore Berry, Knightmetal Berry, Thauminite Ore Berry, Thaumium Ore Berry, Tin Ore Berry, Void Ore Berry |
| `POISONOUS` | 13 | Belladonna, Blightberry, Corpseplant, Duskberry, Ivy, Necrobloom, Shimmerleaf, Skyberry, Snowbell, Spidernip, Stingberry, Wolfsbane, Zomplant |
| `POTION_INGREDIENT` | 28 | Belladonna, Blazereed, Blightberry, Blue Glowshroom, Carrot, Creeperweed, Duskberry, Ember Moss, Garlic, Glowflower, Glowheat, Glowing Coral, Glowshroom, Green Glowshroom, Mandrake, Melon, Nether Wart, Purple Glowshroom, Red Straw, Skyberry, Slimeplant, Snowbell, Spidernip, Stingberry, Sugar Beet, Tearstalks, Water Artichoke, Wolfsbane |
| `PURPLE` | 12 | Allium, Belladonna, Glowing Coral, Grape, Huckleberry, Necrobloom, Plumbshade, Purple Glowshroom, Purple Tulip, Thaumium Ore Berry, Turnip, Wolfsbane |
| `RED` | 17 | BoP Berry, Chilly, Ember Moss, Eyebulb, Granite Lily, Nether Stone Lily, Nether Wart, Pink Tulip, Poppy, Raspberry, Red Granite Lily, Red Mushroom, Red Straw, Red Tulip, Rubyne, Strawberry, Tomato |
| `REED` | 6 | Blazereed, Diareed, Plumbilia, Sticky Cane, Sugar Cane, Withereed |
| `ROOT` | 10 | Allium, Carrot, Garlic, Liveroot, Onion, Potato, Salty Root, Sugar Beet, Turnip, Wild Carrot |
| `SALTPETER` | 2 | Creeperweed, Salty Root |
| `SHINY` | 15 | Argentia, BobsYerUncleRanks, Cassitine, Copper Ore Berry, Coppon, Diareed, Enderbloom, Glowflower, Glowheat, Glowing Coral, Lazulia, Rubyne, Sapphirum, Tin Ore Berry, Tine |
| `SILK` | 5 | Corium, Cotton, Flax, Hemp, Spidernip |
| `SILVER` | 3 | Argentia, Shimmerleaf, Silviscus |
| `STEM` | 7 | Bamboo, Hemp, Melon, Papyrus, Pumpkin, Tearstalks, Withereed |
| `STICKY` | 3 | Bonsai Rubber, Slimeplant, Sticky Cane |
| `STONE` | 16 | Andesite Lily, Basalt Lily, Black Granite Lily, Clay Lily, Deepslate Lily, Diorite Lily, End Stone Lily, Granite Lily, Marble Lily, Nether Stone Lily, Red Granite Lily, Red Straw, Sand Lily, Soul Sand Lily, Stone Lily, Tuff Lily |
| `SULFUR` | 4 | Blazereed, Creeperweed, Thiosulfine, Withereed |
| `TENDRILLY` | 20 | Argentia, Auronia, BobsYerUncleRanks, Corium, Corpseplant, Cotton, Creeperweed, Cucumber, Ember Moss, Eyebulb, Ferrofern, Flowering Vine, Grape, Ivy, Liveroot, Moss, Steeleafranks, Thornvine, Tomato, Vine |
| `TIN` | 3 | Cassitine, Tin Ore Berry, Tine |
| `TREE` | 9 | Bonsai Acacia, Bonsai Birch, Bonsai Dark Oak, Bonsai Jungle, Bonsai Oak, Bonsai Rubber, Bonsai Spruce, Cocoa, Lemon |
| `TULIP` | 5 | Orange Tulip, Pink Tulip, Purple Tulip, Red Tulip, White Tulip |
| `TWILIGHT_FOREST` | 5 | Knightmetal Berry, Liveroot, Moss, Steeleafranks, Torchberry |
| `UNDEAD` | 4 | Corpseplant, Essence Ore Berry, Withereed, Zomplant |
| `VOID_TOUCHED` | 3 | Thauminite Ore Berry, Thaumium Ore Berry, Void Ore Berry |
| `WATERY` | 6 | Clay Lily, Glowing Coral, Goldfish, Ink Bloom, Water Artichoke, Waterlily |
| `WHEAT` | 7 | Barley, Canola, Flax, Glowheat, Hops, Red Straw, Wheat |
| `WHITE` | 20 | Aluminium Ore Berry, Argentia, Azure Bluet, Bonsai Birch, Cotton, Diorite Lily, Evil Ore, Galvania, Garlic, Marble Lily, Oxeye Daisy, Papyrus, Silviscus, Snowbell, Spidernip, Sugar Beet, Tearstalks, Tin Ore Berry, White Tulip, Wild Carrot |
| `WOODEN` | 8 | Bonsai Acacia, Bonsai Birch, Bonsai Dark Oak, Bonsai Jungle, Bonsai Oak, Bonsai Rubber, Bonsai Spruce, Liveroot |
| `YELLOW` | 13 | Auronia, Canola, Dandelion, End Stone Lily, Gold Ore Berry, Lemon, Maloberry, Potato, Sand Lily, Thiosulfine, Thornvine, Torchberry, Wheat |

