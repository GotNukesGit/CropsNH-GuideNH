---
navigation:
  icon: 'cropsnh:genericSeed{crop:"cropsnh:ferrofern"}'
  title: Deterministic & pool mutations
  parent: /breeding.md
  position: 3
---

# Mutations: Deterministic & Pool

> [!TIP]
> **TL;DR.** On the breed path the game tries two things in order: **(1) a deterministic recipe** —
> an exact parent match, fast and predictable; **(2) a pool mutation** — if no recipe matches, it
> picks a shared pool at random, then a random crop from it.

<ContentTabs>
<Tab title="Deterministic" color="#5fd38d">

A specific recipe, e.g. **Ferrofern ← StoneLily + BlackGraniteLily**. If both parent species are
present as neighbours, it can fire. The parent list is **deduplicated** first — so two of the same
crop (Corium + Corium) can never match a deterministic recipe (deduped size 1 < 2). If several
recipes match, one is chosen at random with equal probability.

</Tab>
<Tab title="Pool" color="#6db3f2">

Every crop belongs to 0–7 named **pools** (`METALLIC`, `EDIBLE`, `TENDRILLY`…). Pools fire when
no recipe matches. The list is **not** deduped here — so Corium + Corium counts as two Corium
entries. Pick a random matching pool → a random member → return it. Crops in more pools get
proportionally more chances.

</Tab>
</ContentTabs>

> [!TIP]
> **Rarity is structural, not weighted.** There are no weight values in the code — a crop in 6
> matching pools simply has 6× the chance of a crop in 1. Stingberry (7 pools) is one of the
> likeliest pool outputs when nether/toxic/berry parents are involved.

> [!CAUTION]
> **Breeding a crop against itself widens the odds, not narrows them.** Every pool it belongs to
> activates at once, so the random pick competes against *everyone* in all those pools. Two
> different, pool-sharing parents are usually more targeted.

