---
navigation:
  icon: 'cropsnh:plantLens'
  title: Probability & timing
  parent: /breeding.md
  position: 1
---

# Probability & Timing

> [!TIP]
> **TL;DR.** A tick happens every **12.8 s**, with a **1-in-3** breed chance. A typical
> deterministic mutation lands in **1–5 min**; a specific pool crop can take **10–60 min**. The
> [calculator](https://crops-nh.netlify.app/calculator.html) gives exact minutes.

<details summary="The probability & timing formulas">

<Latex formula="\text{ExpectedTicks} = \tfrac{1}{P}, \quad \text{MeanTime} = \text{ticks}\times 12.8\,\text{s}" scale="1.05"/>

<Latex formula="\text{MedianTime} = \frac{\ln 0.5}{\ln(1-P)}\times 12.8\,\text{s}, \qquad P_{\text{per min}} = 1-(1-P)^{4.6875}" scale="1.0"/>

| Mutation type | ≈ P / tick | ≈ mean time |
|---|:--:|:--:|
| 1 deterministic match, 1 recipe | 8.3% | 2.5 min |
| 1 match, 3 recipes competing | 2.8% | 7.5 min |
| pool, target in 1 pool of 8 | 1% | 21 min |
| pool, soil filter leaves 1 result | 0.5% | 42 min |

</details>

