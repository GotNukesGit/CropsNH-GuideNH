---
navigation:
  icon: 'cropsnh:genericSeed{crop:"cropsnh:wheat"}'
  title: Statting up
  parent: /strategy.md
  position: 3
---

# Statting Up to 31/31/31

> [!TIP]
> **TL;DR.** Place **one** high-stat copy next to an empty cross-crop stick. The spreading path
> clones it, inheriting that one parent's stats ± variance. With fertilizer in the parent, variance
> is **0 to +4** — stats can only go up. Keep better clones, replace the parent, repeat.

> [!IMPORTANT]
> ✅ A single fertilized parent works via the clone path — more efficient than a 2-parent breed for
> pure stat-up.
> ✅ Fertilizer in **every** contributing parent → no drops.
> ❌ Missing fertilizer in any → stats can drop up to 2 per trait.

<details summary="The loop">

1. Get one copy of the target crop, any stats.
2. Place it as the **sole** parent next to a cross-crop stick, fertilizer in it.
3. Collect clones; keep any that improved, discard the rest.
4. Replace the parent with your best, repeat.

With two identical parents at 100%, spreading fires on ~16.7% of ticks (~78%/min) — roughly 3–4
stat rolls per minute at ideal conditions.

</details>

