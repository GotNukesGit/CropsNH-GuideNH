---
navigation:
  icon: 'cropsnh:genericSeed{crop:"cropsnh:wheat"}'
  title: Crops
  parent: /index.md
  position: 10
---

# All Crops

179 crops, grouped by tier. Each page lists soil, block-under, pools,
liked biomes, and every mutation recipe that produces or uses the crop.

### Tier 1

- [Andesite Lily](/crops/andesitelily.md)
- [Basalt Lily](/crops/basaltlily.md)
- [Black Granite Lily](/crops/blackgranitelily.md)
- [Bonsai Acacia](/crops/bonsaiacacia.md)
- [Bonsai Birch](/crops/bonsaibirch.md)
- [Bonsai Dark Oak](/crops/bonsaidarkoak.md)
- [Bonsai Jungle](/crops/bonsaijungle.md)
- [Bonsai Oak](/crops/bonsaioak.md)
- [Bonsai Rubber](/crops/bonsairubber.md)
- [Bonsai Slimy](/crops/bonsaislimy.md)
- [Bonsai Spruce](/crops/bonsaispruce.md)
- [Brown Mushroom](/crops/brownmushroom.md)
- [Clay Lily](/crops/claylily.md)
- [Deepslate Lily](/crops/deepslatelily.md)
- [Diorite Lily](/crops/dioritelily.md)
- [End Stone Lily](/crops/endstonelily.md)
- [Eyebulb](/crops/eyebulb.md)
- [Granite Lily](/crops/granitelily.md)
- [Marble Lily](/crops/marblelily.md)
- [Nether Stone Lily](/crops/netherstonelily.md)
- [Potato](/crops/potato.md)
- [Red Granite Lily](/crops/redgranitelily.md)
- [Red Mushroom](/crops/redmushroom.md)
- [Sand Lily](/crops/sandlily.md)
- [Stone Lily](/crops/stonelily.md)
- [Tuff Lily](/crops/tufflily.md)
- [Wheat](/crops/wheat.md)

### Tier 2

- [Allium](/crops/allium.md)
- [Azure Bluet](/crops/azurebluet.md)
- [Bamboo](/crops/bamboo.md)
- [Barley](/crops/barley.md)
- [Blackberry](/crops/blackberry.md)
- [Blue Orchid](/crops/blueorchid.md)
- [Blueberry](/crops/blueberry.md)
- [BoP Berry](/crops/bopberry.md)
- [Carrot](/crops/carrot.md)
- [Dandelion](/crops/dandelion.md)
- [Dayflower](/crops/dayflower.md)
- [Flax](/crops/flax.md)
- [Huckleberry](/crops/huckleberry.md)
- [Indigo](/crops/indigo.md)
- [Ivy](/crops/ivy.md)
- [Maloberry](/crops/maloberry.md)
- [Melon](/crops/melon.md)
- [Olivia](/crops/olivia.md)
- [Orange Tulip](/crops/orangetulip.md)
- [Oxeye Daisy](/crops/oxeyedaisy.md)
- [Pink Tulip](/crops/pinktulip.md)
- [Poppy](/crops/poppy.md)
- [Pumpkin](/crops/pumpkin.md)
- [Purple Tulip](/crops/purpletulip.md)
- [Raspberry](/crops/raspberry.md)
- [Red Tulip](/crops/redtulip.md)
- [Soul Sand Lily](/crops/soulsandlily.md)
- [Strawberry](/crops/strawberry.md)
- [Sugar Cane](/crops/sugarcane.md)
- [Torchberry](/crops/torchberry.md)
- [Turnip](/crops/turnip.md)
- [Vine](/crops/vine.md)
- [Waterlily](/crops/waterlily.md)
- [White Tulip](/crops/whitetulip.md)
- [Wild Carrot](/crops/wildcarrot.md)

### Tier 3

- [Blue Glowshroom](/crops/blueglowshroom.md)
- [Cactus](/crops/cactus.md)
- [Cocoa](/crops/cocoa.md)
- [Cotton](/crops/cotton.md)
- [Fertilia](/crops/fertilia.md)
- [Flowering Vine](/crops/floweringvine.md)
- [Garlic](/crops/garlic.md)
- [Glowflower](/crops/glowflower.md)
- [Glowshroom](/crops/glowshroom.md)
- [Green Glowshroom](/crops/greenglowshroom.md)
- [Necrobloom](/crops/necrobloom.md)
- [Purple Glowshroom](/crops/purpleglowshroom.md)
- [Thornvine](/crops/thornvine.md)
- [Zomplant](/crops/zomplant.md)

### Tier 4

- [Belladonna](/crops/belladonna.md)
- [Blightberry](/crops/blightberry.md)
- [Canola](/crops/canola.md)
- [Chilly](/crops/chilly.md)
- [Cucumber](/crops/cucumber.md)
- [Duskberry](/crops/duskberry.md)
- [Glint Weed](/crops/glintweed.md)
- [Glowheat](/crops/glowheat.md)
- [Goldfish](/crops/goldfish.md)
- [Grape](/crops/grape.md)
- [Ink Bloom](/crops/inkbloom.md)
- [Lemon](/crops/lemon.md)
- [Mandrake](/crops/mandrake.md)
- [Moss](/crops/moss.md)
- [Oil Berry](/crops/oilberry.md)
- [Onion](/crops/onion.md)
- [Rubyne](/crops/rubyne.md)
- [Saguaro Cactus](/crops/saguarocactus.md)
- [Salty Root](/crops/saltyroot.md)
- [Sapphirum](/crops/sapphirum.md)
- [Skyberry](/crops/skyberry.md)
- [Snowbell](/crops/snowbell.md)
- [Spidernip](/crops/spidernip.md)
- [Sticky Cane](/crops/stickycane.md)
- [Stingberry](/crops/stingberry.md)
- [Sugar Beet](/crops/sugarbeet.md)
- [Tea](/crops/tea.md)
- [Tin Ore Berry](/crops/tinoreberry.md)
- [Tomato](/crops/tomato.md)
- [Water Artichoke](/crops/waterartichoke.md)
- [Wolfsbane](/crops/wolfsbane.md)

### Tier 5

- [Aluminium Ore Berry](/crops/aluminiumoreberry.md)
- [Ardite Ore Berry](/crops/arditeoreberry.md)
- [Cinderpearl](/crops/cinderpearl.md)
- [Cobalt Ore Berry](/crops/cobaltoreberry.md)
- [Copper Ore Berry](/crops/copperoreberry.md)
- [Corpseplant](/crops/corpseplant.md)
- [Essence Ore Berry](/crops/essenceoreberry.md)
- [Gaia Wart](/crops/gaiawart.md)
- [Glowing Coral](/crops/glowingcoral.md)
- [Gold Ore Berry](/crops/goldoreberry.md)
- [Hemp](/crops/hemp.md)
- [Hops](/crops/hops.md)
- [Iron Ore Berry](/crops/ironoreberry.md)
- [Mana Bean](/crops/manabean.md)
- [Nether Wart](/crops/netherwart.md)
- [Nickelback](/crops/nickelback.md)
- [Papyrus](/crops/papyrus.md)
- [Shimmerleaf](/crops/shimmerleaf.md)
- [Tine](/crops/tine.md)

### Tier 6

- [Bauxia](/crops/bauxia.md)
- [Blazereed](/crops/blazereed.md)
- [BobsYerUncleRanks](/crops/bobsyeruncleranks.md)
- [Cassitine](/crops/cassitine.md)
- [Coppon](/crops/coppon.md)
- [Corium](/crops/corium.md)
- [Egg Plant](/crops/eggplant.md)
- [Ferrofern](/crops/ferrofern.md)
- [Galvania](/crops/galvania.md)
- [Malaxia](/crops/malaxia.md)
- [Milk Wart](/crops/milkwart.md)
- [Plumbilia](/crops/plumbilia.md)
- [Plumbshade](/crops/plumbshade.md)
- [Red Straw](/crops/redstraw.md)
- [Slimeplant](/crops/slimeplant.md)
- [Thiosulfine](/crops/thiosulfine.md)
- [Trollplant](/crops/trollplant.md)

### Tier 7

- [Argentia](/crops/argentia.md)
- [Coffee](/crops/coffee.md)
- [Creeperweed](/crops/creeperweed.md)
- [Ember Moss](/crops/embermoss.md)
- [Garnydinia](/crops/garnydinia.md)
- [Lazulia](/crops/lazulia.md)
- [Meatrose](/crops/meatrose.md)
- [Spanish Moss](/crops/spanishmoss.md)
- [Thauminite Ore Berry](/crops/thauminiteoreberry.md)
- [Thaumium Ore Berry](/crops/thaumiumoreberry.md)
- [Void Ore Berry](/crops/voidoreberry.md)

### Tier 8

- [Auronia](/crops/auronia.md)
- [Evil Ore](/crops/evilore.md)
- [Knightmetal Berry](/crops/knightmetalberry.md)
- [Liveroot](/crops/liveroot.md)
- [Silviscus](/crops/silviscus.md)
- [Tearstalks](/crops/tearstalks.md)
- [Withereed](/crops/withereed.md)

### Tier 9

- [God of Thunder](/crops/godofthunder.md)
- [Micadia](/crops/micadia.md)
- [Titania](/crops/titania.md)

### Tier 10

- [Enderbloom](/crops/enderbloom.md)
- [Steeleafranks](/crops/steeleafranks.md)

### Tier 11

- [Platina](/crops/platina.md)

### Tier 12

- [Diareed](/crops/diareed.md)
- [Iridine](/crops/iridine.md)
- [Osmianth](/crops/osmianth.md)
- [Pyrolusium](/crops/pyrolusium.md)
- [Reactoria](/crops/reactoria.md)
- [Scheelinium](/crops/scheelinium.md)
- [Star Wart](/crops/starwart.md)
- [Stargatium](/crops/stargatium.md)
- [Transformium](/crops/transformium.md)

### Tier 13

- [Magical Nightshade](/crops/magicalnightshade.md)
- [Space FlowerS](/crops/spaceflower.md)

### Tier 16

- [Primordial Berry](/crops/primordialberry.md)

