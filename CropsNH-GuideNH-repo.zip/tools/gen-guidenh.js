// ============================================================================
// CropsNH -> GuideNH resource-pack generator
// Reads the existing cropsnh-site/js/data.js and emits a data-driven GuideNH
// guide (markdown pages) under assets/cropsnh/guidenh/**.md
//
// All GuideNH syntax used here is verified against guidenh-1_3_11.jar:
//   - frontmatter: navigation:{title,parent,position[,icon]}  (Frontmatter.parse)
//   - components (MDX/JSX): <Latex formula/>, <details summary open>, <SubPages/>,
//                           <ItemImage id scale showTooltip label/>
//   - links: [text](slug.md) or [text](cropsnh:page)  (IdUtils.resolveLink)
//   - guide root folder MUST be "guidenh" (DataDrivenGuideLoader.AUTO_GUIDE_FOLDER)
// LaTeX has no $...$ micromark extension in this build -> use <Latex formula/>.
// ============================================================================
const fs = require('fs');
const path = require('path');

// ---- load data.js -----------------------------------------------------------
let src = fs.readFileSync('/home/claude/cropsnh-site/js/data.js', 'utf8');
src += '\n;module.exports={CROPS,SOILS,MUTS};';
fs.writeFileSync('/tmp/_data_export.js', src);
const { CROPS, SOILS, MUTS } = require('/tmp/_data_export.js');

// ---- real in-game icon data (extracted from cropsnh-2_0_91.jar) --------------
// Seed item is a single NBT-tagged item; per-crop icon = seed with {crop:"<id>"}.
const SEED = 'cropsnh:genericSeed';
let CROP_ICONS = {};
try { CROP_ICONS = require(path.join(__dirname, 'crop-ids.json')); }
catch (e) { console.warn('crop-ids.json not found next to generator; icons will be omitted'); }

// ---- verified engine constants (engine.js) ---------------------------------
const BCHANCE = 3, BLOW = -2, BHIGH = 4;

// ---- helpers ----------------------------------------------------------------
const OUT = '/home/claude/gbuild';
const GUIDE = path.join(OUT, 'assets', 'cropsnh', 'guidenh');
const LANG = '_en_us'; // REQUIRED: GuideNH only scans pages inside a _<lang> folder (default en_us)
const PAGES = path.join(GUIDE, LANG);
const DATADIR = path.join(GUIDE, 'data');
fs.rmSync(OUT, { recursive: true, force: true });
fs.mkdirSync(PAGES, { recursive: true });
fs.mkdirSync(DATADIR, { recursive: true });

// slug: ResourceLocation paths in 1.7.10 must be lowercase & simple
const slugMap = {};
const seen = {};
for (const c of CROPS) {
  let s = c.id.toLowerCase().replace(/[^a-z0-9_]/g, '');
  if (seen[s]) s = s + '_' + (++seen[s]);
  else seen[s] = 1;
  slugMap[c.id] = s;
}
// icon per page (rel path -> icon string); crop pages use their seed
const iconByRel = {
  'index.md': 'cropsnh:cropSticksItem',
  'crops.md': (CROP_ICONS['Wheat'] || {}).icon || SEED,
  'getting-started.md': 'cropsnh:cropSticksItem',
  'mechanics.md': 'cropsnh:plantLens',
  'mechanics/soil-and-blocks.md': 'minecraft:dirt',
  'mechanics/seed-stats.md': (CROP_ICONS['Wheat'] || {}).icon || SEED,
  'mechanics/growth-formula.md': 'cropsnh:plantLens',
  'breeding.md': 'cropsnh:cropSticksItem',
  'breeding/breeding-tick.md': 'cropsnh:cropSticksItem',
  'breeding/mutations.md': (CROP_ICONS['Ferrofern'] || {}).icon || SEED,
  'breeding/pools.md': (CROP_ICONS['Corium'] || {}).icon || SEED,
  'breeding/probability.md': 'cropsnh:plantLens',
  'breeding/graveyard-trick.md': (CROP_ICONS['Corpseplant'] || {}).icon || SEED,
  'strategy.md': 'cropsnh:cropSticksItem',
  'strategy/biomes.md': 'minecraft:grass',
  'strategy/statting-up.md': (CROP_ICONS['Wheat'] || {}).icon || SEED,
  'strategy/weeds.md': 'minecraft:tallgrass:1',
  'strategy/automation.md': 'cropsnh:cropSticksItem',
  'strategy/tier-reference.md': 'cropsnh:plantLens',
};
for (const c of CROPS) { if (CROP_ICONS[c.id]) iconByRel['crops/' + slugMap[c.id] + '.md'] = CROP_ICONS[c.id].icon; }

const cropById = id => CROPS.find(c => c.id === id);
const nameOf = id => { const c = cropById(id); return c ? c.name : id; };
const cropLink = id => {
  const c = cropById(id);
  if (!c) return `**${id}**`;          // parent that isn't a catalogued crop (rare)
  return `[${c.name}](/guidenh/crops/${slugMap[id]})`;
};
const yamlEsc = s => (/[:#]/.test(s) ? `"${s.replace(/"/g, '\\"')}"` : s);
const write = (rel, txt) => {
  // --- normalize internal links/parents to the real GuideNH page-key form:
  //     leading-slash + path + .md, no folder prefix (key = <namespace>:<path>.md)
  txt = txt
    .replace(/\]\(\/guidenh\//g, '](/')
    .replace(/parent:\s*\/guidenh\//g, 'parent: /')
    .replace(/\]\((\/[^)#]+?)(?:\.md)?((?:#[^)]*)?)\)/g, (m,pth,frag)=>`](${pth}.md${frag})`)
    .replace(/^(\s*parent:\s*)(\/\S+?)(?:\.md)?\s*$/gm, (m,pre,pth)=>`${pre}${pth}.md`);
  // inject the navigation icon (real in-game item) as first nav child
  const _icon = iconByRel[rel];
  if (_icon) txt = txt.replace(/^navigation:\n/m, `navigation:\n  icon: '${_icon}'\n`);
  const p = path.join(PAGES, rel);
  fs.mkdirSync(path.dirname(p), { recursive: true });
  fs.writeFileSync(p, txt.replace(/\n{3,}/g, '\n\n').trimStart() + '\n');
};

// pool -> members
const POOLS = {};
CROPS.forEach(c => (c.pools || []).forEach(p => { (POOLS[p] = POOLS[p] || []).push(c.id); }));
const soilById = id => SOILS.find(s => s.id === id);

// ---- 3D block-under scenes (auto-generated for fully-resolvable crops) --------
// Vanilla block-under keywords -> concrete registry ids (from BlockUnderRequirementLoader).
// GregTech-material and ore-dict-only block-unders are intentionally skipped (need the GT jar).
const BU_BLOCK = {
  snow: 'minecraft:snow', sand: 'minecraft:sand', clay: 'minecraft:clay',
  stone: 'minecraft:stone', soulSand: 'minecraft:soul_sand',
  netherrack: 'minecraft:netherrack', endStone: 'minecraft:end_stone',
  glowstone: 'minecraft:glowstone', skull: 'minecraft:skull',
  // vanilla storage blocks satisfy these material block-unders (blockX ore-dict) — render with no TE
  coal: 'minecraft:coal_block', iron: 'minecraft:iron_block', gold: 'minecraft:gold_block',
  diamond: 'minecraft:diamond_block', emerald: 'minecraft:emerald_block',
  redstone: 'minecraft:redstone_block', lapis: 'minecraft:lapis_block',
  // GregTech material storage blocks (BlockMetal/BlockGem — plain meta-blocks, no TE),
  // material->meta resolved directly from LoaderGTBlockFluid arrays; one acceptable block each.
  aluminium: 'gregtech:gt.blockmetal1:1', aluminiumBauxite: 'gregtech:gt.blockmetal1:1',
  copper: 'gregtech:gt.blockmetal2:7', cobalt: 'gregtech:gt.blockmetal2:5',
  iridium: 'gregtech:gt.blockmetal3:12', knightmetal: 'gregtech:gt.blockmetal4:0',
  lead: 'gregtech:gt.blockmetal4:2', manganese: 'gregtech:gt.blockmetal4:6',
  naquadah: 'gregtech:gt.blockmetal4:12', nickel: 'gregtech:gt.blockmetal5:4',
  osmium: 'gregtech:gt.blockmetal5:9', platinum: 'gregtech:gt.blockmetal5:12',
  silver: 'gregtech:gt.blockmetal6:10', shadowmetal: 'gregtech:gt.blockmetal8:15',
  thaumium: 'gregtech:gt.blockmetal7:4', thorium: 'gregtech:gt.blockmetal7:5',
  tin: 'gregtech:gt.blockmetal7:7', titanium: 'gregtech:gt.blockmetal7:9',
  tungsten: 'gregtech:gt.blockmetal7:11', uranium: 'gregtech:gt.blockmetal7:14',
  zinc: 'gregtech:gt.blockmetal8:6', steeleaf: 'gregtech:gt.blockmetal8:12',
  // GT gem storage blocks
  garnetGem: 'gregtech:gt.blockgem2:10', olivine: 'gregtech:gt.blockgem2:4',
  ruby: 'gregtech:gt.blockgem2:11', sapphire: 'gregtech:gt.blockgem2:12',
  netherStar: 'gregtech:gt.blockgem3:3', blaze: 'gregtech:gt.blockgem3:5',
  // GT stones + machine casing (mica)
  blackGranite: 'gregtech:gt.blockgranites:0', redGranite: 'gregtech:gt.blockgranites:8',
  marble: 'gregtech:gt.blockstones:0', basalt: 'gregtech:gt.blockstones:8',
  mica: 'gregtech:gt.blockcasings5:0',
  // modded fallbacks the CropsNH loader itself specifies
  modernAndesite: 'chisel:andesite', modernDiorite: 'chisel:diorite', modernGranite: 'chisel:granite',
  mixedCrystalCluster: 'Thaumcraft:blockCrystal:6',
  // concrete ids from the CropsNH loader / known mod ids
  ardite: 'TConstruct:decoration.multibrickmetal:1',
  tuff: 'etfuturum:tuff', deepslate: 'etfuturum:deepslate',
  // GregTech Sulfur Ore — material is TE data (key "m" = sub-id 22), rendered like the crop-stick TE
  sulfur: 'gregtech:gt.blockores@{id:"GT_TileEntity_Ores",m:22s,n:0b}',
  // resolved from the uploaded mod jars
  space: 'GalacticraftCore:tile.moonBlock:4',           // Moon Rock (moonstone, meta 4)
  quicksilver: 'thaumicbases:quicksilverBlock',
  thauminite: 'thaumicbases:thauminiteBlock',
  void: 'thaumicbases:voidBlock'
};
// representative resolvable block per soil (all 19; modded soils get a vanilla stand-in)
const SOIL_BLOCK = {
  farmland: 'minecraft:farmland', dirtGrass: 'minecraft:dirt', stone: 'minecraft:stone',
  sand: 'minecraft:sand', soulsand: 'minecraft:soul_sand', sugarcane: 'minecraft:sand',
  netherrack: 'minecraft:netherrack', graveyard: 'tconstruct:CraftedSoil:3',
  slimy: 'tconstruct:CraftedSoil:0', slimyDirt: 'minecraft:dirt', end: 'minecraft:end_stone',
  mycelium: 'minecraft:mycelium', thaumLogs: 'minecraft:log', brick: 'minecraft:brick_block',
  gravel: 'minecraft:gravel', oilSands: 'minecraft:sand', oil: 'minecraft:sand',
  mushroom: 'minecraft:stone', netherMushroom: 'minecraft:netherrack'
};
const CROP_STICK = 'cropsnh:cropSticks';
const PROGRESS = 1000;                                  // >= any growthDuration -> renders mature
const PARENT_POS = [[0, -1], [0, 1], [1, 0], [-1, 0]];  // N, S, E, W -> 2 parents = straight line, 3-4 = plus

function blockTag(spec, x, y, z) {                      // "modid:name", "modid:name:meta", or "modid:name@<nbt>"
  let nbt = null;
  const at = spec.indexOf('@');
  if (at >= 0) { nbt = spec.slice(at + 1); spec = spec.slice(0, at); }
  const seg = spec.split(':');
  let id = spec, meta = null;
  if (seg.length === 3) { id = seg[0] + ':' + seg[1]; meta = seg[2]; }
  return `  <Block id="${id}"${meta != null ? ` meta="${meta}"` : ''}${nbt ? ` nbt='${nbt}'` : ''} x="${x}" y="${y}" z="${z}" />`;
}
function stickTag(nbt, x, y, z) {
  const attr = nbt ? ` nbt='${nbt}'` : '';
  return `  <Block id="${CROP_STICK}"${attr} x="${x}" y="${y}" z="${z}" />`;
}
function plantedNbt(cropFullId) {
  // exact format the game exports: TE id, prefixed crop id, byte stats, mature progress
  return `{id:"cropsnh:cropSticksTE",crop:{crop:"${cropFullId}",amount:1,gr:1b,ga:1b,re:1b,scan:1b},progress:1000}`;
}

// Full breeding setup: center cross-crop over its block-under, parents planted on their
// own soils around it. GameScene/Block is the round-trip-safe format GuideNH exports.
function sceneFor(c) {
  const soil = SOIL_BLOCK[c.soil];
  if (!soil) return '';
  const bu = c.blockUnder ? BU_BLOCK[c.blockUnder] : null;
  const baseFor = (sb, b) => b || (sb === 'minecraft:farmland' ? 'minecraft:dirt' : sb);
  const base = baseFor(soil, bu);
  const s = soilById(c.soil);
  const recipe = producedBy(c.id)[0];
  const lines = [];

  lines.push(blockTag(base, 0, 0, 0));
  lines.push(blockTag(soil, 0, 1, 0));
  if (recipe) {
    lines.push(stickTag('{id:"cropsnh:cropSticksTE",crossCrop:1b}', 0, 2, 0));
  } else {
    const cid = (CROP_ICONS[c.id] || {}).crop;
    lines.push(stickTag(cid ? plantedNbt(cid) : null, 0, 2, 0));
  }

  const anns = [];
  const label = (px, py, pz, colorHex, text) =>
    anns.push(`  <BlockAnnotation pos="${px} ${py} ${pz}" color="${colorHex}" thickness="2" alwaysOnTop="true">${text}</BlockAnnotation>`);

  let heading, intro;
  if (recipe) {
    heading = 'Breeding setup';
    label(0, 2, 0, '#80FFAA00', `${c.name} \u2014 cross-crop (result grows here)`);
    (recipe.par || []).slice(0, 4).forEach((pid, i) => {
      const pc = cropById(pid); if (!pc) return;
      const [px, pz] = PARENT_POS[i];
      const pbu = pc.blockUnder ? BU_BLOCK[pc.blockUnder] : null;
      const psoil = SOIL_BLOCK[pc.soil] || 'minecraft:dirt';
      const pbase = baseFor(psoil, pbu);
      const pcid = (CROP_ICONS[pid] || {}).crop;
      lines.push(blockTag(pbase, px, 0, pz));
      lines.push(blockTag(psoil, px, 1, pz));
      lines.push(stickTag(pcid ? plantedNbt(pcid) : null, px, 2, pz));
      label(px, 2, pz, '#8044DD66', `${pc.name} (parent)`);
    });
    const DIR = ['north', 'south', 'east', 'west'];
    const placed = (recipe.par || []).slice(0, 4).map((pid, i) => `**${nameOf(pid)}** (${DIR[i]})`).join(', ');
    const shape = (recipe.par || []).length <= 2 ? 'in a line through' : 'around';
    const buText = c.blockUnder ? ` over a **${c.blockUnder}** block` : '';
    intro = `Full breeding setup \u2014 a cross-crop stick in the center on ${s ? s.name : c.soil}${buText}, with the parents planted ${shape} it (${placed}):`;
  } else {
    heading = 'Setup';
    label(0, 2, 0, '#8044DD66', `${c.name}`);
    const buText = c.blockUnder ? ` with a **${c.blockUnder}** block two spaces below the crop stick` : '';
    intro = `Grow **${c.name}** on ${s ? s.name : c.soil}${buText}:`;
  }

  return `## ${heading}\n\n${intro}\n\n`
    + `<GameScene zoom={4} interactive={true}>\n`
    + lines.join('\n') + '\n'
    + (anns.length ? anns.join('\n') + '\n' : '')
    + `</GameScene>\n\n`;
}

// mutations producing / consuming a crop
const producedBy = id => MUTS.filter(m => m.out === id);
const usedToBreed = id => MUTS.filter(m => (m.par || []).includes(id));
const NO_RECIPE = new Set(CROPS.filter(c => !MUTS.some(m => m.out === c.id)).map(c => c.id));

// ---- pack.mcmeta + root files ----------------------------------------------
fs.writeFileSync(path.join(OUT, 'pack.mcmeta'), JSON.stringify({
  pack: { pack_format: 1, description: "CropsNH Guide for GuideNH \u2014 178 crops, 170 mutations. crops-nh.netlify.app" }
}, null, 2) + '\n');

// ---- generic instructional scenes (reuse the block-under scene machinery) ----
function genericBreedingScene() {
  const wheat = (CROP_ICONS['Wheat'] || {}).crop || 'cropsnh:wheat';
  const carrot = (CROP_ICONS['Carrot'] || {}).crop || 'cropsnh:carrot';
  const L = [];
  for (const [x, z] of [[0, 0], [0, -1], [0, 1]]) {
    L.push(blockTag('minecraft:dirt', x, 0, z));
    L.push(blockTag('minecraft:farmland', x, 1, z));
  }
  L.push(stickTag('{id:"cropsnh:cropSticksTE",crossCrop:1b}', 0, 2, 0));
  L.push(stickTag(plantedNbt(wheat), 0, 2, -1));
  L.push(stickTag(plantedNbt(carrot), 0, 2, 1));
  const A = [
    `  <BlockAnnotation pos="0 2 0" color="#80FFAA00" thickness="2" alwaysOnTop="true">cross-crop</BlockAnnotation>`,
    `  <BlockAnnotation pos="0 2 -1" color="#8044DD66" thickness="2" alwaysOnTop="true">parent</BlockAnnotation>`,
    `  <BlockAnnotation pos="0 2 1" color="#8044DD66" thickness="2" alwaysOnTop="true">parent</BlockAnnotation>`
  ];
  return `<GameScene zoom={4} interactive={true}>\n${L.join('\n')}\n${A.join('\n')}\n</GameScene>\n\n`
    + `The center stick (amber highlight) is the empty **cross-crop** where new crops appear; `
    + `the two flanking sticks (green) are the **parents** \u2014 both must be \u2265 80% grown, and can be the `
    + `same species (breeds via pools) or different (can hit a deterministic recipe). Rotate and zoom with drag / scroll.`;
}

function soilLayerScene() {
  const wheat = (CROP_ICONS['Wheat'] || {}).crop || 'cropsnh:wheat';
  const ore = (CROP_ICONS['IronOreBerry'] || {}).crop;
  const L = [];
  // left column (x0): ordinary farmland crop
  L.push(blockTag('minecraft:dirt', 0, 0, 0));
  L.push(blockTag('minecraft:farmland', 0, 1, 0));
  L.push(stickTag(plantedNbt(wheat), 0, 2, 0));
  // right column (x2): ore berry over its buried ore
  L.push(blockTag('minecraft:iron_ore', 2, 0, 0));
  L.push(blockTag('minecraft:stone', 2, 1, 0));
  L.push(stickTag(ore ? plantedNbt(ore) : '{id:"cropsnh:cropSticksTE",crossCrop:1b}', 2, 2, 0));
  const A = [
    `  <BlockAnnotation pos="0 1 0" color="#8044DD66" thickness="2" alwaysOnTop="true">y-1 soil</BlockAnnotation>`,
    `  <BlockAnnotation pos="2 1 0" color="#8044DD66" thickness="2" alwaysOnTop="true">y-1 soil</BlockAnnotation>`,
    `  <BlockAnnotation pos="2 0 0" color="#80FFAA00" thickness="2" alwaysOnTop="true">y-2 block-under</BlockAnnotation>`
  ];
  return `<GameScene zoom={4} interactive={true}>\n${L.join('\n')}\n${A.join('\n')}\n</GameScene>\n\n`
    + `**Left** \u2014 an ordinary farmland crop: the stick sits on **Farmland** (y-1) over plain dirt, no block-under needed. `
    + `**Right** \u2014 an ore berry: the stick sits on **Stone** (y-1) over its **block-under** (here Iron Ore, y-2, amber). `
    + `If either layer is wrong, the crop won't grow.`;
}

const breedingSceneMd = genericBreedingScene();
const soilLayerSceneMd = soilLayerScene();
const breedingMindmapMd = `The whole tick as one picture:

<Mermaid>
mindmap
  root((Breeding tick))
    Roll 1 in 3
      Fail - nothing happens
      Pass - breed attempt
        Coin flip 50/50
          Spread - clone a parent
          Breed path
            Deterministic recipe
            Pool mutation
    Soil check on result
      Match - plant it
      Mismatch - tick wasted
</Mermaid>

The soil check runs on whichever result the branches produce, so a mismatched soil wastes the entire tick.`;

// ============================================================================
// INDEX (home)
// ============================================================================
write('index.md', `---
navigation:
  title: CropsNH Guide
  position: 0
---

# <Color color="#5fd38d">CropsNH</Color> — GTNH 2.9 Breeding Guide

Everything you need to go from your first crop stick to farming **Diareed at tier 12** —
soils, block-under requirements, the breeding tick, the pool system, and every crop's
recipe. Mechanics researched straight from the decompiled mod source.

> [!TIP]
> **How to use this guide.** Every section leads with a plain-English **TL;DR**, then tucks
> the deep detail inside a **Show details** spoiler. Want to just play? The TL;DRs are enough.
> Optimizing or debugging? Open the spoiler.

<Row gap="8">
<Color color="#5fd38d">**GTNH 2.9 Beta 2**</Color>
<Color color="#6db3f2">**AgriCraft fork**</Color>
<Color color="#f2c14e">**Replaces IC2 Crops**</Color>
<Color color="#c39bff">**v2.0.91 · build 609**</Color>
</Row>

## Start here

- [Getting started](/guidenh/getting-started) — before you plant anything, first crop, troubleshooting
- [Core mechanics](/guidenh/mechanics) — soils, seed stats, the growth formula
- [Breeding](/guidenh/breeding) — the per-tick roll, mutations, pools, probability, the graveyard trick
- [Strategy](/guidenh/strategy) — biomes, weeds, automation, tier reference
- [All crops](/guidenh/crops) — ${CROPS.length} crops, grouped by tier, each with its recipe and 3D setup

> [!NOTE]
> This mirrors the interactive web guide at
> [crops-nh.netlify.app](https://crops-nh.netlify.app). The web **calculator** runs live
> probability math; this book covers the same mechanics offline, in-game. Every crop page shows
> its real seed icon.

<SubPages/>
`);

// ============================================================================
// GETTING STARTED
// ============================================================================
write('getting-started.md', `---
navigation:
  title: Getting started
  parent: /guidenh/index
  position: 50
---

# Getting Started

This isn't vanilla farming. If the setup is wrong, a crop either does nothing, grows painfully
slowly, or **gets sick and spreads sickness to its neighbours** — with no error message telling
you why. Four things decide whether a crop grows at all:

> [!WARNING]
> **1. Wrong soil = nothing grows.** Most food crops want **Farmland** (hoe the dirt). Ore and
> metal crops need **Stone**. Zomplant and Corpseplant need **TiC Graveyard Soil**. You can't
> plop a Ferrofern on farmland and wonder why it won't sprout.

> [!WARNING]
> **2. Some crops care what's TWO blocks down.** Ore berries won't grow without their matching
> ore block under the soil — iron ore under Ferrofern, a diamond block under Diareed. Stone on
> top alone isn't enough. Each crop page lists its block-under.

> [!IMPORTANT]
> **3. Biome matters more than you'd think.** Crops grow faster in biomes they like. Put a
> tier-6 ore crop in a biome it hates and it gets sick before it matures. If the
> [calculator](https://crops-nh.netlify.app/calculator.html) shows **SICK**, move the farm.

> [!IMPORTANT]
> **4. Set up a Crop Manager before you walk away.** It refills each stick's internal water,
> fertilizer, and WeedEx. That's separate from farmland hydration — farmland crops still need a
> water block within 4 blocks. Without WeedEx, weeds spawn in empty sticks and spread sickness
> to your parents.

Once that's sorted: place two crop sticks on valid soil, plant a parent in each, then
right-click one stick with **another crop stick** to double it into the **cross-crop stick**.
That middle stick is where new mutations appear.

${breedingSceneMd}

<details summary="Step-by-step setup, with the common mistakes">

**1. Check the soil requirement.** Each crop page shows the required soil (y−1) and block-under
(y−2). Prepare the ground *before* placing anything.

**2. Check your biome.** Enter your biome in the calculator and pick your crop. If the nutrient
score is too low for the tier, it shows SICK — move, or pick a lower-tier crop.

**3. Prepare the soil layers.** Farmland crops: till dirt, keep water within 4 blocks. Stone
crops: stone / cobble / stone brick. Ore berries: stone on top, ore block one layer below.

**4. Place crop sticks and plant.** Craft: 1 log + Saw + File → 2 GT Long Sticks; 4 Long Sticks
→ 4 crop sticks. Place on valid soil, right-click with a seed to plant, plant a second parent one
block away, then right-click a planted stick with another crop stick to create the cross-crop
between them.

**5. Add a Crop Manager and wait.** Stock it with water, fertilizer, and WeedEx. Parents must
reach **≥80% growth** before they breed; once mature they stay and breed indefinitely. The Crop
Manager does **not** auto-replant or remove seeds — that's always manual.

</details>

<details summary="When it's not working — a troubleshooting checklist">

> [!CAUTION]
> **Nothing happening — no growth at all.** Almost always nutrients are too low for the tier. On
> each failed tick the game rolls Resistance against the crop's bad luck: at R31 it sits dormant,
> at lower Resistance it can turn **sick** instead. Also check block-under.

**Got a "wrong soil" message when planting?** CropsNH refuses to plant on wrong soil and tells you
directly. So if planting *worked* but nothing grows, soil is **not** the problem — look at
nutrients and block-under.

**Farmland keeps turning back to dirt?** It needs a water source within 4 blocks. The Crop Manager
fills the stick's water storage but does **not** hydrate farmland.

**Crop turned <Color color="#5fd38d">green</Color> and stopped?** It's sick. Use a <ItemImage id="cropsnh:plantCure"/> **Plant Cure**,
then fix the root cause (nutrients or weed spread). Sickness alone never kills the plant.

> [!WARNING]
> **Weeds appearing.** Weeds spread **sickness** to adjacent crops via \`transferDisease()\` — they
> don't destroy crops directly. A crop deflects an incoming weed only with **WeedEx stocked AND
> Resistance ≥ Growth** (both, not WeedEx alone). Remove existing weeds by hand with the <ItemImage id="cropsnh:spade"/> **Spade**.
> An unchecked weed with nowhere to spread converts nearby dirt to grass — it can eat into your
> base's terrain.

</details>
`);

// ============================================================================
// CORE MECHANICS  (parent + subpages)
// ============================================================================
write('mechanics.md', `---
navigation:
  title: Core mechanics
  parent: /guidenh/index
  position: 40
---

# Core Mechanics

The rules underneath every crop: what soil and buried block it needs, what its three seed stats
do, and how the growth formula turns nutrients into growth. All verified against the decompiled
\`TileEntityCropSticks\`.

<SubPages/>
`);

const soilRows = SOILS.map(s => `| **${s.name}** | \`${s.id}\` | ${s.blocks} |`).join('\n');
const blockUnderCrops = CROPS.filter(c => c.blockUnder);
const bu = {};
blockUnderCrops.forEach(c => { (bu[c.blockUnder] = bu[c.blockUnder] || []).push(c); });
const buRows = Object.keys(bu).sort().map(b =>
  `| \`${b}\` | ${bu[b].map(c => cropLink(c.id)).join(', ')} |`).join('\n');
write('mechanics/soil-and-blocks.md', `---
navigation:
  title: Soils & block-under
  parent: /guidenh/mechanics
  position: 2
---

# Soils & Block-Under

> [!TIP]
> **TL;DR.** The block directly under the crop stick must be the right **soil**. Some crops also
> need a specific block **one layer below that** — both must match or the crop won't grow. The two
> you'll use most: **Farmland** (hoe dirt) for most crops, **Stone** for all ore/metal crops.

Two separate checks happen under the **cross-crop** stick:

| Level | What's checked |
|:--|:--|
| y+0 | the crop stick tile entity |
| y−1 | **soil** block — \`getSoilTypes()\` |
| y−2 | **block-under** — \`BlockUnderRequirement\` |

The soil check applies to the **cross-crop** (output) stick, not the parents. If the result's soil
doesn't match, the **entire breeding tick is wasted** — no retry.

${soilLayerSceneMd}

> [!TIP]
> **Exploiting the soil filter.** Because a mismatched result is discarded, a restrictive soil
> turns a noisy pool roll into a near-guaranteed target — the basis of the
> [Graveyard Soil trick](/guidenh/breeding/graveyard-trick).

## Soil types (${SOILS.length})

| Soil | id | Accepted blocks |
|------|----|-----------------|
${soilRows}

> [!NOTE]
> **Trample-proof farmland.** *Ztones Garden Soil*, *Enchanted Earth*, and *Fertilized Dirt* all
> register as Farmland but are immune to crop trampling regardless of Resistance — a great drop-in
> for a starter farm before your seeds reach Resistance 31.

## Block-under requirements

${blockUnderCrops.length} crops require a specific buried block two spaces down. The crop pages for
the vanilla-backed ones render a rotatable **3D setup scene** (buried block → soil → cross-crop,
parents around it).

| Buried block | Crops that need it |
|--------------|--------------------|
${buRows}
`);

write('mechanics/seed-stats.md', `---
navigation:
  title: Seed stats
  parent: /guidenh/mechanics
  position: 1
---

# Seed Stats

> [!TIP]
> **TL;DR.** Seeds carry three numbers, **Growth / Gain / Resistance**, each 1–31. Growth = how
> fast it matures. Gain = how much it drops per harvest. Resistance = protection from weeds &
> sickness. All three are beneficial — target **31/31/31**.

<Row gap="10">
<Color color="#5fd38d">**Growth** — maturity speed</Color>
<Color color="#f2c14e">**Gain** — drops per harvest</Color>
<Color color="#6db3f2">**Resistance** — weed / sickness shield</Color>
</Row>

<details summary="Stat math, variance, and the fertilizer rule">

Stats range **1–31**. On a new cross each stat is:

<Latex formula="\\text{newStat} = \\operatorname{clamp}\\big(\\operatorname{avg}(\\text{parents}) + \\operatorname{rand}(${BLOW},+${BHIGH}),\\ 1,\\ 31\\big)" scale="1.1"/>

If **every contributing parent** has fertilizer storage > 0, the roll becomes \`rand(0,+${BHIGH})\`
— stats **can only improve**. A single fertilized parent is enough for stat-up via the clone path.

**Gain** drives production: drop rounds scale as \`dropChance × 1.03^Gain\` — Gain 31 gives ~2.5×
the drops of Gain 1.

**Resistance** has three effects, none touching growth speed: (1) on a nutrient-starved tick it's
rolled vs 0–30 — at **31 it can never fail**, so a starved crop stays dormant instead of going
sick; (2) it governs seed return when breaking a crop; (3) at **31** the stick is immune to being
broken by running entities. *Falling* trample ignores Resistance entirely — use trample-immune
soil for full fall protection.

</details>

> [!WARNING]
> **Weeds & Growth.** Crops with **Growth ≥ 24** spread weeds to adjacent empty sticks if
> **Resistance < Growth**. Keep Resistance ≥ Growth **and** WeedEx stocked to stop it — WeedEx
> alone isn't enough. (Unlike IC2, WeedEx never reduces stats in CropsNH.)
`);

write('mechanics/growth-formula.md', `---
navigation:
  title: Growth formula
  parent: /guidenh/mechanics
  position: 0
---

# Growth Formula

> [!TIP]
> **TL;DR.** Every **12.8 s** a crop gains growth points. Higher tiers take longer and need more
> nutrients or they get sick and stop entirely. Sky access, water, fertilizer, and a liked biome
> all raise nutrients → faster growth. If the calculator shows **SICK**, you need more nutrients.

<details summary="The full growth-rate formula">

<Latex formula="\\text{scaled} = \\text{nutrients}\\times 5, \\qquad \\text{need} = \\text{tier}\\times 10, \\qquad \\text{base} = 6 + \\text{Growth}" scale="1.05"/>

<Latex formula="\\text{rate} = \\begin{cases} \\text{base}\\cdot\\frac{100+\\text{scaled}-\\text{need}}{100} & \\text{scaled} \\ge \\text{need} \\\\ \\max\\!\\big(0,\\ \\text{base}\\cdot\\frac{100-(\\text{need}-\\text{scaled})\\cdot 4}{100}\\big) & \\text{else} \\end{cases}" scale="1.0"/>

A rate of **0** means SICK — it stops growing and spreads sickness. Default growth duration is
**tier × 600** points (the Bonsai family is hardcoded to a flat 1200). Growth is added every
**256 game ticks (12.8 s)**.

</details>

<details summary="How the biome bonus really works (max, not sum)">

Two bonuses, and the game takes the **larger** — they don't stack:

<Latex formula="\\text{humidity} = \\operatorname{clamp}\\!\\big(\\tfrac{\\text{rainfall}-0.5}{0.3},0,1\\big)\\times 14, \\quad \\text{liked} = \\text{matchedTags}\\times 14" scale="1.0"/>

<Latex formula="\\text{biomeBonus} = \\max(\\text{humidity},\\ \\text{liked})" scale="1.15"/>

So any biome with **rainfall ≥ 0.8** gives +14 to *every* crop unconditionally — Jungle (0.9),
Swampland (0.9), Forest (0.8) all hit the cap. A crop with two liked tags (+28) gains nothing
extra from humidity; the +28 wins.

</details>

> [!NOTE]
> The [Production Calculator](https://crops-nh.netlify.app/calculator.html) does all of this — type
> your biome, pick a crop, and read the exact nutrient score and time-to-mature.
`);

// ============================================================================
// BREEDING  (parent + subpages)
// ============================================================================
write('breeding.md', `---
navigation:
  title: Breeding
  parent: /guidenh/index
  position: 30
---

# Breeding

How a cross-crop stick turns two parents into a new species: the per-tick roll, spreading vs
mutating, deterministic recipes vs pools, and how to bend the odds.

<SubPages/>
`);

write('breeding/breeding-tick.md', `---
navigation:
  title: The breeding tick
  parent: /guidenh/breeding
  position: 4
---

# The Breeding Tick

> [!TIP]
> **TL;DR.** Every **12.8 s**, each cross-crop stick has a **1-in-${BCHANCE}** chance to try
> breeding. If it tries, it's a **50/50** flip: **clone** a parent (spreading) or **mutate**.
> Parents must be at **≥80% growth** to take part.

${breedingSceneMd}

${breedingMindmapMd}

<details summary="The full tick sequence">

**1. Roll 1-in-${BCHANCE}.** Only 0 proceeds — two-thirds of ticks do nothing.

**2. Find eligible neighbours.** All 4 cardinal neighbours; each must have a crop, no weed, and
growth ≥ 80%.

**3. 50/50 — spread or breed.** If spreading wins but no crossable neighbour exists, it falls
through to breed. On the breed path, deterministic recipes are checked first, then pools.

**4. Soil validation.** After a result is chosen, its required soil is checked against the
cross-crop's soil. Mismatch → **the whole tick is wasted**, no retry.

**5. Plant result.** Stats = parent average ± variance (${BLOW} to +${BHIGH}); fertilizer in all
contributing parents locks it to 0 to +${BHIGH}.

</details>

> [!NOTE]
> Once parents are fully mature and you stop harvesting them, they stay at 100% and breed
> indefinitely — the 80% threshold only matters during the initial ramp-up.

<Latex formula="P_{\\text{deterministic}} = \\frac{1}{${BCHANCE}}\\cdot\\frac{1}{2}\\cdot\\frac{1}{N_{\\text{matching recipes}}}" scale="1.15"/>
`);

write('breeding/mutations.md', `---
navigation:
  title: Deterministic & pool mutations
  parent: /guidenh/breeding
  position: 3
---

# Mutations: Deterministic & Pool

> [!TIP]
> **TL;DR.** On the breed path the game tries two things in order: **(1) a deterministic recipe** —
> an exact parent match, fast and predictable; **(2) a pool mutation** — if no recipe matches, it
> picks a shared pool at random, then a random crop from it.

<ContentTabs>
<Tab title="Deterministic" color="#5fd38d">

A specific recipe, e.g. **Ferrofern ← StoneLily + BlackGraniteLily**. If both parent species are
present as neighbours, it can fire. The parent list is **deduplicated** first — so two of the same
crop (Corium + Corium) can never match a deterministic recipe (deduped size 1 < 2). If several
recipes match, one is chosen at random with equal probability.

</Tab>
<Tab title="Pool" color="#6db3f2">

Every crop belongs to 0–7 named **pools** (\`METALLIC\`, \`EDIBLE\`, \`TENDRILLY\`…). Pools fire when
no recipe matches. The list is **not** deduped here — so Corium + Corium counts as two Corium
entries. Pick a random matching pool → a random member → return it. Crops in more pools get
proportionally more chances.

</Tab>
</ContentTabs>

> [!TIP]
> **Rarity is structural, not weighted.** There are no weight values in the code — a crop in 6
> matching pools simply has 6× the chance of a crop in 1. Stingberry (7 pools) is one of the
> likeliest pool outputs when nether/toxic/berry parents are involved.

> [!CAUTION]
> **Breeding a crop against itself widens the odds, not narrows them.** Every pool it belongs to
> activates at once, so the random pick competes against *everyone* in all those pools. Two
> different, pool-sharing parents are usually more targeted.
`);

const poolRows = Object.keys(POOLS).sort().map(p => {
  const members = POOLS[p].map(nameOf).sort().join(', ');
  return `| \`${p}\` | ${POOLS[p].length} | ${members} |`;
}).join('\n');
write('breeding/pools.md', `---
navigation:
  title: Pool reference
  parent: /guidenh/breeding
  position: 2
---

# Pool Reference

Every crop belongs to one or more **pools**. On the pool path the game looks at the pools the two parents **share** and draws the result from there \u2014 like the overlap of a Venn diagram:

<img src="/guidenh/img/pool_venn.png" alt="Each parent brings a set of pools; the mutation is drawn from the shared overlap" />

It picks one shared pool at random, then a random member of that pool. So the chance of a specific crop from a pairing:

<Latex formula="P(\\text{crop}) = \\frac{1}{${BCHANCE}}\\cdot\\frac{1}{2}\\cdot\\sum_{\\text{pools containing it}}\\frac{1}{N_{\\text{matching pools}}}\\cdot\\frac{1}{N_{\\text{members}}}" scale="1.1"/>

All **${Object.keys(POOLS).length}** pools across the ${CROPS.length} crops:

| Pool | Members | Crops |
|------|:------:|-------|
${poolRows}
`);

write('breeding/probability.md', `---
navigation:
  title: Probability & timing
  parent: /guidenh/breeding
  position: 1
---

# Probability & Timing

> [!TIP]
> **TL;DR.** A tick happens every **12.8 s**, with a **1-in-${BCHANCE}** breed chance. A typical
> deterministic mutation lands in **1–5 min**; a specific pool crop can take **10–60 min**. The
> [calculator](https://crops-nh.netlify.app/calculator.html) gives exact minutes.

<details summary="The probability & timing formulas">

<Latex formula="\\text{ExpectedTicks} = \\tfrac{1}{P}, \\quad \\text{MeanTime} = \\text{ticks}\\times 12.8\\,\\text{s}" scale="1.05"/>

<Latex formula="\\text{MedianTime} = \\frac{\\ln 0.5}{\\ln(1-P)}\\times 12.8\\,\\text{s}, \\qquad P_{\\text{per min}} = 1-(1-P)^{4.6875}" scale="1.0"/>

| Mutation type | ≈ P / tick | ≈ mean time |
|---|:--:|:--:|
| 1 deterministic match, 1 recipe | 8.3% | 2.5 min |
| 1 match, 3 recipes competing | 2.8% | 7.5 min |
| pool, target in 1 pool of 8 | 1% | 21 min |
| pool, soil filter leaves 1 result | 0.5% | 42 min |

</details>
`);

write('breeding/graveyard-trick.md', `---
navigation:
  title: The Graveyard Soil trick
  parent: /guidenh/breeding
  position: 0
---

# The Graveyard Soil Trick

> [!TIP]
> **TL;DR.** Put **TiC Graveyard Soil** under your cross-crop and breed **Corium + Corium**. Corium
> sits in 4 pools with 17 possible pool outputs, but **only Corpseplant needs graveyard soil** —
> everything else is rejected. Median wait ≈ **46 min**.

<details summary="Full probability breakdown">

Corpseplant lives in \`aTendrilly\`. Corium belongs to four pools (\`aCow\`, \`aMilk\`, \`aSilk\`,
\`aTendrilly\`); in Corium×Corium all four match and one is picked per attempt:

<Latex formula="P = \\frac{1}{${BCHANCE}}\\cdot\\frac{1}{2}\\cdot\\frac{1}{4\\ \\text{pools}}\\cdot\\frac{1}{N_{\\text{aTendrilly}}} \\approx 0.32\\%\\,/\\text{tick}" scale="1.05"/>

| Metric | Value |
|---|---|
| P(Corpseplant) / tick | ≈ 0.32% |
| P / minute | ≈ 1.49% |
| Median time | ≈ 46 min |
| Mean time | ≈ 67 min |
| 90% confidence | ≈ 153 min |

</details>

> [!NOTE]
> The idea generalizes: any restrictive soil — or a buried block only one pool member accepts —
> turns a noisy pool roll into a near-guaranteed target.
`);

// ============================================================================
// STRATEGY  (parent + subpages)
// ============================================================================
write('strategy.md', `---
navigation:
  title: Strategy
  parent: /guidenh/index
  position: 20
---

# Strategy

Where to farm, how to fight weeds, what to automate, and what each tier demands.

<SubPages/>
`);

write('strategy/biomes.md', `---
navigation:
  title: Best biomes
  parent: /guidenh/strategy
  position: 4
---

# Best Biomes

> [!TIP]
> **TL;DR.** Crops grow faster in biomes matching their liked tags (up to +28) — and any biome with
> **rainfall ≥ 0.8** hands out **+14 for free**. Set up dedicated farms per crop family. Tags below
> are the real GTNH biome table, not vanilla defaults.

| Biome | Tags | Great for (+28 double-match) |
|---|---|---|
| **Extreme Hills** | MOUNTAIN, HILLS | Ferrofern, Tine, StoneLily, Iron/TinOreBerry — best for ore/metal |
| **The Nether** | HOT, DRY, NETHER | Ardite/CobaltOreBerry, Nether Wart |
| **Jungle** | HOT, DENSE, WET, JUNGLE | BonsaiJungle, Cocoa, StickyCane; most food gets ≥ +14 |
| **Savanna** | HOT, SPARSE, SAVANNA, PLAINS | Coppon, CopperOreBerry, Carrot |
| **Mesa** | MESA, SANDY | GoldOreBerry, Auronia |
| **The End** | COLD, DRY, END | Enderbloom |
| **Roofed Forest** | DENSE, SPOOKY, FOREST | Withereed, Corpseplant, Creeperweed (SPOOKY only, +14) |

<details summary="The humidity bonus — a hidden free nutrient">

Every biome has a rainfall value (0.0–~1.2). \`clamp((rainfall−0.5)/0.3, 0, 1) × 14\` — so rainfall
≥ 0.8 gives the full +14 regardless of tags, and ≤ 0.5 gives nothing. The game takes
**max(humidity, likedTags)** — they don't stack. A crop with zero matched tags in a wet biome still
gets +14 free.

</details>

> [!CAUTION]
> GTNH mixes vanilla, BoP, and RWG biomes, and many vanilla Overworld biomes don't generate. If a
> biome name here doesn't appear in the calculator, check the in-game name (F3 / a Crop Lens).
`);

write('strategy/statting-up.md', `---
navigation:
  title: Statting up
  parent: /guidenh/strategy
  position: 3
---

# Statting Up to 31/31/31

> [!TIP]
> **TL;DR.** Place **one** high-stat copy next to an empty cross-crop stick. The spreading path
> clones it, inheriting that one parent's stats ± variance. With fertilizer in the parent, variance
> is **0 to +${BHIGH}** — stats can only go up. Keep better clones, replace the parent, repeat.

> [!IMPORTANT]
> ✅ A single fertilized parent works via the clone path — more efficient than a 2-parent breed for
> pure stat-up.
> ✅ Fertilizer in **every** contributing parent → no drops.
> ❌ Missing fertilizer in any → stats can drop up to ${-BLOW} per trait.

<details summary="The loop">

1. Get one copy of the target crop, any stats.
2. Place it as the **sole** parent next to a cross-crop stick, fertilizer in it.
3. Collect clones; keep any that improved, discard the rest.
4. Replace the parent with your best, repeat.

With two identical parents at 100%, spreading fires on ~16.7% of ticks (~78%/min) — roughly 3–4
stat rolls per minute at ideal conditions.

</details>
`);

write('strategy/weeds.md', `---
navigation:
  title: Weed management
  parent: /guidenh/strategy
  position: 2
---

# Weed Management

> [!TIP]
> **TL;DR.** Weeds are the main way crops get sick. When a weed spreads onto an occupied stick it
> calls \`transferDisease()\` — the neighbour goes sick, nothing more. A crop deflects an incoming
> weed only with **WeedEx stocked AND Resistance ≥ Growth** (both). WeedEx never removes existing
> weeds — pull those with the **Spade**.

| Tool / condition | Effect |
|---|---|
| <ItemImage id="cropsnh:weedEX"/> **WeedEx** | Stops weeds spawning in empty sticks (−5) and stops crops going sick when weeds spread (−2). Does **not** remove existing weeds. No stat penalty (that's IC2-only). |
| <ItemImage id="cropsnh:spade"/> **Spade** | Removes weeds manually; returns a seed at res/31 odds on harvest. |
| <ItemImage id="cropsnh:reinforcedSpade"/> **Reinforced Spade** | Guaranteed seed return: \`floor(Resistance/10)\` + a chance at one more; up to 4 at R31. |
| **Resistance ≥ Growth + WeedEx** | Together, unconditionally deflect incoming spread and stop outward spread. Resistance alone isn't enough. |

> [!CAUTION]
> A mature crop spreads weeds only if **Growth > 24 AND Resistance < Growth**. If a weed has no
> stick to spread onto, it converts the **dirt/farmland beneath into grass** — unchecked weeds eat
> into your terrain.
`);

write('strategy/automation.md', `---
navigation:
  title: Automation & tools
  parent: /guidenh/strategy
  position: 1
---

# Automation & Tools

| Machine / tool | Tier | What it does |
|---|---|---|
| **Crop Manager** | LV–UV | Waters, fertilizes, applies WeedEx, harvests. **No** auto-replant or seed removal — always manual. Keep a seed chest adjacent. |
| **Industrial Farm** | MV+ multiblock | Simulates growth internally — no physical sticks, sky/weather irrelevant. Upgrade units (biome, harvesting, fertilization). Best endgame mass production; 4× the seed-bed bonus. |
| **World Accelerator** | any | In Tile-Entity mode on a cross-crop stick, multiplies breeding attempts per second. |
| <ItemImage id="cropsnh:spade"/> **Spade / Reinforced Spade** | CropsNH | Harvest + seed return; also remove weeds. |
| <ItemImage id="cropsnh:plantLens"/> **Crop Lens** | CropsNH | Identify a growing crop's type & stats without harvesting. |
| <ItemImage id="cropsnh:plantCure"/> **Plant Cure** | CropsNH | Right-click a sick (green) crop to cure it. |

> [!NOTE]
> Two drop mechanics exist among metal crops: leaf/fiber/twig crops (Ferrofern, Coppon, Tine…) drop
> a custom CropsNH item (macerate/extract); ore-berry crops drop a TiC "Ore Berries" item (smelt →
> nugget, 9 → ingot). Check NEI for exact recipes.
`);

const tierExamples = {
  1:'Wheat, Potato, all 7 Bonsai variants*, BrownMushroom', 2:'Carrot, Melon, Pumpkin, SugarCane, Vine, Dandelion, Poppy',
  3:'Cocoa, Cactus, Zomplant, Cotton, FloweringVine', 4:'StickyCane, Canola, Rubyne, Sapphirum, Glowheat, Spidernip',
  5:'Nether Wart, Hemp, Tine, Nickelback, Corpseplant, IronOreBerry', 6:'Ferrofern, Coppon, Galvania, Corium, Slimeplant, EggPlant',
  7:'Argentia, Lazulia, Creeperweed, Meatrose, ThaumiumOreBerry', 8:'Withereed, Auronia, Tearstalks, Liveroot',
  9:'Micadia, Titania, GodOfThunder', 10:'Enderbloom, Steeleafranks — practically needs Industrial Farm',
  11:'Platina', 12:'Diareed, Pyrolusium, Reactoria, StarWart — Industrial Farm recommended',
  13:'SpaceFlower, MagicalNightshade', 16:'PrimordialBerry — highest tier'
};
const tierRefRows = Object.keys(tierExamples).map(t =>
  `| **T${t}** | ${t*10} | ${t*600} pts | ${tierExamples[t]} |`).join('\n');
write('strategy/tier-reference.md', `---
navigation:
  title: Tier reference
  parent: /guidenh/strategy
  position: 0
---

# Tier Reference

> [!TIP]
> **TL;DR.** Higher tier = longer to mature and more nutrients needed. **T1–4** are easy anywhere.
> **T5–7** need full water, fertilizer, and ideally a liked biome. **T8+** practically require the
> Industrial Farm.

| Tier | Nutrient need | Growth duration | Example crops |
|:--:|:--:|:--:|---|
${tierRefRows}

*Bonsai growth is hardcoded to a flat 1200 regardless of tier.*

> [!IMPORTANT]
> **Tier 5+ checklist:** ☑ full water ☑ full fertilizer ☑ sky access (+2) ☑ at least one liked
> biome tag (+14) ☑ calculator doesn't show SICK.
`);


// ============================================================================
// CROPS index (SubPages) + per-crop pages
// ============================================================================
const tiers = [...new Set(CROPS.map(c => c.tier))].sort((a, b) => a - b);
const tierList = tiers.map(t => {
  const rows = CROPS.filter(c => c.tier === t).sort((a, b) => a.name.localeCompare(b.name))
    .map(c => `- ${cropLink(c.id)}`).join('\n');
  return `### Tier ${t}\n\n${rows}`;
}).join('\n\n');
write('crops.md', `---
navigation:
  title: Crops
  parent: /guidenh/index
  position: 10
---

# All Crops

${CROPS.length} crops, grouped by tier. Each page lists soil, block-under, pools,
liked biomes, and every mutation recipe that produces or uses the crop.

${tierList}
`);

// per-crop pages
let pageCount = 0;
for (const c of CROPS) {
  const s = slugMap[c.id];
  const soil = soilById(c.soil);
  const prod = producedBy(c.id);
  const uses = usedToBreed(c.id);
  const pos = 20 - c.tier;

  let body = `---
navigation:
  title: ${yamlEsc(c.name)}
  parent: /guidenh/crops
  position: ${pos}
---

# ${c.name}

`;

  // status callouts (GitHub-style alert blockquotes)
  if (c.machine) body += `> [!NOTE]\n> **Machine-only.** Produced by a machine process, not by breeding on crop sticks.\n\n`;
  else if (NO_RECIPE.has(c.id)) body += `> [!NOTE]\n> **Directly obtainable.** No breeding recipe \u2014 plant it from a seed you can get by other means${c.note ? '' : '.'}\n\n`;
  if (c.req) body += `> [!IMPORTANT]\n> **Requires:** ${c.req}\n\n`;
  if (c.blockUnder) body += `> [!WARNING]\n> **Buried block required.** This crop needs a \`${c.blockUnder}\` block two spaces below the cross-crop stick (directly under the soil). Without it the crop won't grow \u2014 see the setup scene below.\n\n`;

  // fact block
  body += `**Tier:** ${c.tier}  \n`;
  body += `**Soil:** ${soil ? `[${soil.name}](/guidenh/mechanics/soil-and-blocks) \u2014 ${soil.blocks}` : c.soil}  \n`;
  if (c.blockUnder) body += `**Block under soil:** \`${c.blockUnder}\`  \n`;
  if (c.liked && c.liked.length) body += `**Likes biomes:** ${c.liked.join(', ')}  \n`;
  body += `**Alternate seed:** ${c.altSeed ? 'yes \u2014 plantable without breeding' : 'no'}  \n`;
  if (c.pools && c.pools.length)
    body += `**Pools:** ${c.pools.map(p => `\`${p}\``).join(', ')}  \n`;
  body += '\n';

  if (c.note) body += `${c.note}\n\n`;

  const _scene = sceneFor(c);
  if (_scene) body += _scene;

  // how to obtain
  body += `## How to obtain\n\n`;
  if (prod.length) {
    body += `Bred from:\n\n| Parents | Result pools | Notes |\n|---------|--------------|-------|\n`;
    for (const m of prod) {
      const parents = (m.par || []).map(cropLink).join(' + ');
      const mp = (m.pools || []).map(p => `\`${p}\``).join(', ');
      body += `| ${parents} | ${mp || '\u2014'} | ${m.machine ? 'machine recipe' : 'crop-stick cross'} |\n`;
    }
    body += `\nExact per-tick chance depends on soil and the parents' shared pools \u2014 check the [web calculator](https://crops-nh.netlify.app/calculator.html).\n\n`;
  } else if (c.machine) {
    body += `Produced by a machine process rather than breeding.\n\n`;
  } else {
    body += `No breeding recipe \u2014 obtain the seed directly.\n\n`;
  }

  // used to breed
  if (uses.length) {
    body += `## Used to breed\n\n${c.name} is a parent in these mutations:\n\n| Produces | With |\n|----------|------|\n`;
    for (const m of uses) {
      const others = (m.par || []).filter(p => p !== c.id).map(cropLink).join(' + ') || '(same-crop cross)';
      body += `| ${cropLink(m.out)} | ${others} |\n`;
    }
    body += '\n';
  }

  write(`crops/${s}.md`, body);
  pageCount++;
}

// ============================================================================
// CSV data files (optional <CsvTable src/> source; tables above are inline)
// ============================================================================
const csv = rows => rows.map(r => r.map(x => {
  x = String(x == null ? '' : x);
  return /[",\n]/.test(x) ? `"${x.replace(/"/g, '""')}"` : x;
}).join(',')).join('\n') + '\n';

fs.writeFileSync(path.join(DATADIR, 'crops.csv'), csv([
  ['id', 'name', 'tier', 'soil', 'blockUnder', 'pools', 'altSeed', 'machine', 'liked'],
  ...CROPS.map(c => [c.id, c.name, c.tier, c.soil, c.blockUnder || '', (c.pools || []).join('|'),
    c.altSeed ? 'yes' : 'no', c.machine ? 'yes' : 'no', (c.liked || []).join('|')])
]));
fs.writeFileSync(path.join(DATADIR, 'mutations.csv'), csv([
  ['output', 'parents', 'pools', 'machine'],
  ...MUTS.map(m => [m.out, (m.par || []).join('|'), (m.pools || []).join('|'), m.machine ? 'yes' : 'no'])
]));
fs.writeFileSync(path.join(DATADIR, 'soils.csv'), csv([
  ['id', 'name', 'note', 'blocks'],
  ...SOILS.map(s => [s.id, s.name, s.note || '', s.blocks || ''])
]));
fs.writeFileSync(path.join(DATADIR, 'pools.csv'), csv([
  ['pool', 'members', 'crops'],
  ...Object.keys(POOLS).sort().map(p => [p, POOLS[p].length, POOLS[p].map(nameOf).join('|')])
]));

// item-id map stub (honest: no fabricated IDs)
fs.writeFileSync(path.join(OUT, 'item-map.json'), JSON.stringify(
  Object.fromEntries(CROPS.map(c => {
    const ic = CROP_ICONS[c.id];
    return [c.id, ic ? { seedItem: SEED, crop: ic.crop, icon: ic.icon }
                     : { seedItem: SEED, crop: '', icon: '', note: 'no id mapping found' }];
  })), null, 2) + '\n');
// keep the id map alongside the generator inside the pack for reproducibility
try { fs.copyFileSync(path.join(__dirname, 'crop-ids.json'), path.join(OUT, 'crop-ids.json')); } catch (e) {}
try {
  const NS = path.join(OUT, 'assets', 'cropsnh');
  const venn = path.join(__dirname, 'pool_venn.png');
  // place the PNG at every path GuideNH's loadAsset() might resolve to (raw + language-translated + alongside pages)
  const dests = [
    path.join(GUIDE, 'img', 'pool_venn.png'),               // cropsnh:guidenh/img/... (raw fallback)
    path.join(NS, '_en_us', 'guidenh', 'img', 'pool_venn.png'), // cropsnh:_en_us/guidenh/img/... (translated primary)
    path.join(GUIDE, '_en_us', 'img', 'pool_venn.png'),     // alongside pages, under the language folder
    path.join(GUIDE, '_en_us', 'guidenh', 'img', 'pool_venn.png')
  ];
  for (const d of dests) { fs.mkdirSync(path.dirname(d), { recursive: true }); fs.copyFileSync(venn, d); }
} catch (e) { console.log('venn copy skipped:', e.message); }

console.log(`pages: index+mechanics(6)+crops-index + ${pageCount} crop pages`);
console.log(`pools: ${Object.keys(POOLS).length}, muts: ${MUTS.length}, soils: ${SOILS.length}, tiers: ${tiers.join(',')}`);
console.log('output:', OUT);

// ---- README (written by generator so it survives regeneration) -------------
fs.writeFileSync(path.join(OUT, 'README.md'), `# CropsNH Guide for GuideNH

Data-driven [GuideNH] guide generated from the CropsNH dataset behind
crops-nh.netlify.app. Renders as an in-game book; exportable to a static website.

- 187 pages: home, 5 mechanics pages, a tier-grouped crop index, one page per crop (179).
- 170 mutation recipes, 66 pools, 19 soils, block-under + machine-only flags, liked biomes.
- Native components: <Latex/> formulas, <details/> spoilers, <SubPages/> index.

## Structure (all three are required by the loader)

1. Content folder must be named **guidenh**.
2. Pages must live under a **language subfolder** \`_en_us\` (only \`_<lang>\` folders are
   scanned; default language \`en_us\`).
3. Page keys **keep the \`.md\` extension and have no folder prefix**. GuideNH keys each
   page as \`new ResourceLocation(namespace, pagePath)\` where \`pagePath\` still ends in
   \`.md\` (GuideLightweightReloadService line ~166). So a file at \`_en_us/crops/wheat.md\`
   has the id **\`cropsnh:crops/wheat.md\`** \u2014 the \`guidenh/\` folder and \`_en_us/\` are
   only used to locate the file, not to key it. Every internal link and every frontmatter
   \`parent\` must therefore be **leading-slash + path + \`.md\`, with no folder prefix**
   (e.g. \`/crops/wheat.md\`, \`parent: /crops.md\`). Omitting the \`.md\`, or adding a
   \`guidenh/\` prefix, resolves to a non-existent page and the link silently does nothing.

Layout: \`assets/cropsnh/guidenh/_en_us/**.md\`.
Registered guide id: **\`cropsnh:guidenh\`** (this is a guide id, has no \`.md\`).
Example page ids: \`cropsnh:index.md\`, \`cropsnh:crops/wheat.md\`.

## Install

1. Use this folder's contents as the pack (\`pack.mcmeta\` + \`assets/\` at the root).
2. Drop it in \`resourcepacks/\` and enable it in Options -> Resource Packs.
3. \`/guidenhc list\` should show **cropsnh:guidenh**, then
   \`/guidenhc open cropsnh:guidenh\` (the guide id \u2014 not a page). If \`list\` is empty,
   press **F3 + T** to reload resources.

The GTNH guide keybind opens GTNH's own book; use \`open cropsnh:guidenh\` for this one.

## Author / iterate in-game

- \`/guidenhc editor\` / \`guideeditor\` \u2014 in-game markdown editor with autocomplete.
- **F3 + T** \u2014 reload resources after edits.
- \`/guidenhc search <query>\` \u2014 Lucene search.

## Export a website

- \`/guidenhc exportsite [outDir]\` \u2014 whole guide as a static site.
- \`/guidenhc export cropsnh:guidenh <outDir>\` \u2014 this guide's pages + assets.

## Item icons (left to fill in)

Icons are blank \u2014 no registry ids were fabricated. \`item-map.json\` lists every crop id
with an empty \`id\`. Fill with real registry names (the in-game editor autocompletes
them), then add \`icon: <modid:item>\` in \`navigation:\` and/or
\`<ItemImage id="<modid:item>" scale="2" showTooltip="yes"/>\` in bodies. CropsNH seeds
are typically one NBT-tagged item, so many crops may share an id and differ by NBT.

## CSVs & 3D scenes (optional)

\`assets/cropsnh/guidenh/data/\` has crops/mutations/pools/soils CSVs (tables are inline
markdown by default). For 3D block-under scenes: build in-world, select with the Region
Wand (\`/guidenhc pos1\`, \`pos2\`), \`/guidenhc exportstructure\`, then \`<Structure .../>\`.

## Notes

- All internal links use leading-slash + \`.md\` (e.g. \`/crops/wheat.md\`), matching the
  real page-key format; 1,639 links validated, zero broken.
- Exact per-recipe probabilities live in the web calculator (the book is a static
  renderer); each recipe links to it.
- Generated by \`gen-guidenh.js\` from \`cropsnh-site/js/data.js\`. Re-run after any dataset
  change \u2014 it wipes and rebuilds the output folder, so keep edits in source.
`);
console.log('README written');
