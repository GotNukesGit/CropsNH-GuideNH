---
navigation:
  icon: 'cropsnh:genericSeed:0:{crop:"cropsnh:wheat"}'
  title: Seed stats
  parent: /mechanics.md
  position: 1
---

# Seed Stats

> [!TIP]
> **TL;DR.** Seeds carry three numbers, **Growth / Gain / Resistance**, each 1–31. Growth = how
> fast it matures. Gain = how much it drops per harvest. Resistance = protection from weeds &
> sickness. All three are beneficial — target **31/31/31**.

<Row gap="10">
<Color color="#5fd38d">**Growth** — maturity speed</Color>
<Color color="#f2c14e">**Gain** — drops per harvest</Color>
<Color color="#6db3f2">**Resistance** — weed / sickness shield</Color>
</Row>

<details>
<summary>Stat math, variance, and the fertilizer rule</summary>

Stats range **1–31**. On a new cross each stat is:

<Latex formula="\text{newStat} = \operatorname{clamp}\big(\operatorname{avg}(\text{parents}) + \operatorname{rand}(-2,+4),\ 1,\ 31\big)" scale="1.1"/>

If **every contributing parent** has fertilizer storage > 0, the roll becomes `rand(0,+4)`
— stats **can only improve**. A single fertilized parent is enough for stat-up via the clone path.

**Gain** drives production: drop rounds scale as `dropChance × 1.03^Gain` — Gain 31 gives ~2.5×
the drops of Gain 1.

**Resistance** has three effects, none touching growth speed: (1) on a nutrient-starved tick it's
rolled vs 0–30 — at **31 it can never fail**, so a starved crop stays dormant instead of going
sick; (2) it governs seed return when breaking a crop; (3) at **31** the stick is immune to being
broken by running entities. *Falling* trample ignores Resistance entirely — use trample-immune
soil for full fall protection.

</details>

> [!WARNING]
> **Weeds & Growth.** Crops with **Growth ≥ 24** spread weeds to adjacent empty sticks if
> **Resistance < Growth**. Keep Resistance ≥ Growth **and** WeedEx stocked to stop it — WeedEx
> alone isn't enough. (Unlike IC2, WeedEx never reduces stats in CropsNH.)

