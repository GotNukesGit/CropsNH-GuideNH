---
navigation:
  icon: 'minecraft:dirt'
  title: Soils & block-under
  parent: /mechanics.md
  position: 2
---

# Soils & Block-Under

> [!TIP]
> **TL;DR.** The block directly under the crop stick must be the right **soil**. Some crops also
> need a specific block **one layer below that** — both must match or the crop won't grow. The two
> you'll use most: **Farmland** (hoe dirt) for most crops, **Stone** for all ore/metal crops.

Two separate checks happen under the **cross-crop** stick:

| Level | What's checked |
|:--|:--|
| y+0 | the crop stick tile entity |
| y−1 | **soil** block — `getSoilTypes()` |
| y−2 | **block-under** — `BlockUnderRequirement` |

The soil check applies to the **cross-crop** (output) stick, not the parents. If the result's soil
doesn't match, the **entire breeding tick is wasted** — no retry.

<GameScene zoom={4} interactive={true}>
  <Block id="minecraft:dirt" x="0" y="0" z="0" />
  <Block id="minecraft:farmland" x="0" y="1" z="0" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crop:{crop:"cropsnh:wheat",amount:1,gr:1b,ga:1b,re:1b,scan:1b},progress:1000}' x="0" y="2" z="0" />
  <Block id="minecraft:iron_ore" x="2" y="0" z="0" />
  <Block id="minecraft:stone" x="2" y="1" z="0" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crop:{crop:"cropsnh:ironOreBerry",amount:1,gr:1b,ga:1b,re:1b,scan:1b},progress:1000}' x="2" y="2" z="0" />
  <BlockAnnotation pos="0 1 0" color="#8044DD66" thickness="2" alwaysOnTop={true}>y-1 soil</BlockAnnotation>
  <BlockAnnotation pos="2 1 0" color="#8044DD66" thickness="2" alwaysOnTop={true}>y-1 soil</BlockAnnotation>
  <BlockAnnotation pos="2 0 0" color="#80FFAA00" thickness="2" alwaysOnTop={true}>y-2 block-under</BlockAnnotation>
</GameScene>

**Left** — an ordinary farmland crop: the stick sits on **Farmland** (y-1) over plain dirt, no block-under needed. **Right** — an ore berry: the stick sits on **Stone** (y-1) over its **block-under** (here Iron Ore, y-2, amber). If either layer is wrong, the crop won't grow.

> [!TIP]
> **Exploiting the soil filter.** Because a mismatched result is discarded, a restrictive soil
> turns a noisy pool roll into a near-guaranteed target — the basis of the
> [Graveyard Soil trick](/breeding/graveyard-trick.md).

## Soil types (19)

| Soil | id | Accepted blocks |
|------|----|-----------------|
| **Farmland** | `farmland` | Farmland, Enchanted Earth, Ztones Garden Soil, Fertilized Dirt |
| **Dirt / Grass** | `dirtGrass` | Dirt, Grass, Mycelium variants |
| **Stone** | `stone` | Stone, Cobblestone, Stone Brick, Mossy Cobble + Chisel variants |
| **Sand** | `sand` | Sand, Sandstone |
| **Soul Sand** | `soulsand` | Soul Sand |
| **Sugarcane Soil** | `sugarcane` | Sand, Sandstone, Dirt, Grass (CompoundSoilList) |
| **Netherrack** | `netherrack` | Netherrack, TiC Nether Bricks, Chisel Netherrack |
| **Graveyard Soil** | `graveyard` | TiC CraftedSoil:3 (Graveyard Soil) |
| **Slimy Soil** | `slimy` | TiC Green/Blue Slimy Mud, Slime Dirt, Slime Grass |
| **Slimy Dirt/Grass** | `slimyDirt` | Dirt, Grass + all Slimy Soil variants (CompoundSoilList) |
| **End Stone** | `end` | End Stone, Botania End Stone Brick, Chisel End Stone |
| **Mycelium** | `mycelium` | Mycelium |
| **Thaumcraft Logs** | `thaumLogs` | Greatwood Log, Silverwood Log |
| **Brick** | `brick` | Brick Block, ExtraUtils Color Brick, ThaumicBases Old Brick |
| **Gravel** | `gravel` | Gravel |
| **Oil Sands** | `oilSands` | GT Oil Sands ore variants |
| **Oil Soil** | `oil` | Sand, Gravel, Soul Sand, Oil Sands (OilBerry compound) |
| **Mushroom Soil** | `mushroom` | Stone, Dirt/Grass, Mycelium |
| **Nether Mushroom Soil** | `netherMushroom` | Stone, Dirt, Mycelium, Netherrack |

> [!NOTE]
> **Trample-proof farmland.** *Ztones Garden Soil*, *Enchanted Earth*, and *Fertilized Dirt* all
> register as Farmland but are immune to crop trampling regardless of Resistance — a great drop-in
> for a starter farm before your seeds reach Resistance 31.

## Block-under requirements

71 crops require a specific buried block two spaces down. The crop pages for
the vanilla-backed ones render a rotatable **3D setup scene** (buried block → soil → cross-crop,
parents around it).

| Buried block | Crops that need it |
|--------------|--------------------|
| `aluminium` | [Aluminium Ore Berry](/crops/aluminiumoreberry.md) |
| `aluminiumBauxite` | [Bauxia](/crops/bauxia.md) |
| `ardite` | [Ardite Ore Berry](/crops/arditeoreberry.md) |
| `basalt` | [Basalt Lily](/crops/basaltlily.md) |
| `blackGranite` | [Black Granite Lily](/crops/blackgranitelily.md) |
| `blaze` | [Cinderpearl](/crops/cinderpearl.md) |
| `clay` | [Clay Lily](/crops/claylily.md) |
| `coal` | [Withereed](/crops/withereed.md) |
| `cobalt` | [Cobalt Ore Berry](/crops/cobaltoreberry.md) |
| `copper` | [Coppon](/crops/coppon.md), [Malaxia](/crops/malaxia.md), [Copper Ore Berry](/crops/copperoreberry.md) |
| `deepslate` | [Deepslate Lily](/crops/deepslatelily.md) |
| `diamond` | [Diareed](/crops/diareed.md) |
| `emerald` | [BobsYerUncleRanks](/crops/bobsyeruncleranks.md) |
| `endStone` | [End Stone Lily](/crops/endstonelily.md), [Enderbloom](/crops/enderbloom.md) |
| `garnetGem` | [Garnydinia](/crops/garnydinia.md) |
| `glowstone` | [Glowheat](/crops/glowheat.md), [Glowing Coral](/crops/glowingcoral.md) |
| `gold` | [Auronia](/crops/auronia.md), [Gold Ore Berry](/crops/goldoreberry.md) |
| `iridium` | [Iridine](/crops/iridine.md) |
| `iron` | [Ferrofern](/crops/ferrofern.md), [Iron Ore Berry](/crops/ironoreberry.md) |
| `knightmetal` | [Knightmetal Berry](/crops/knightmetalberry.md) |
| `lapis` | [Lazulia](/crops/lazulia.md) |
| `lead` | [Plumbilia](/crops/plumbilia.md), [Plumbshade](/crops/plumbshade.md) |
| `manganese` | [Pyrolusium](/crops/pyrolusium.md) |
| `marble` | [Marble Lily](/crops/marblelily.md) |
| `mica` | [Micadia](/crops/micadia.md) |
| `mixedCrystalCluster` | [Mana Bean](/crops/manabean.md) |
| `modernAndesite` | [Andesite Lily](/crops/andesitelily.md) |
| `modernDiorite` | [Diorite Lily](/crops/dioritelily.md) |
| `modernGranite` | [Granite Lily](/crops/granitelily.md) |
| `naquadah` | [Stargatium](/crops/stargatium.md) |
| `netherStar` | [Star Wart](/crops/starwart.md) |
| `netherrack` | [Nether Stone Lily](/crops/netherstonelily.md) |
| `nickel` | [Nickelback](/crops/nickelback.md) |
| `olivine` | [Olivia](/crops/olivia.md) |
| `osmium` | [Osmianth](/crops/osmianth.md) |
| `platinum` | [Platina](/crops/platina.md) |
| `quicksilver` | [Shimmerleaf](/crops/shimmerleaf.md) |
| `redGranite` | [Red Granite Lily](/crops/redgranitelily.md) |
| `redstone` | [Red Straw](/crops/redstraw.md) |
| `ruby` | [Rubyne](/crops/rubyne.md) |
| `sand` | [Sand Lily](/crops/sandlily.md) |
| `sapphire` | [Sapphirum](/crops/sapphirum.md) |
| `shadowmetal` | [Magical Nightshade](/crops/magicalnightshade.md) |
| `silver` | [Silviscus](/crops/silviscus.md), [Argentia](/crops/argentia.md) |
| `skull` | [Essence Ore Berry](/crops/essenceoreberry.md) |
| `snow` | [Gaia Wart](/crops/gaiawart.md) |
| `soulSand` | [Soul Sand Lily](/crops/soulsandlily.md) |
| `space` | [Space FlowerS](/crops/spaceflower.md) |
| `steeleaf` | [Steeleafranks](/crops/steeleafranks.md) |
| `stone` | [Stone Lily](/crops/stonelily.md) |
| `sulfur` | [Thiosulfine](/crops/thiosulfine.md) |
| `thauminite` | [Thauminite Ore Berry](/crops/thauminiteoreberry.md) |
| `thaumium` | [Thaumium Ore Berry](/crops/thaumiumoreberry.md) |
| `thorium` | [God of Thunder](/crops/godofthunder.md) |
| `tin` | [Tine](/crops/tine.md), [Cassitine](/crops/cassitine.md), [Tin Ore Berry](/crops/tinoreberry.md) |
| `titanium` | [Titania](/crops/titania.md) |
| `tuff` | [Tuff Lily](/crops/tufflily.md) |
| `tungsten` | [Scheelinium](/crops/scheelinium.md) |
| `uranium` | [Reactoria](/crops/reactoria.md) |
| `void` | [Void Ore Berry](/crops/voidoreberry.md) |
| `zinc` | [Galvania](/crops/galvania.md) |

