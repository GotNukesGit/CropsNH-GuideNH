---
navigation:
  icon: 'cropsnh:cropSticks'
  title: The breeding tick
  parent: /breeding.md
  position: 4
---

# The Breeding Tick

> [!TIP]
> **TL;DR.** Every **12.8 s**, each cross-crop stick has a **1-in-3** chance to try
> breeding. If it tries, it's a **50/50** flip: **clone** a parent (spreading) or **mutate**.
> Parents must be at **≥80% growth** to take part.

<GameScene zoom={4} interactive={true}>
  <Block id="minecraft:dirt" x="0" y="0" z="0" />
  <Block id="minecraft:farmland" x="0" y="1" z="0" />
  <Block id="minecraft:dirt" x="0" y="0" z="-1" />
  <Block id="minecraft:farmland" x="0" y="1" z="-1" />
  <Block id="minecraft:dirt" x="0" y="0" z="1" />
  <Block id="minecraft:farmland" x="0" y="1" z="1" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crossCrop:1b}' x="0" y="2" z="0" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crop:{crop:"cropsnh:wheat",amount:1,gr:1b,ga:1b,re:1b,scan:1b},progress:1000}' x="0" y="2" z="-1" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crop:{crop:"cropsnh:carrot",amount:1,gr:1b,ga:1b,re:1b,scan:1b},progress:1000}' x="0" y="2" z="1" />
  <BlockAnnotation pos="0 2 0" color="#80FFAA00" thickness="2" alwaysOnTop={true}>cross-crop</BlockAnnotation>
  <BlockAnnotation pos="0 2 -1" color="#8044DD66" thickness="2" alwaysOnTop={true}>parent</BlockAnnotation>
  <BlockAnnotation pos="0 2 1" color="#8044DD66" thickness="2" alwaysOnTop={true}>parent</BlockAnnotation>
</GameScene>

The center stick (amber highlight) is the empty **cross-crop** where new crops appear; the two flanking sticks (green) are the **parents** — both must be ≥ 80% grown, and can be the same species (breeds via pools) or different (can hit a deterministic recipe). Rotate and zoom with drag / scroll.

The whole tick as one picture:

<Mermaid>
mindmap
  root((Breeding tick))
    Roll 1 in 3
      Fail - nothing happens
      Pass - breed attempt
        Coin flip 50/50
          Spread - clone a parent
          Breed path
            Deterministic recipe
            Pool mutation
    Soil check on result
      Match - plant it
      Mismatch - tick wasted
</Mermaid>

The soil check runs on whichever result the branches produce, so a mismatched soil wastes the entire tick.

<details>
<summary>The full tick sequence</summary>

**1. Roll 1-in-3.** Only 0 proceeds — two-thirds of ticks do nothing.

**2. Find eligible neighbours.** All 4 cardinal neighbours; each must have a crop, no weed, and
growth ≥ 80%.

**3. 50/50 — spread or breed.** If spreading wins but no crossable neighbour exists, it falls
through to breed. On the breed path, deterministic recipes are checked first, then pools.

**4. Soil validation.** After a result is chosen, its required soil is checked against the
cross-crop's soil. Mismatch → **the whole tick is wasted**, no retry.

**5. Plant result.** Stats = parent average ± variance (-2 to +4); fertilizer in all
contributing parents locks it to 0 to +4.

</details>

> [!NOTE]
> Once parents are fully mature and you stop harvesting them, they stay at 100% and breed
> indefinitely — the 80% threshold only matters during the initial ramp-up.

<Latex formula="P_{\text{deterministic}} = \frac{1}{3}\cdot\frac{1}{2}\cdot\frac{1}{N_{\text{matching recipes}}}" scale="1.15"/>

