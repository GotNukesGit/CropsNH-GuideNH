---
navigation:
  icon: 'cropsnh:cropSticks'
  title: Strategy
  parent: /index.md
  position: 20
---

# Strategy

Where to farm, how to fight weeds, what to automate, and what each tier demands.

<SubPages/>

