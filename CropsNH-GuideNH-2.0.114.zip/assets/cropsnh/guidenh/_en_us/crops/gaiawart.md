---
item_id: 'cropsnh:genericSeed:0:{crop:"cropsnh:gaiaWart"}'
categories:
  - crops
  - tier-5
navigation:
  icon: 'cropsnh:genericSeed:0:{crop:"cropsnh:gaiaWart"}'
  title: Gaia Wart
  parent: /crops.md
  position: 15
  keywords:
    - Gaia Wart
    - GaiaWart
---

# Gaia Wart

> [!NOTE]
> **Directly obtainable.** No breeding recipe — plant it from a seed you can get by other means

> [!WARNING]
> **Buried block required.** This crop needs a `snow` block two spaces below the cross-crop stick (directly under the soil). Without it the crop won't grow — see the setup scene below.

**Tier:** 5  
**Soil:** [Soul Sand](/mechanics/soil-and-blocks.md) — Soul Sand  
**Block under soil:** `snow`  
**Likes biomes:** SNOWY, COLD  
**Alternate seed:** yes — plantable without breeding  

Obtained by growing Nether Wart to maturity on Soul Sand, then right-clicking with Snow Blocks until it converts. Not breedable.

## Setup

Grow **Gaia Wart** on Soul Sand with a **snow** block two spaces below the crop stick:

<GameScene zoom={4} interactive={true}>
  <Block id="minecraft:snow" x="0" y="0" z="0" />
  <Block id="minecraft:soul_sand" x="0" y="1" z="0" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crop:{crop:"cropsnh:gaiaWart",amount:1,gr:1b,ga:1b,re:1b,scan:1b},progress:1000}' x="0" y="2" z="0" />
  <BlockAnnotation pos="0 2 0" color="#8044DD66" thickness="2" alwaysOnTop={true}>Gaia Wart</BlockAnnotation>
</GameScene>

## How to obtain

No breeding recipe — obtain the seed directly.


