---
item_id: 'cropsnh:genericSeed:0:{crop:"cropsnh:ironOreBerry"}'
categories:
  - crops
  - tier-5
navigation:
  icon: 'cropsnh:genericSeed:0:{crop:"cropsnh:ironOreBerry"}'
  title: Iron Ore Berry
  parent: /crops.md
  position: 15
  keywords:
    - Iron Ore Berry
    - IronOreBerry
---

# Iron Ore Berry

> [!WARNING]
> **Buried block required.** This crop needs a `iron` block two spaces below the cross-crop stick (directly under the soil). Without it the crop won't grow — see the setup scene below.

**Tier:** 5  
**Soil:** [Stone](/mechanics/soil-and-blocks.md) — Stone, Cobblestone, Stone Brick, Mossy Cobble + Chisel variants  
**Block under soil:** `iron`  
**Likes biomes:** MOUNTAIN, HILLS  
**Alternate seed:** yes — plantable without breeding  
**Pools:** `DANGEROUS`, `GRAY`, `IRON`, `METALLIC`, `ORE_BERRY`  

TiC req

## Breeding setup

Full breeding setup — a cross-crop stick in the center on Stone over a **iron** block, with the parents planted in a line through it (**Tin Ore Berry** (north), **Stone Lily** (south)):

<GameScene zoom={4} interactive={true}>
  <Block id="minecraft:iron_block" x="0" y="0" z="0" />
  <Block id="minecraft:stone" x="0" y="1" z="0" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crossCrop:1b}' x="0" y="2" z="0" />
  <Block id="gregtech:gt.blockmetal7" meta="7" x="0" y="0" z="-1" />
  <Block id="minecraft:stone" x="0" y="1" z="-1" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crop:{crop:"cropsnh:tinOreBerry",amount:1,gr:1b,ga:1b,re:1b,scan:1b},progress:1000}' x="0" y="2" z="-1" />
  <Block id="minecraft:stone" x="0" y="0" z="1" />
  <Block id="minecraft:stone" x="0" y="1" z="1" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crop:{crop:"cropsnh:stoneLily",amount:1,gr:1b,ga:1b,re:1b,scan:1b},progress:1000}' x="0" y="2" z="1" />
  <BlockAnnotation pos="0 2 0" color="#80FFAA00" thickness="2" alwaysOnTop={true}>Iron Ore Berry — cross-crop (result grows here)</BlockAnnotation>
  <BlockAnnotation pos="0 2 -1" color="#8044DD66" thickness="2" alwaysOnTop={true}>Tin Ore Berry (parent)</BlockAnnotation>
  <BlockAnnotation pos="0 2 1" color="#8044DD66" thickness="2" alwaysOnTop={true}>Stone Lily (parent)</BlockAnnotation>
</GameScene>

## How to obtain

Bred from:

| Parents | Result pools | Notes |
|---------|--------------|-------|
| [Tin Ore Berry](/crops/tinoreberry.md) + [Stone Lily](/crops/stonelily.md) | `DANGEROUS`, `GRAY`, `IRON`, `METALLIC`, `ORE_BERRY` | crop-stick cross |

Exact per-tick chance depends on soil and the parents' shared pools — check the [web calculator](https://crops-nh.netlify.app/calculator.html).

## Used to breed

Iron Ore Berry is a parent in these mutations:

| Produces | With |
|----------|------|
| [Gold Ore Berry](/crops/goldoreberry.md) | [Copper Ore Berry](/crops/copperoreberry.md) + [Tin Ore Berry](/crops/tinoreberry.md) |
| [Knightmetal Berry](/crops/knightmetalberry.md) | [Torchberry](/crops/torchberry.md) + [Bonsai Dark Oak](/crops/bonsaidarkoak.md) |


