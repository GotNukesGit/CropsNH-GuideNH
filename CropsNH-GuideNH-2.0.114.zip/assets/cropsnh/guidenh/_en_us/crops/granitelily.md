---
item_id: 'cropsnh:genericSeed:0:{crop:"cropsnh:graniteLily"}'
categories:
  - crops
  - tier-1
navigation:
  icon: 'cropsnh:genericSeed:0:{crop:"cropsnh:graniteLily"}'
  title: Granite Lily
  parent: /crops.md
  position: 19
  keywords:
    - Granite Lily
    - GraniteLily
---

# Granite Lily

> [!WARNING]
> **Buried block required.** This crop needs a `modernGranite` block two spaces below the cross-crop stick (directly under the soil). Without it the crop won't grow — see the setup scene below.

**Tier:** 1  
**Soil:** [Stone](/mechanics/soil-and-blocks.md) — Stone, Cobblestone, Stone Brick, Mossy Cobble + Chisel variants  
**Block under soil:** `modernGranite`  
**Likes biomes:** MOUNTAIN, HILLS  
**Alternate seed:** no  
**Pools:** `RED`, `STONE`  

## Breeding setup

Full breeding setup — a cross-crop stick in the center on Stone over a **modernGranite** block, with the parents planted in a line through it (**Black Granite Lily** (north), **Red Granite Lily** (south)):

<GameScene zoom={4} interactive={true}>
  <Block id="chisel:granite" x="0" y="0" z="0" />
  <Block id="minecraft:stone" x="0" y="1" z="0" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crossCrop:1b}' x="0" y="2" z="0" />
  <Block id="gregtech:gt.blockgranites" meta="0" x="0" y="0" z="-1" />
  <Block id="minecraft:stone" x="0" y="1" z="-1" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crop:{crop:"cropsnh:blackGraniteLily",amount:1,gr:1b,ga:1b,re:1b,scan:1b},progress:1000}' x="0" y="2" z="-1" />
  <Block id="gregtech:gt.blockgranites" meta="8" x="0" y="0" z="1" />
  <Block id="minecraft:stone" x="0" y="1" z="1" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crop:{crop:"cropsnh:redGraniteLily",amount:1,gr:1b,ga:1b,re:1b,scan:1b},progress:1000}' x="0" y="2" z="1" />
  <BlockAnnotation pos="0 2 0" color="#80FFAA00" thickness="2" alwaysOnTop={true}>Granite Lily — cross-crop (result grows here)</BlockAnnotation>
  <BlockAnnotation pos="0 2 -1" color="#8044DD66" thickness="2" alwaysOnTop={true}>Black Granite Lily (parent)</BlockAnnotation>
  <BlockAnnotation pos="0 2 1" color="#8044DD66" thickness="2" alwaysOnTop={true}>Red Granite Lily (parent)</BlockAnnotation>
</GameScene>

## How to obtain

Bred from:

| Parents | Result pools | Notes |
|---------|--------------|-------|
| [Black Granite Lily](/crops/blackgranitelily.md) + [Red Granite Lily](/crops/redgranitelily.md) | `RED`, `STONE` | crop-stick cross |

Exact per-tick chance depends on soil and the parents' shared pools — check the [web calculator](https://crops-nh.netlify.app/calculator.html).


