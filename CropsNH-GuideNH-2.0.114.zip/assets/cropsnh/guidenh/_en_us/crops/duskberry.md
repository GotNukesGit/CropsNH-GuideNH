---
item_id: 'cropsnh:genericSeed:0:{crop:"cropsnh:duskberry"}'
categories:
  - crops
  - tier-4
navigation:
  icon: 'cropsnh:genericSeed:0:{crop:"cropsnh:duskberry"}'
  title: Duskberry
  parent: /crops.md
  position: 16
  keywords:
    - Duskberry
    - Duskberry
---

# Duskberry

**Tier:** 4  
**Soil:** [Netherrack](/mechanics/soil-and-blocks.md) — Netherrack, TiC Nether Bricks, Chisel Netherrack  
**Likes biomes:** NETHER, HOT  
**Alternate seed:** yes — plantable without breeding  
**Pools:** `ADDICTIVE`, `BERRY`, `BUSH`, `DANGEROUS`, `EDIBLE`, `GRAY`, `NETHER`, `POISONOUS`, `POTION_INGREDIENT`  

Natura req

## Breeding setup

Full breeding setup — a cross-crop stick in the center on Netherrack, with the parents planted in a line through it (**Ink Bloom** (north), **Blackberry** (south)):

<GameScene zoom={4} interactive={true}>
  <Block id="minecraft:netherrack" x="0" y="0" z="0" />
  <Block id="minecraft:netherrack" x="0" y="1" z="0" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crossCrop:1b}' x="0" y="2" z="0" />
  <Block id="minecraft:dirt" x="0" y="0" z="-1" />
  <Block id="minecraft:dirt" x="0" y="1" z="-1" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crop:{crop:"cropsnh:inkbloom",amount:1,gr:1b,ga:1b,re:1b,scan:1b},progress:1000}' x="0" y="2" z="-1" />
  <Block id="minecraft:dirt" x="0" y="0" z="1" />
  <Block id="minecraft:farmland" x="0" y="1" z="1" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crop:{crop:"cropsnh:blackberry",amount:1,gr:1b,ga:1b,re:1b,scan:1b},progress:1000}' x="0" y="2" z="1" />
  <BlockAnnotation pos="0 2 0" color="#80FFAA00" thickness="2" alwaysOnTop={true}>Duskberry — cross-crop (result grows here)</BlockAnnotation>
  <BlockAnnotation pos="0 2 -1" color="#8044DD66" thickness="2" alwaysOnTop={true}>Ink Bloom (parent)</BlockAnnotation>
  <BlockAnnotation pos="0 2 1" color="#8044DD66" thickness="2" alwaysOnTop={true}>Blackberry (parent)</BlockAnnotation>
</GameScene>

## How to obtain

Bred from:

| Parents | Result pools | Notes |
|---------|--------------|-------|
| [Ink Bloom](/crops/inkbloom.md) + [Blackberry](/crops/blackberry.md) | `ADDICTIVE`, `BERRY`, `BUSH`, `DANGEROUS`, `EDIBLE`, `GRAY`, `NETHER`, `POISONOUS`, `POTION_INGREDIENT` | crop-stick cross |

Exact per-tick chance depends on soil and the parents' shared pools — check the [web calculator](https://crops-nh.netlify.app/calculator.html).


