---
item_id: 'cropsnh:genericSeed:0:{crop:"cropsnh:trollplant"}'
categories:
  - crops
  - tier-6
navigation:
  icon: 'cropsnh:genericSeed:0:{crop:"cropsnh:trollplant"}'
  title: Trollplant
  parent: /crops.md
  position: 14
  keywords:
    - Trollplant
    - Trollplant
---

# Trollplant

> [!NOTE]
> **Machine-only.** Produced by a machine process, not by breeding on crop sticks.

> [!IMPORTANT]
> **Requires:** Plutonium dust ×1, Red Alloy Stick ×64, Brick Block ×5

**Tier:** 6  
**Soil:** [Brick](/mechanics/soil-and-blocks.md) — Brick Block, ExtraUtils Color Brick, ThaumicBases Old Brick  
**Likes biomes:** SWAMP, SPOOKY  
**Alternate seed:** no  

Crop Synthesizer only. Extreme late-game. No pool membership.

## Setup

Grow **Trollplant** on Brick:

<GameScene zoom={4} interactive={true}>
  <Block id="minecraft:brick_block" x="0" y="0" z="0" />
  <Block id="minecraft:brick_block" x="0" y="1" z="0" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crop:{crop:"cropsnh:trollplant",amount:1,gr:1b,ga:1b,re:1b,scan:1b},progress:1000}' x="0" y="2" z="0" />
  <BlockAnnotation pos="0 2 0" color="#8044DD66" thickness="2" alwaysOnTop={true}>Trollplant</BlockAnnotation>
</GameScene>

## How to obtain

Produced by a machine process rather than breeding.

## Used to breed

Trollplant is a parent in these mutations:

| Produces | With |
|----------|------|
| [Stargatium](/crops/stargatium.md) | [Iridine](/crops/iridine.md) |
| [Transformium](/crops/transformium.md) | [Bauxia](/crops/bauxia.md) + [Titania](/crops/titania.md) |


