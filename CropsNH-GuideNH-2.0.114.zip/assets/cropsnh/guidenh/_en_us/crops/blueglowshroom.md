---
item_id: 'cropsnh:genericSeed:0:{crop:"cropsnh:blueGlowshroom"}'
categories:
  - crops
  - tier-3
navigation:
  icon: 'cropsnh:genericSeed:0:{crop:"cropsnh:blueGlowshroom"}'
  title: Blue Glowshroom
  parent: /crops.md
  position: 17
  keywords:
    - Blue Glowshroom
    - BlueGlowshroom
---

# Blue Glowshroom

> [!NOTE]
> **Directly obtainable.** No breeding recipe — plant it from a seed you can get by other means

**Tier:** 3  
**Soil:** [Nether Mushroom Soil](/mechanics/soil-and-blocks.md) — Stone, Dirt, Mycelium, Netherrack  
**Alternate seed:** no  
**Pools:** `BLUE`, `EDIBLE`, `EMISSIVE`, `MUSHROOM`, `NETHER`, `POTION_INGREDIENT`  

Natura req

## Setup

Grow **Blue Glowshroom** on Nether Mushroom Soil:

<GameScene zoom={4} interactive={true}>
  <Block id="minecraft:netherrack" x="0" y="0" z="0" />
  <Block id="minecraft:netherrack" x="0" y="1" z="0" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crop:{crop:"cropsnh:blueGlowshroom",amount:1,gr:1b,ga:1b,re:1b,scan:1b},progress:1000}' x="0" y="2" z="0" />
  <BlockAnnotation pos="0 2 0" color="#8044DD66" thickness="2" alwaysOnTop={true}>Blue Glowshroom</BlockAnnotation>
</GameScene>

## How to obtain

No breeding recipe — obtain the seed directly.

## Used to breed

Blue Glowshroom is a parent in these mutations:

| Produces | With |
|----------|------|
| [Glowshroom](/crops/glowshroom.md) | [Green Glowshroom](/crops/greenglowshroom.md) + [Purple Glowshroom](/crops/purpleglowshroom.md) |
| [Purple Glowshroom](/crops/purpleglowshroom.md) | [Blue Orchid](/crops/blueorchid.md) + [Glowflower](/crops/glowflower.md) |


