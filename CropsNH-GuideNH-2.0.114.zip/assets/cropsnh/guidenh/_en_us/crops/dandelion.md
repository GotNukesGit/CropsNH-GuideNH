---
item_id: 'cropsnh:genericSeed:0:{crop:"cropsnh:dandelion"}'
categories:
  - crops
  - tier-2
navigation:
  icon: 'cropsnh:genericSeed:0:{crop:"cropsnh:dandelion"}'
  title: Dandelion
  parent: /crops.md
  position: 18
  keywords:
    - Dandelion
    - Dandelion
---

# Dandelion

> [!NOTE]
> **Directly obtainable.** No breeding recipe — plant it from a seed you can get by other means.

**Tier:** 2  
**Soil:** [Dirt / Grass](/mechanics/soil-and-blocks.md) — Dirt, Grass, Mycelium variants  
**Likes biomes:** PLAINS, FOREST  
**Alternate seed:** yes — plantable without breeding  
**Pools:** `FLOWER`, `YELLOW`  

## Setup

Grow **Dandelion** on Dirt / Grass:

<GameScene zoom={4} interactive={true}>
  <Block id="minecraft:dirt" x="0" y="0" z="0" />
  <Block id="minecraft:dirt" x="0" y="1" z="0" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crop:{crop:"cropsnh:dandelion",amount:1,gr:1b,ga:1b,re:1b,scan:1b},progress:1000}' x="0" y="2" z="0" />
  <BlockAnnotation pos="0 2 0" color="#8044DD66" thickness="2" alwaysOnTop={true}>Dandelion</BlockAnnotation>
</GameScene>

## How to obtain

No breeding recipe — obtain the seed directly.

## Used to breed

Dandelion is a parent in these mutations:

| Produces | With |
|----------|------|
| [Glowflower](/crops/glowflower.md) | [Nether Stone Lily](/crops/netherstonelily.md) |
| [Hops](/crops/hops.md) | [Hemp](/crops/hemp.md) |
| [Orange Tulip](/crops/orangetulip.md) | [Red Tulip](/crops/redtulip.md) |
| [Oxeye Daisy](/crops/oxeyedaisy.md) | [Azure Bluet](/crops/azurebluet.md) |


