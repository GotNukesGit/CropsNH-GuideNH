---
item_id: 'cropsnh:genericSeed:0:{crop:"cropsnh:sugarCane"}'
categories:
  - crops
  - tier-2
navigation:
  icon: 'cropsnh:genericSeed:0:{crop:"cropsnh:sugarCane"}'
  title: Sugar Cane
  parent: /crops.md
  position: 18
  keywords:
    - Sugar Cane
    - SugarCane
---

# Sugar Cane

**Tier:** 2  
**Soil:** [Sugarcane Soil](/mechanics/soil-and-blocks.md) — Sand, Sandstone, Dirt, Grass (CompoundSoilList)  
**Likes biomes:** WET, HOT  
**Alternate seed:** yes — plantable without breeding  
**Pools:** `EDIBLE`, `GREEN`, `REED`  

## Breeding setup

Full breeding setup — a cross-crop stick in the center on Sugarcane Soil, with the parents planted in a line through it (**Carrot** (north), **Potato** (south)):

<GameScene zoom={4} interactive={true}>
  <Block id="minecraft:sand" x="0" y="0" z="0" />
  <Block id="minecraft:sand" x="0" y="1" z="0" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crossCrop:1b}' x="0" y="2" z="0" />
  <Block id="minecraft:dirt" x="0" y="0" z="-1" />
  <Block id="minecraft:farmland" x="0" y="1" z="-1" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crop:{crop:"cropsnh:carrot",amount:1,gr:1b,ga:1b,re:1b,scan:1b},progress:1000}' x="0" y="2" z="-1" />
  <Block id="minecraft:dirt" x="0" y="0" z="1" />
  <Block id="minecraft:farmland" x="0" y="1" z="1" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crop:{crop:"cropsnh:potato",amount:1,gr:1b,ga:1b,re:1b,scan:1b},progress:1000}' x="0" y="2" z="1" />
  <BlockAnnotation pos="0 2 0" color="#80FFAA00" thickness="2" alwaysOnTop={true}>Sugar Cane — cross-crop (result grows here)</BlockAnnotation>
  <BlockAnnotation pos="0 2 -1" color="#8044DD66" thickness="2" alwaysOnTop={true}>Carrot (parent)</BlockAnnotation>
  <BlockAnnotation pos="0 2 1" color="#8044DD66" thickness="2" alwaysOnTop={true}>Potato (parent)</BlockAnnotation>
</GameScene>

## How to obtain

Bred from:

| Parents | Result pools | Notes |
|---------|--------------|-------|
| [Carrot](/crops/carrot.md) + [Potato](/crops/potato.md) | `EDIBLE`, `GREEN`, `REED` | crop-stick cross |

Exact per-tick chance depends on soil and the parents' shared pools — check the [web calculator](https://crops-nh.netlify.app/calculator.html).

## Used to breed

Sugar Cane is a parent in these mutations:

| Produces | With |
|----------|------|
| [Blazereed](/crops/blazereed.md) | [Cinderpearl](/crops/cinderpearl.md) |
| [Bonsai Birch](/crops/bonsaibirch.md) | [Bonsai Oak](/crops/bonsaioak.md) |
| [Cactus](/crops/cactus.md) | [Potato](/crops/potato.md) |
| [Pumpkin](/crops/pumpkin.md) | [Carrot](/crops/carrot.md) |
| [Sticky Cane](/crops/stickycane.md) | [Bonsai Jungle](/crops/bonsaijungle.md) |
| [Sugar Beet](/crops/sugarbeet.md) | [Allium](/crops/allium.md) |
| [Waterlily](/crops/waterlily.md) | [Vine](/crops/vine.md) |


