---
item_id: 'cropsnh:genericSeed:0:{crop:"cropsnh:waterLily"}'
categories:
  - crops
  - tier-2
navigation:
  icon: 'cropsnh:genericSeed:0:{crop:"cropsnh:waterLily"}'
  title: Waterlily
  parent: /crops.md
  position: 18
  keywords:
    - Waterlily
    - Waterlily
---

# Waterlily

**Tier:** 2  
**Soil:** [Farmland](/mechanics/soil-and-blocks.md) — Farmland, Enchanted Earth, Ztones Garden Soil, Fertilized Dirt  
**Likes biomes:** WET, SWAMP, RIVER  
**Alternate seed:** yes — plantable without breeding  
**Pools:** `GREEN`, `WATERY`  

## Breeding setup

Full breeding setup — a cross-crop stick in the center on Farmland, with the parents planted in a line through it (**Vine** (north), **Sugar Cane** (south)):

<GameScene zoom={4} interactive={true}>
  <Block id="minecraft:dirt" x="0" y="0" z="0" />
  <Block id="minecraft:farmland" x="0" y="1" z="0" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crossCrop:1b}' x="0" y="2" z="0" />
  <Block id="minecraft:dirt" x="0" y="0" z="-1" />
  <Block id="minecraft:farmland" x="0" y="1" z="-1" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crop:{crop:"cropsnh:vine",amount:1,gr:1b,ga:1b,re:1b,scan:1b},progress:1000}' x="0" y="2" z="-1" />
  <Block id="minecraft:sand" x="0" y="0" z="1" />
  <Block id="minecraft:sand" x="0" y="1" z="1" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crop:{crop:"cropsnh:sugarCane",amount:1,gr:1b,ga:1b,re:1b,scan:1b},progress:1000}' x="0" y="2" z="1" />
  <BlockAnnotation pos="0 2 0" color="#80FFAA00" thickness="2" alwaysOnTop={true}>Waterlily — cross-crop (result grows here)</BlockAnnotation>
  <BlockAnnotation pos="0 2 -1" color="#8044DD66" thickness="2" alwaysOnTop={true}>Vine (parent)</BlockAnnotation>
  <BlockAnnotation pos="0 2 1" color="#8044DD66" thickness="2" alwaysOnTop={true}>Sugar Cane (parent)</BlockAnnotation>
</GameScene>

## How to obtain

Bred from:

| Parents | Result pools | Notes |
|---------|--------------|-------|
| [Vine](/crops/vine.md) + [Sugar Cane](/crops/sugarcane.md) | `GREEN`, `WATERY` | crop-stick cross |

Exact per-tick chance depends on soil and the parents' shared pools — check the [web calculator](https://crops-nh.netlify.app/calculator.html).

## Used to breed

Waterlily is a parent in these mutations:

| Produces | With |
|----------|------|
| [Blue Orchid](/crops/blueorchid.md) | [Poppy](/crops/poppy.md) |
| [Clay Lily](/crops/claylily.md) | [Stone Lily](/crops/stonelily.md) |
| [Glowing Coral](/crops/glowingcoral.md) | [Glowflower](/crops/glowflower.md) |
| [Goldfish](/crops/goldfish.md) | [Water Artichoke](/crops/waterartichoke.md) + [Mandrake](/crops/mandrake.md) |
| [Poppy](/crops/poppy.md) | [Blue Orchid](/crops/blueorchid.md) |
| [Water Artichoke](/crops/waterartichoke.md) | [Hops](/crops/hops.md) |


