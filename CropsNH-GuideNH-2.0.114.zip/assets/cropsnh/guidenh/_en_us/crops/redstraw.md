---
item_id: 'cropsnh:genericSeed:0:{crop:"cropsnh:redstraw"}'
categories:
  - crops
  - tier-6
navigation:
  icon: 'cropsnh:genericSeed:0:{crop:"cropsnh:redstraw"}'
  title: Red Straw
  parent: /crops.md
  position: 14
  keywords:
    - Red Straw
    - RedStraw
---

# Red Straw

> [!WARNING]
> **Buried block required.** This crop needs a `redstone` block two spaces below the cross-crop stick (directly under the soil). Without it the crop won't grow — see the setup scene below.

**Tier:** 6  
**Soil:** [Farmland](/mechanics/soil-and-blocks.md) — Farmland, Enchanted Earth, Ztones Garden Soil, Fertilized Dirt  
**Block under soil:** `redstone`  
**Likes biomes:** PLAINS, HOT  
**Alternate seed:** no  
**Pools:** `EMISSIVE`, `POTION_INGREDIENT`, `RED`, `STONE`, `WHEAT`  

## Breeding setup

Full breeding setup — a cross-crop stick in the center on Farmland over a **redstone** block, with the parents planted in a line through it (**Nether Stone Lily** (north), **Wheat** (south)):

<GameScene zoom={4} interactive={true}>
  <Block id="minecraft:redstone_block" x="0" y="0" z="0" />
  <Block id="minecraft:farmland" x="0" y="1" z="0" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crossCrop:1b}' x="0" y="2" z="0" />
  <Block id="minecraft:netherrack" x="0" y="0" z="-1" />
  <Block id="minecraft:stone" x="0" y="1" z="-1" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crop:{crop:"cropsnh:netherStoneLily",amount:1,gr:1b,ga:1b,re:1b,scan:1b},progress:1000}' x="0" y="2" z="-1" />
  <Block id="minecraft:dirt" x="0" y="0" z="1" />
  <Block id="minecraft:farmland" x="0" y="1" z="1" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crop:{crop:"cropsnh:wheat",amount:1,gr:1b,ga:1b,re:1b,scan:1b},progress:1000}' x="0" y="2" z="1" />
  <BlockAnnotation pos="0 2 0" color="#80FFAA00" thickness="2" alwaysOnTop={true}>Red Straw — cross-crop (result grows here)</BlockAnnotation>
  <BlockAnnotation pos="0 2 -1" color="#8044DD66" thickness="2" alwaysOnTop={true}>Nether Stone Lily (parent)</BlockAnnotation>
  <BlockAnnotation pos="0 2 1" color="#8044DD66" thickness="2" alwaysOnTop={true}>Wheat (parent)</BlockAnnotation>
</GameScene>

## How to obtain

Bred from:

| Parents | Result pools | Notes |
|---------|--------------|-------|
| [Nether Stone Lily](/crops/netherstonelily.md) + [Wheat](/crops/wheat.md) | `EMISSIVE`, `POTION_INGREDIENT`, `RED`, `STONE`, `WHEAT` | crop-stick cross |

Exact per-tick chance depends on soil and the parents' shared pools — check the [web calculator](https://crops-nh.netlify.app/calculator.html).

## Used to breed

Red Straw is a parent in these mutations:

| Produces | With |
|----------|------|
| [Rubyne](/crops/rubyne.md) | [Diareed](/crops/diareed.md) |
| [Shimmerleaf](/crops/shimmerleaf.md) | [White Tulip](/crops/whitetulip.md) |
| [Garnydinia](/crops/garnydinia.md) | [Diareed](/crops/diareed.md) |
| [Titania](/crops/titania.md) | [Bauxia](/crops/bauxia.md) |


