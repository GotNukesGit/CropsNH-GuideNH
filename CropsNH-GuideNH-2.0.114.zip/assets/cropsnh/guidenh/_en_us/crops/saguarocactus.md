---
item_id: 'cropsnh:genericSeed:0:{crop:"cropsnh:saguaroCactus"}'
categories:
  - crops
  - tier-4
navigation:
  icon: 'cropsnh:genericSeed:0:{crop:"cropsnh:saguaroCactus"}'
  title: Saguaro Cactus
  parent: /crops.md
  position: 16
  keywords:
    - Saguaro Cactus
    - SaguaroCactus
---

# Saguaro Cactus

**Tier:** 4  
**Soil:** [Sand](/mechanics/soil-and-blocks.md) — Sand, Sandstone  
**Likes biomes:** HOT, DRY, SANDY  
**Alternate seed:** yes — plantable without breeding  
**Pools:** `CACTUS`, `DANGEROUS`, `EDIBLE`, `GREEN`  

Natura req

## Breeding setup

Full breeding setup — a cross-crop stick in the center on Sand, with the parents planted in a line through it (**Cactus** (north), **Sand Lily** (south)):

<GameScene zoom={4} interactive={true}>
  <Block id="minecraft:sand" x="0" y="0" z="0" />
  <Block id="minecraft:sand" x="0" y="1" z="0" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crossCrop:1b}' x="0" y="2" z="0" />
  <Block id="minecraft:sand" x="0" y="0" z="-1" />
  <Block id="minecraft:sand" x="0" y="1" z="-1" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crop:{crop:"cropsnh:cactus",amount:1,gr:1b,ga:1b,re:1b,scan:1b},progress:1000}' x="0" y="2" z="-1" />
  <Block id="minecraft:sand" x="0" y="0" z="1" />
  <Block id="minecraft:stone" x="0" y="1" z="1" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crop:{crop:"cropsnh:sandLily",amount:1,gr:1b,ga:1b,re:1b,scan:1b},progress:1000}' x="0" y="2" z="1" />
  <BlockAnnotation pos="0 2 0" color="#80FFAA00" thickness="2" alwaysOnTop={true}>Saguaro Cactus — cross-crop (result grows here)</BlockAnnotation>
  <BlockAnnotation pos="0 2 -1" color="#8044DD66" thickness="2" alwaysOnTop={true}>Cactus (parent)</BlockAnnotation>
  <BlockAnnotation pos="0 2 1" color="#8044DD66" thickness="2" alwaysOnTop={true}>Sand Lily (parent)</BlockAnnotation>
</GameScene>

## How to obtain

Bred from:

| Parents | Result pools | Notes |
|---------|--------------|-------|
| [Cactus](/crops/cactus.md) + [Sand Lily](/crops/sandlily.md) | `CACTUS`, `DANGEROUS`, `EDIBLE`, `GREEN` | crop-stick cross |

Exact per-tick chance depends on soil and the parents' shared pools — check the [web calculator](https://crops-nh.netlify.app/calculator.html).

## Used to breed

Saguaro Cactus is a parent in these mutations:

| Produces | With |
|----------|------|
| [Stingberry](/crops/stingberry.md) | [Thornvine](/crops/thornvine.md) |


