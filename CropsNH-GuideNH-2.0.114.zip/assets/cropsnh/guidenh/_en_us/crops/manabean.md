---
item_id: 'cropsnh:genericSeed:0:{crop:"cropsnh:manaBean"}'
categories:
  - crops
  - tier-5
navigation:
  icon: 'cropsnh:genericSeed:0:{crop:"cropsnh:manaBean"}'
  title: Mana Bean
  parent: /crops.md
  position: 15
  keywords:
    - Mana Bean
    - ManaBean
---

# Mana Bean

> [!WARNING]
> **Buried block required.** This crop needs a `mixedCrystalCluster` block two spaces below the cross-crop stick (directly under the soil). Without it the crop won't grow — see the setup scene below.

**Tier:** 5  
**Soil:** [Thaumcraft Logs](/mechanics/soil-and-blocks.md) — Greatwood Log, Silverwood Log  
**Block under soil:** `mixedCrystalCluster`  
**Likes biomes:** MAGICAL, FOREST  
**Alternate seed:** no  
**Pools:** `BEAN`, `BROWN`, `MAGICAL`  

TC req

## Breeding setup

Full breeding setup — a cross-crop stick in the center on Thaumcraft Logs over a **mixedCrystalCluster** block, with the parents planted around it (**Cocoa** (north), **Cinderpearl** (south), **Shimmerleaf** (east)):

<GameScene zoom={4} interactive={true}>
  <Block id="Thaumcraft:blockCrystal" meta="6" x="0" y="0" z="0" />
  <Block id="minecraft:log" x="0" y="1" z="0" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crossCrop:1b}' x="0" y="2" z="0" />
  <Block id="minecraft:dirt" x="0" y="0" z="-1" />
  <Block id="minecraft:farmland" x="0" y="1" z="-1" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crop:{crop:"cropsnh:cocoa",amount:1,gr:1b,ga:1b,re:1b,scan:1b},progress:1000}' x="0" y="2" z="-1" />
  <Block id="gregtech:gt.blockgem3" meta="5" x="0" y="0" z="1" />
  <Block id="minecraft:dirt" x="0" y="1" z="1" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crop:{crop:"cropsnh:cinderpearl",amount:1,gr:1b,ga:1b,re:1b,scan:1b},progress:1000}' x="0" y="2" z="1" />
  <Block id="thaumicbases:quicksilverBlock" x="1" y="0" z="0" />
  <Block id="minecraft:dirt" x="1" y="1" z="0" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crop:{crop:"cropsnh:shimmerleaf",amount:1,gr:1b,ga:1b,re:1b,scan:1b},progress:1000}' x="1" y="2" z="0" />
  <BlockAnnotation pos="0 2 0" color="#80FFAA00" thickness="2" alwaysOnTop={true}>Mana Bean — cross-crop (result grows here)</BlockAnnotation>
  <BlockAnnotation pos="0 2 -1" color="#8044DD66" thickness="2" alwaysOnTop={true}>Cocoa (parent)</BlockAnnotation>
  <BlockAnnotation pos="0 2 1" color="#8044DD66" thickness="2" alwaysOnTop={true}>Cinderpearl (parent)</BlockAnnotation>
  <BlockAnnotation pos="1 2 0" color="#8044DD66" thickness="2" alwaysOnTop={true}>Shimmerleaf (parent)</BlockAnnotation>
</GameScene>

## How to obtain

Bred from:

| Parents | Result pools | Notes |
|---------|--------------|-------|
| [Cocoa](/crops/cocoa.md) + [Cinderpearl](/crops/cinderpearl.md) + [Shimmerleaf](/crops/shimmerleaf.md) | `BEAN`, `BROWN`, `MAGICAL` | crop-stick cross |

Exact per-tick chance depends on soil and the parents' shared pools — check the [web calculator](https://crops-nh.netlify.app/calculator.html).

## Used to breed

Mana Bean is a parent in these mutations:

| Produces | With |
|----------|------|
| [Thauminite Ore Berry](/crops/thauminiteoreberry.md) | [Thaumium Ore Berry](/crops/thaumiumoreberry.md) |
| [Magical Nightshade](/crops/magicalnightshade.md) | [Primordial Berry](/crops/primordialberry.md) + [Cinderpearl](/crops/cinderpearl.md) + [Shimmerleaf](/crops/shimmerleaf.md) |


