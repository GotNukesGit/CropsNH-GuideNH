---
item_id: 'cropsnh:genericSeed:0:{crop:"cropsnh:aluminiumOreBerry"}'
categories:
  - crops
  - tier-5
navigation:
  icon: 'cropsnh:genericSeed:0:{crop:"cropsnh:aluminiumOreBerry"}'
  title: Aluminium Ore Berry
  parent: /crops.md
  position: 15
  keywords:
    - Aluminium Ore Berry
    - AluminiumOreBerry
---

# Aluminium Ore Berry

> [!WARNING]
> **Buried block required.** This crop needs a `aluminium` block two spaces below the cross-crop stick (directly under the soil). Without it the crop won't grow — see the setup scene below.

**Tier:** 5  
**Soil:** [Stone](/mechanics/soil-and-blocks.md) — Stone, Cobblestone, Stone Brick, Mossy Cobble + Chisel variants  
**Block under soil:** `aluminium`  
**Likes biomes:** COLD, DRY  
**Alternate seed:** yes — plantable without breeding  
**Pools:** `DANGEROUS`, `METALLIC`, `ORE_BERRY`, `WHITE`  

TiC req

## Breeding setup

Full breeding setup — a cross-crop stick in the center on Stone over a **aluminium** block, with the parents planted in a line through it (**Gold Ore Berry** (north), **Essence Ore Berry** (south)):

<GameScene zoom={4} interactive={true}>
  <Block id="gregtech:gt.blockmetal1" meta="1" x="0" y="0" z="0" />
  <Block id="minecraft:stone" x="0" y="1" z="0" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crossCrop:1b}' x="0" y="2" z="0" />
  <Block id="minecraft:gold_block" x="0" y="0" z="-1" />
  <Block id="minecraft:stone" x="0" y="1" z="-1" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crop:{crop:"cropsnh:goldOreBerry",amount:1,gr:1b,ga:1b,re:1b,scan:1b},progress:1000}' x="0" y="2" z="-1" />
  <Block id="minecraft:skull" x="0" y="0" z="1" />
  <Block id="minecraft:stone" x="0" y="1" z="1" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crop:{crop:"cropsnh:essenceOreBerry",amount:1,gr:1b,ga:1b,re:1b,scan:1b},progress:1000}' x="0" y="2" z="1" />
  <BlockAnnotation pos="0 2 0" color="#80FFAA00" thickness="2" alwaysOnTop={true}>Aluminium Ore Berry — cross-crop (result grows here)</BlockAnnotation>
  <BlockAnnotation pos="0 2 -1" color="#8044DD66" thickness="2" alwaysOnTop={true}>Gold Ore Berry (parent)</BlockAnnotation>
  <BlockAnnotation pos="0 2 1" color="#8044DD66" thickness="2" alwaysOnTop={true}>Essence Ore Berry (parent)</BlockAnnotation>
</GameScene>

## How to obtain

Bred from:

| Parents | Result pools | Notes |
|---------|--------------|-------|
| [Gold Ore Berry](/crops/goldoreberry.md) + [Essence Ore Berry](/crops/essenceoreberry.md) | `DANGEROUS`, `METALLIC`, `ORE_BERRY`, `WHITE` | crop-stick cross |

Exact per-tick chance depends on soil and the parents' shared pools — check the [web calculator](https://crops-nh.netlify.app/calculator.html).


