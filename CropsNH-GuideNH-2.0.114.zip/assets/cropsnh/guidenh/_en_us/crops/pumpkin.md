---
item_id: 'cropsnh:genericSeed:0:{crop:"cropsnh:pumpkin"}'
categories:
  - crops
  - tier-2
navigation:
  icon: 'cropsnh:genericSeed:0:{crop:"cropsnh:pumpkin"}'
  title: Pumpkin
  parent: /crops.md
  position: 18
  keywords:
    - Pumpkin
    - Pumpkin
---

# Pumpkin

**Tier:** 2  
**Soil:** [Farmland](/mechanics/soil-and-blocks.md) — Farmland, Enchanted Earth, Ztones Garden Soil, Fertilized Dirt  
**Likes biomes:** PLAINS, WET  
**Alternate seed:** yes — plantable without breeding  
**Pools:** `EDIBLE`, `ORANGE`, `STEM`  

## Breeding setup

Full breeding setup — a cross-crop stick in the center on Farmland, with the parents planted in a line through it (**Carrot** (north), **Sugar Cane** (south)):

<GameScene zoom={4} interactive={true}>
  <Block id="minecraft:dirt" x="0" y="0" z="0" />
  <Block id="minecraft:farmland" x="0" y="1" z="0" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crossCrop:1b}' x="0" y="2" z="0" />
  <Block id="minecraft:dirt" x="0" y="0" z="-1" />
  <Block id="minecraft:farmland" x="0" y="1" z="-1" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crop:{crop:"cropsnh:carrot",amount:1,gr:1b,ga:1b,re:1b,scan:1b},progress:1000}' x="0" y="2" z="-1" />
  <Block id="minecraft:sand" x="0" y="0" z="1" />
  <Block id="minecraft:sand" x="0" y="1" z="1" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crop:{crop:"cropsnh:sugarCane",amount:1,gr:1b,ga:1b,re:1b,scan:1b},progress:1000}' x="0" y="2" z="1" />
  <BlockAnnotation pos="0 2 0" color="#80FFAA00" thickness="2" alwaysOnTop={true}>Pumpkin — cross-crop (result grows here)</BlockAnnotation>
  <BlockAnnotation pos="0 2 -1" color="#8044DD66" thickness="2" alwaysOnTop={true}>Carrot (parent)</BlockAnnotation>
  <BlockAnnotation pos="0 2 1" color="#8044DD66" thickness="2" alwaysOnTop={true}>Sugar Cane (parent)</BlockAnnotation>
</GameScene>

## How to obtain

Bred from:

| Parents | Result pools | Notes |
|---------|--------------|-------|
| [Carrot](/crops/carrot.md) + [Sugar Cane](/crops/sugarcane.md) | `EDIBLE`, `ORANGE`, `STEM` | crop-stick cross |

Exact per-tick chance depends on soil and the parents' shared pools — check the [web calculator](https://crops-nh.netlify.app/calculator.html).

## Used to breed

Pumpkin is a parent in these mutations:

| Produces | With |
|----------|------|
| [Bonsai Spruce](/crops/bonsaispruce.md) | [Bonsai Oak](/crops/bonsaioak.md) |
| [Malaxia](/crops/malaxia.md) | [Orange Tulip](/crops/orangetulip.md) + [Stone Lily](/crops/stonelily.md) |
| [Melon](/crops/melon.md) | [Bonsai Jungle](/crops/bonsaijungle.md) |
| [Red Mushroom](/crops/redmushroom.md) | [Poppy](/crops/poppy.md) |
| [Stone Lily](/crops/stonelily.md) | [Vine](/crops/vine.md) |
| [Vine](/crops/vine.md) | [Blue Orchid](/crops/blueorchid.md) |


