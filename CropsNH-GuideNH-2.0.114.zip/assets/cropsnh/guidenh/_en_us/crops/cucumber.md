---
item_id: 'cropsnh:genericSeed:0:{crop:"cropsnh:cucumber"}'
categories:
  - crops
  - tier-4
navigation:
  icon: 'cropsnh:genericSeed:0:{crop:"cropsnh:cucumber"}'
  title: Cucumber
  parent: /crops.md
  position: 16
  keywords:
    - Cucumber
    - Cucumber
---

# Cucumber

**Tier:** 4  
**Soil:** [Farmland](/mechanics/soil-and-blocks.md) — Farmland, Enchanted Earth, Ztones Garden Soil, Fertilized Dirt  
**Likes biomes:** HOT, LUSH  
**Alternate seed:** yes — plantable without breeding  
**Pools:** `EDIBLE`, `GREEN`, `TENDRILLY`  

## Breeding setup

Full breeding setup — a cross-crop stick in the center on Farmland, with the parents planted in a line through it (**Melon** (north), **Carrot** (south)):

<GameScene zoom={4} interactive={true}>
  <Block id="minecraft:dirt" x="0" y="0" z="0" />
  <Block id="minecraft:farmland" x="0" y="1" z="0" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crossCrop:1b}' x="0" y="2" z="0" />
  <Block id="minecraft:dirt" x="0" y="0" z="-1" />
  <Block id="minecraft:farmland" x="0" y="1" z="-1" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crop:{crop:"cropsnh:melon",amount:1,gr:1b,ga:1b,re:1b,scan:1b},progress:1000}' x="0" y="2" z="-1" />
  <Block id="minecraft:dirt" x="0" y="0" z="1" />
  <Block id="minecraft:farmland" x="0" y="1" z="1" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crop:{crop:"cropsnh:carrot",amount:1,gr:1b,ga:1b,re:1b,scan:1b},progress:1000}' x="0" y="2" z="1" />
  <BlockAnnotation pos="0 2 0" color="#80FFAA00" thickness="2" alwaysOnTop={true}>Cucumber — cross-crop (result grows here)</BlockAnnotation>
  <BlockAnnotation pos="0 2 -1" color="#8044DD66" thickness="2" alwaysOnTop={true}>Melon (parent)</BlockAnnotation>
  <BlockAnnotation pos="0 2 1" color="#8044DD66" thickness="2" alwaysOnTop={true}>Carrot (parent)</BlockAnnotation>
</GameScene>

## How to obtain

Bred from:

| Parents | Result pools | Notes |
|---------|--------------|-------|
| [Melon](/crops/melon.md) + [Carrot](/crops/carrot.md) | `EDIBLE`, `GREEN`, `TENDRILLY` | crop-stick cross |

Exact per-tick chance depends on soil and the parents' shared pools — check the [web calculator](https://crops-nh.netlify.app/calculator.html).


