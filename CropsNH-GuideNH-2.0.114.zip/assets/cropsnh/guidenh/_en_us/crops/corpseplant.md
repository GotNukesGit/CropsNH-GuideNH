---
item_id: 'cropsnh:genericSeed:0:{crop:"cropsnh:corpseplant"}'
categories:
  - crops
  - tier-5
navigation:
  icon: 'cropsnh:genericSeed:0:{crop:"cropsnh:corpseplant"}'
  title: Corpseplant
  parent: /crops.md
  position: 15
  keywords:
    - Corpseplant
    - Corpseplant
---

# Corpseplant

**Tier:** 5  
**Soil:** [Graveyard Soil](/mechanics/soil-and-blocks.md) — TiC CraftedSoil:3 (Graveyard Soil)  
**Likes biomes:** DEAD, SPOOKY  
**Alternate seed:** no  
**Pools:** `BROWN`, `EDIBLE`, `EVIL`, `POISONOUS`, `TENDRILLY`, `UNDEAD`  

## Breeding setup

Full breeding setup — a cross-crop stick in the center on Graveyard Soil, with the parents planted in a line through it (**Zomplant** (north), **Eyebulb** (south)):

<GameScene zoom={4} interactive={true}>
  <Block id="tconstruct:CraftedSoil" meta="3" x="0" y="0" z="0" />
  <Block id="tconstruct:CraftedSoil" meta="3" x="0" y="1" z="0" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crossCrop:1b}' x="0" y="2" z="0" />
  <Block id="tconstruct:CraftedSoil" meta="3" x="0" y="0" z="-1" />
  <Block id="tconstruct:CraftedSoil" meta="3" x="0" y="1" z="-1" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crop:{crop:"cropsnh:zomplant",amount:1,gr:1b,ga:1b,re:1b,scan:1b},progress:1000}' x="0" y="2" z="-1" />
  <Block id="minecraft:netherrack" x="0" y="0" z="1" />
  <Block id="minecraft:netherrack" x="0" y="1" z="1" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crop:{crop:"cropsnh:eyebulb",amount:1,gr:1b,ga:1b,re:1b,scan:1b},progress:1000}' x="0" y="2" z="1" />
  <BlockAnnotation pos="0 2 0" color="#80FFAA00" thickness="2" alwaysOnTop={true}>Corpseplant — cross-crop (result grows here)</BlockAnnotation>
  <BlockAnnotation pos="0 2 -1" color="#8044DD66" thickness="2" alwaysOnTop={true}>Zomplant (parent)</BlockAnnotation>
  <BlockAnnotation pos="0 2 1" color="#8044DD66" thickness="2" alwaysOnTop={true}>Eyebulb (parent)</BlockAnnotation>
</GameScene>

## How to obtain

Bred from:

| Parents | Result pools | Notes |
|---------|--------------|-------|
| [Zomplant](/crops/zomplant.md) + [Eyebulb](/crops/eyebulb.md) | `BROWN`, `EDIBLE`, `EVIL`, `POISONOUS`, `TENDRILLY`, `UNDEAD` | crop-stick cross |

Exact per-tick chance depends on soil and the parents' shared pools — check the [web calculator](https://crops-nh.netlify.app/calculator.html).

## Used to breed

Corpseplant is a parent in these mutations:

| Produces | With |
|----------|------|
| [Fertilia](/crops/fertilia.md) | [Corium](/crops/corium.md) |


