---
item_id: 'cropsnh:genericSeed:0:{crop:"cropsnh:copperOreBerry"}'
categories:
  - crops
  - tier-5
navigation:
  icon: 'cropsnh:genericSeed:0:{crop:"cropsnh:copperOreBerry"}'
  title: Copper Ore Berry
  parent: /crops.md
  position: 15
  keywords:
    - Copper Ore Berry
    - CopperOreBerry
---

# Copper Ore Berry

> [!WARNING]
> **Buried block required.** This crop needs a `copper` block two spaces below the cross-crop stick (directly under the soil). Without it the crop won't grow — see the setup scene below.

**Tier:** 5  
**Soil:** [Stone](/mechanics/soil-and-blocks.md) — Stone, Cobblestone, Stone Brick, Mossy Cobble + Chisel variants  
**Block under soil:** `copper`  
**Likes biomes:** SAVANNA, HOT, SANDY  
**Alternate seed:** yes — plantable without breeding  
**Pools:** `COPPER`, `DANGEROUS`, `METALLIC`, `ORANGE`, `ORE_BERRY`, `SHINY`  

TiC req

## Breeding setup

Full breeding setup — a cross-crop stick in the center on Stone over a **copper** block, with the parents planted around it (**Malaxia** (north), **BoP Berry** (south), **Stone Lily** (east)):

<GameScene zoom={4} interactive={true}>
  <Block id="gregtech:gt.blockmetal2" meta="7" x="0" y="0" z="0" />
  <Block id="minecraft:stone" x="0" y="1" z="0" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crossCrop:1b}' x="0" y="2" z="0" />
  <Block id="gregtech:gt.blockmetal2" meta="7" x="0" y="0" z="-1" />
  <Block id="minecraft:stone" x="0" y="1" z="-1" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crop:{crop:"cropsnh:malaxia",amount:1,gr:1b,ga:1b,re:1b,scan:1b},progress:1000}' x="0" y="2" z="-1" />
  <Block id="minecraft:dirt" x="0" y="0" z="1" />
  <Block id="minecraft:farmland" x="0" y="1" z="1" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crop:{crop:"cropsnh:bopBerry",amount:1,gr:1b,ga:1b,re:1b,scan:1b},progress:1000}' x="0" y="2" z="1" />
  <Block id="minecraft:stone" x="1" y="0" z="0" />
  <Block id="minecraft:stone" x="1" y="1" z="0" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crop:{crop:"cropsnh:stoneLily",amount:1,gr:1b,ga:1b,re:1b,scan:1b},progress:1000}' x="1" y="2" z="0" />
  <BlockAnnotation pos="0 2 0" color="#80FFAA00" thickness="2" alwaysOnTop={true}>Copper Ore Berry — cross-crop (result grows here)</BlockAnnotation>
  <BlockAnnotation pos="0 2 -1" color="#8044DD66" thickness="2" alwaysOnTop={true}>Malaxia (parent)</BlockAnnotation>
  <BlockAnnotation pos="0 2 1" color="#8044DD66" thickness="2" alwaysOnTop={true}>BoP Berry (parent)</BlockAnnotation>
  <BlockAnnotation pos="1 2 0" color="#8044DD66" thickness="2" alwaysOnTop={true}>Stone Lily (parent)</BlockAnnotation>
</GameScene>

## How to obtain

Bred from:

| Parents | Result pools | Notes |
|---------|--------------|-------|
| [Malaxia](/crops/malaxia.md) + [BoP Berry](/crops/bopberry.md) + [Stone Lily](/crops/stonelily.md) | `COPPER`, `DANGEROUS`, `METALLIC`, `ORANGE`, `ORE_BERRY`, `SHINY` | crop-stick cross |

Exact per-tick chance depends on soil and the parents' shared pools — check the [web calculator](https://crops-nh.netlify.app/calculator.html).

## Used to breed

Copper Ore Berry is a parent in these mutations:

| Produces | With |
|----------|------|
| [Ardite Ore Berry](/crops/arditeoreberry.md) | [Nether Stone Lily](/crops/netherstonelily.md) + [Coppon](/crops/coppon.md) + [Malaxia](/crops/malaxia.md) |
| [Gold Ore Berry](/crops/goldoreberry.md) | [Iron Ore Berry](/crops/ironoreberry.md) + [Tin Ore Berry](/crops/tinoreberry.md) |


