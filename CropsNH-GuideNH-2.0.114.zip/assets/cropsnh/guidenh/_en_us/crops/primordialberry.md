---
item_id: 'cropsnh:genericSeed:0:{crop:"cropsnh:primordialBerry"}'
categories:
  - crops
  - tier-16
navigation:
  icon: 'cropsnh:genericSeed:0:{crop:"cropsnh:primordialBerry"}'
  title: Primordial Berry
  parent: /crops.md
  position: 4
  keywords:
    - Primordial Berry
    - PrimordialBerry
---

# Primordial Berry

> [!NOTE]
> **Directly obtainable.** No breeding recipe — plant it from a seed you can get by other means

**Tier:** 16  
**Soil:** [Farmland](/mechanics/soil-and-blocks.md) — Farmland, Enchanted Earth, Ztones Garden Soil, Fertilized Dirt  
**Likes biomes:** END, MAGICAL  
**Alternate seed:** yes — plantable without breeding  

Has alternate seed (Thaumcraft Primordial Pearl). Thaumcraft req.

## Setup

Grow **Primordial Berry** on Farmland:

<GameScene zoom={4} interactive={true}>
  <Block id="minecraft:dirt" x="0" y="0" z="0" />
  <Block id="minecraft:farmland" x="0" y="1" z="0" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crop:{crop:"cropsnh:primordialBerry",amount:1,gr:1b,ga:1b,re:1b,scan:1b},progress:1000}' x="0" y="2" z="0" />
  <BlockAnnotation pos="0 2 0" color="#8044DD66" thickness="2" alwaysOnTop={true}>Primordial Berry</BlockAnnotation>
</GameScene>

## How to obtain

No breeding recipe — obtain the seed directly.

## Used to breed

Primordial Berry is a parent in these mutations:

| Produces | With |
|----------|------|
| [Magical Nightshade](/crops/magicalnightshade.md) | [Mana Bean](/crops/manabean.md) + [Cinderpearl](/crops/cinderpearl.md) + [Shimmerleaf](/crops/shimmerleaf.md) |


