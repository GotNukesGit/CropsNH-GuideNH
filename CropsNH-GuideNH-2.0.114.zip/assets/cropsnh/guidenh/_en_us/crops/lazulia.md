---
item_id: 'cropsnh:genericSeed:0:{crop:"cropsnh:lazulia"}'
categories:
  - crops
  - tier-7
navigation:
  icon: 'cropsnh:genericSeed:0:{crop:"cropsnh:lazulia"}'
  title: Lazulia
  parent: /crops.md
  position: 13
  keywords:
    - Lazulia
    - Lazulia
---

# Lazulia

> [!WARNING]
> **Buried block required.** This crop needs a `lapis` block two spaces below the cross-crop stick (directly under the soil). Without it the crop won't grow — see the setup scene below.

**Tier:** 7  
**Soil:** [Stone](/mechanics/soil-and-blocks.md) — Stone, Cobblestone, Stone Brick, Mossy Cobble + Chisel variants  
**Block under soil:** `lapis`  
**Likes biomes:** HOT, SANDY  
**Alternate seed:** no  
**Pools:** `BLUE`, `CRYSTALLINE`, `HEALING`, `SHINY`  

## Breeding setup

Full breeding setup — a cross-crop stick in the center on Stone over a **lapis** block, with the parents planted in a line through it (**Stone Lily** (north), **Indigo** (south)):

<GameScene zoom={4} interactive={true}>
  <Block id="minecraft:lapis_block" x="0" y="0" z="0" />
  <Block id="minecraft:stone" x="0" y="1" z="0" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crossCrop:1b}' x="0" y="2" z="0" />
  <Block id="minecraft:stone" x="0" y="0" z="-1" />
  <Block id="minecraft:stone" x="0" y="1" z="-1" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crop:{crop:"cropsnh:stoneLily",amount:1,gr:1b,ga:1b,re:1b,scan:1b},progress:1000}' x="0" y="2" z="-1" />
  <Block id="minecraft:dirt" x="0" y="0" z="1" />
  <Block id="minecraft:dirt" x="0" y="1" z="1" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crop:{crop:"cropsnh:indigo",amount:1,gr:1b,ga:1b,re:1b,scan:1b},progress:1000}' x="0" y="2" z="1" />
  <BlockAnnotation pos="0 2 0" color="#80FFAA00" thickness="2" alwaysOnTop={true}>Lazulia — cross-crop (result grows here)</BlockAnnotation>
  <BlockAnnotation pos="0 2 -1" color="#8044DD66" thickness="2" alwaysOnTop={true}>Stone Lily (parent)</BlockAnnotation>
  <BlockAnnotation pos="0 2 1" color="#8044DD66" thickness="2" alwaysOnTop={true}>Indigo (parent)</BlockAnnotation>
</GameScene>

## How to obtain

Bred from:

| Parents | Result pools | Notes |
|---------|--------------|-------|
| [Stone Lily](/crops/stonelily.md) + [Indigo](/crops/indigo.md) | `BLUE`, `CRYSTALLINE`, `HEALING`, `SHINY` | crop-stick cross |

Exact per-tick chance depends on soil and the parents' shared pools — check the [web calculator](https://crops-nh.netlify.app/calculator.html).

## Used to breed

Lazulia is a parent in these mutations:

| Produces | With |
|----------|------|
| [Cobalt Ore Berry](/crops/cobaltoreberry.md) | [Nether Stone Lily](/crops/netherstonelily.md) + [Ardite Ore Berry](/crops/arditeoreberry.md) + [Gold Ore Berry](/crops/goldoreberry.md) |
| [Sapphirum](/crops/sapphirum.md) | [Evil Ore](/crops/evilore.md) |


