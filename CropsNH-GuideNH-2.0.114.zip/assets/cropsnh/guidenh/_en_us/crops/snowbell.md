---
item_id: 'cropsnh:genericSeed:0:{crop:"cropsnh:snowbell"}'
categories:
  - crops
  - tier-4
navigation:
  icon: 'cropsnh:genericSeed:0:{crop:"cropsnh:snowbell"}'
  title: Snowbell
  parent: /crops.md
  position: 16
  keywords:
    - Snowbell
    - Snowbell
---

# Snowbell

**Tier:** 4  
**Soil:** [Farmland](/mechanics/soil-and-blocks.md) — Farmland, Enchanted Earth, Ztones Garden Soil, Fertilized Dirt  
**Likes biomes:** SNOWY, COLD  
**Alternate seed:** yes — plantable without breeding  
**Pools:** `FLOWER`, `POISONOUS`, `POTION_INGREDIENT`, `WHITE`  

Witchery req

## Breeding setup

Full breeding setup — a cross-crop stick in the center on Farmland, with the parents planted in a line through it (**Belladonna** (north), **Glint Weed** (south)):

<GameScene zoom={4} interactive={true}>
  <Block id="minecraft:dirt" x="0" y="0" z="0" />
  <Block id="minecraft:farmland" x="0" y="1" z="0" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crossCrop:1b}' x="0" y="2" z="0" />
  <Block id="minecraft:dirt" x="0" y="0" z="-1" />
  <Block id="minecraft:farmland" x="0" y="1" z="-1" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crop:{crop:"cropsnh:belladonna",amount:1,gr:1b,ga:1b,re:1b,scan:1b},progress:1000}' x="0" y="2" z="-1" />
  <Block id="minecraft:dirt" x="0" y="0" z="1" />
  <Block id="minecraft:farmland" x="0" y="1" z="1" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crop:{crop:"cropsnh:glintWeed",amount:1,gr:1b,ga:1b,re:1b,scan:1b},progress:1000}' x="0" y="2" z="1" />
  <BlockAnnotation pos="0 2 0" color="#80FFAA00" thickness="2" alwaysOnTop={true}>Snowbell — cross-crop (result grows here)</BlockAnnotation>
  <BlockAnnotation pos="0 2 -1" color="#8044DD66" thickness="2" alwaysOnTop={true}>Belladonna (parent)</BlockAnnotation>
  <BlockAnnotation pos="0 2 1" color="#8044DD66" thickness="2" alwaysOnTop={true}>Glint Weed (parent)</BlockAnnotation>
</GameScene>

## How to obtain

Bred from:

| Parents | Result pools | Notes |
|---------|--------------|-------|
| [Belladonna](/crops/belladonna.md) + [Glint Weed](/crops/glintweed.md) | `FLOWER`, `POISONOUS`, `POTION_INGREDIENT`, `WHITE` | crop-stick cross |

Exact per-tick chance depends on soil and the parents' shared pools — check the [web calculator](https://crops-nh.netlify.app/calculator.html).


