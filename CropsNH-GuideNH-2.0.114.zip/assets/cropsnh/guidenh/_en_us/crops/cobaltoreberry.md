---
item_id: 'cropsnh:genericSeed:0:{crop:"cropsnh:cobaltOreBerry"}'
categories:
  - crops
  - tier-5
navigation:
  icon: 'cropsnh:genericSeed:0:{crop:"cropsnh:cobaltOreBerry"}'
  title: Cobalt Ore Berry
  parent: /crops.md
  position: 15
  keywords:
    - Cobalt Ore Berry
    - CobaltOreBerry
---

# Cobalt Ore Berry

> [!WARNING]
> **Buried block required.** This crop needs a `cobalt` block two spaces below the cross-crop stick (directly under the soil). Without it the crop won't grow — see the setup scene below.

**Tier:** 5  
**Soil:** [Stone](/mechanics/soil-and-blocks.md) — Stone, Cobblestone, Stone Brick, Mossy Cobble + Chisel variants  
**Block under soil:** `cobalt`  
**Likes biomes:** NETHER, DRY  
**Alternate seed:** no  
**Pools:** `BLUE`, `DANGEROUS`, `METALLIC`, `NETHER`, `ORE_BERRY`  

TiC req

## Breeding setup

Full breeding setup — a cross-crop stick in the center on Stone over a **cobalt** block, with the parents planted around it (**Nether Stone Lily** (north), **Ardite Ore Berry** (south), **Lazulia** (east), **Gold Ore Berry** (west)):

<GameScene zoom={4} interactive={true}>
  <Block id="gregtech:gt.blockmetal2" meta="5" x="0" y="0" z="0" />
  <Block id="minecraft:stone" x="0" y="1" z="0" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crossCrop:1b}' x="0" y="2" z="0" />
  <Block id="minecraft:netherrack" x="0" y="0" z="-1" />
  <Block id="minecraft:stone" x="0" y="1" z="-1" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crop:{crop:"cropsnh:netherStoneLily",amount:1,gr:1b,ga:1b,re:1b,scan:1b},progress:1000}' x="0" y="2" z="-1" />
  <Block id="TConstruct:decoration.multibrickmetal" meta="1" x="0" y="0" z="1" />
  <Block id="minecraft:stone" x="0" y="1" z="1" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crop:{crop:"cropsnh:arditeOreBerry",amount:1,gr:1b,ga:1b,re:1b,scan:1b},progress:1000}' x="0" y="2" z="1" />
  <Block id="minecraft:lapis_block" x="1" y="0" z="0" />
  <Block id="minecraft:stone" x="1" y="1" z="0" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crop:{crop:"cropsnh:lazulia",amount:1,gr:1b,ga:1b,re:1b,scan:1b},progress:1000}' x="1" y="2" z="0" />
  <Block id="minecraft:gold_block" x="-1" y="0" z="0" />
  <Block id="minecraft:stone" x="-1" y="1" z="0" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crop:{crop:"cropsnh:goldOreBerry",amount:1,gr:1b,ga:1b,re:1b,scan:1b},progress:1000}' x="-1" y="2" z="0" />
  <BlockAnnotation pos="0 2 0" color="#80FFAA00" thickness="2" alwaysOnTop={true}>Cobalt Ore Berry — cross-crop (result grows here)</BlockAnnotation>
  <BlockAnnotation pos="0 2 -1" color="#8044DD66" thickness="2" alwaysOnTop={true}>Nether Stone Lily (parent)</BlockAnnotation>
  <BlockAnnotation pos="0 2 1" color="#8044DD66" thickness="2" alwaysOnTop={true}>Ardite Ore Berry (parent)</BlockAnnotation>
  <BlockAnnotation pos="1 2 0" color="#8044DD66" thickness="2" alwaysOnTop={true}>Lazulia (parent)</BlockAnnotation>
  <BlockAnnotation pos="-1 2 0" color="#8044DD66" thickness="2" alwaysOnTop={true}>Gold Ore Berry (parent)</BlockAnnotation>
</GameScene>

## How to obtain

Bred from:

| Parents | Result pools | Notes |
|---------|--------------|-------|
| [Nether Stone Lily](/crops/netherstonelily.md) + [Ardite Ore Berry](/crops/arditeoreberry.md) + [Lazulia](/crops/lazulia.md) + [Gold Ore Berry](/crops/goldoreberry.md) | `BLUE`, `DANGEROUS`, `METALLIC`, `NETHER`, `ORE_BERRY` | crop-stick cross |

Exact per-tick chance depends on soil and the parents' shared pools — check the [web calculator](https://crops-nh.netlify.app/calculator.html).


