---
item_id: 'cropsnh:genericSeed:0:{crop:"cropsnh:bopBerry"}'
categories:
  - crops
  - tier-2
navigation:
  icon: 'cropsnh:genericSeed:0:{crop:"cropsnh:bopBerry"}'
  title: BoP Berry
  parent: /crops.md
  position: 18
  keywords:
    - BoP Berry
    - BoPBerry
---

# BoP Berry

**Tier:** 2  
**Soil:** [Farmland](/mechanics/soil-and-blocks.md) — Farmland, Enchanted Earth, Ztones Garden Soil, Fertilized Dirt  
**Likes biomes:** FOREST, DENSE  
**Alternate seed:** yes — plantable without breeding  
**Pools:** `BERRY`, `BUSH`, `EDIBLE`, `RED`  

BoP req

## Breeding setup

Full breeding setup — a cross-crop stick in the center on Farmland, with the parents planted in a line through it (**Poppy** (north), **Blackberry** (south)):

<GameScene zoom={4} interactive={true}>
  <Block id="minecraft:dirt" x="0" y="0" z="0" />
  <Block id="minecraft:farmland" x="0" y="1" z="0" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crossCrop:1b}' x="0" y="2" z="0" />
  <Block id="minecraft:dirt" x="0" y="0" z="-1" />
  <Block id="minecraft:dirt" x="0" y="1" z="-1" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crop:{crop:"cropsnh:poppy",amount:1,gr:1b,ga:1b,re:1b,scan:1b},progress:1000}' x="0" y="2" z="-1" />
  <Block id="minecraft:dirt" x="0" y="0" z="1" />
  <Block id="minecraft:farmland" x="0" y="1" z="1" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crop:{crop:"cropsnh:blackberry",amount:1,gr:1b,ga:1b,re:1b,scan:1b},progress:1000}' x="0" y="2" z="1" />
  <BlockAnnotation pos="0 2 0" color="#80FFAA00" thickness="2" alwaysOnTop={true}>BoP Berry — cross-crop (result grows here)</BlockAnnotation>
  <BlockAnnotation pos="0 2 -1" color="#8044DD66" thickness="2" alwaysOnTop={true}>Poppy (parent)</BlockAnnotation>
  <BlockAnnotation pos="0 2 1" color="#8044DD66" thickness="2" alwaysOnTop={true}>Blackberry (parent)</BlockAnnotation>
</GameScene>

## How to obtain

Bred from:

| Parents | Result pools | Notes |
|---------|--------------|-------|
| [Poppy](/crops/poppy.md) + [Blackberry](/crops/blackberry.md) | `BERRY`, `BUSH`, `EDIBLE`, `RED` | crop-stick cross |

Exact per-tick chance depends on soil and the parents' shared pools — check the [web calculator](https://crops-nh.netlify.app/calculator.html).

## Used to breed

BoP Berry is a parent in these mutations:

| Produces | With |
|----------|------|
| [Copper Ore Berry](/crops/copperoreberry.md) | [Malaxia](/crops/malaxia.md) + [Stone Lily](/crops/stonelily.md) |
| [Tin Ore Berry](/crops/tinoreberry.md) | [Cassitine](/crops/cassitine.md) + [Stone Lily](/crops/stonelily.md) |
| [Torchberry](/crops/torchberry.md) | [Glowflower](/crops/glowflower.md) |
| [Turnip](/crops/turnip.md) | [Potato](/crops/potato.md) |
| [Wild Carrot](/crops/wildcarrot.md) | [Carrot](/crops/carrot.md) |


