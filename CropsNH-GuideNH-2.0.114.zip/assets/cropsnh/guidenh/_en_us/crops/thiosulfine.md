---
item_id: 'cropsnh:genericSeed:0:{crop:"cropsnh:thiosulfine"}'
categories:
  - crops
  - tier-6
navigation:
  icon: 'cropsnh:genericSeed:0:{crop:"cropsnh:thiosulfine"}'
  title: Thiosulfine
  parent: /crops.md
  position: 14
  keywords:
    - Thiosulfine
    - Thiosulfine
---

# Thiosulfine

> [!WARNING]
> **Buried block required.** This crop needs a `sulfur` block two spaces below the cross-crop stick (directly under the soil). Without it the crop won't grow — see the setup scene below.

**Tier:** 6  
**Soil:** [Stone](/mechanics/soil-and-blocks.md) — Stone, Cobblestone, Stone Brick, Mossy Cobble + Chisel variants  
**Block under soil:** `sulfur`  
**Likes biomes:** NETHER, HOT  
**Alternate seed:** no  
**Pools:** `DANGEROUS`, `FLOWER`, `SULFUR`, `YELLOW`  

## Breeding setup

Full breeding setup — a cross-crop stick in the center on Stone over a **sulfur** block, with the parents planted in a line through it (**Galvania** (north), **Plumbilia** (south)):

<GameScene zoom={4} interactive={true}>
  <Block id="gregtech:gt.blockores" nbt='{id:"GT_TileEntity_Ores",m:22s,n:0b}' x="0" y="0" z="0" />
  <Block id="minecraft:stone" x="0" y="1" z="0" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crossCrop:1b}' x="0" y="2" z="0" />
  <Block id="gregtech:gt.blockmetal8" meta="6" x="0" y="0" z="-1" />
  <Block id="minecraft:stone" x="0" y="1" z="-1" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crop:{crop:"cropsnh:galvania",amount:1,gr:1b,ga:1b,re:1b,scan:1b},progress:1000}' x="0" y="2" z="-1" />
  <Block id="gregtech:gt.blockmetal4" meta="2" x="0" y="0" z="1" />
  <Block id="minecraft:stone" x="0" y="1" z="1" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crop:{crop:"cropsnh:plumbilia",amount:1,gr:1b,ga:1b,re:1b,scan:1b},progress:1000}' x="0" y="2" z="1" />
  <BlockAnnotation pos="0 2 0" color="#80FFAA00" thickness="2" alwaysOnTop={true}>Thiosulfine — cross-crop (result grows here)</BlockAnnotation>
  <BlockAnnotation pos="0 2 -1" color="#8044DD66" thickness="2" alwaysOnTop={true}>Galvania (parent)</BlockAnnotation>
  <BlockAnnotation pos="0 2 1" color="#8044DD66" thickness="2" alwaysOnTop={true}>Plumbilia (parent)</BlockAnnotation>
</GameScene>

## How to obtain

Bred from:

| Parents | Result pools | Notes |
|---------|--------------|-------|
| [Galvania](/crops/galvania.md) + [Plumbilia](/crops/plumbilia.md) | `DANGEROUS`, `FLOWER`, `SULFUR`, `YELLOW` | crop-stick cross |

Exact per-tick chance depends on soil and the parents' shared pools — check the [web calculator](https://crops-nh.netlify.app/calculator.html).


