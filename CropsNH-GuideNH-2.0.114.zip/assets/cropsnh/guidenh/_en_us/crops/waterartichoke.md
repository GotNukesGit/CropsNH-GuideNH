---
item_id: 'cropsnh:genericSeed:0:{crop:"cropsnh:waterArtichoke"}'
categories:
  - crops
  - tier-4
navigation:
  icon: 'cropsnh:genericSeed:0:{crop:"cropsnh:waterArtichoke"}'
  title: Water Artichoke
  parent: /crops.md
  position: 16
  keywords:
    - Water Artichoke
    - WaterArtichoke
---

# Water Artichoke

**Tier:** 4  
**Soil:** [Farmland](/mechanics/soil-and-blocks.md) — Farmland, Enchanted Earth, Ztones Garden Soil, Fertilized Dirt  
**Likes biomes:** RIVER, WET, OCEAN  
**Alternate seed:** yes — plantable without breeding  
**Pools:** `BLUE`, `EDIBLE`, `FLOWER`, `POTION_INGREDIENT`, `WATERY`  

Witchery req

## Breeding setup

Full breeding setup — a cross-crop stick in the center on Farmland, with the parents planted in a line through it (**Waterlily** (north), **Hops** (south)):

<GameScene zoom={4} interactive={true}>
  <Block id="minecraft:dirt" x="0" y="0" z="0" />
  <Block id="minecraft:farmland" x="0" y="1" z="0" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crossCrop:1b}' x="0" y="2" z="0" />
  <Block id="minecraft:dirt" x="0" y="0" z="-1" />
  <Block id="minecraft:farmland" x="0" y="1" z="-1" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crop:{crop:"cropsnh:waterLily",amount:1,gr:1b,ga:1b,re:1b,scan:1b},progress:1000}' x="0" y="2" z="-1" />
  <Block id="minecraft:dirt" x="0" y="0" z="1" />
  <Block id="minecraft:farmland" x="0" y="1" z="1" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crop:{crop:"cropsnh:hops",amount:1,gr:1b,ga:1b,re:1b,scan:1b},progress:1000}' x="0" y="2" z="1" />
  <BlockAnnotation pos="0 2 0" color="#80FFAA00" thickness="2" alwaysOnTop={true}>Water Artichoke — cross-crop (result grows here)</BlockAnnotation>
  <BlockAnnotation pos="0 2 -1" color="#8044DD66" thickness="2" alwaysOnTop={true}>Waterlily (parent)</BlockAnnotation>
  <BlockAnnotation pos="0 2 1" color="#8044DD66" thickness="2" alwaysOnTop={true}>Hops (parent)</BlockAnnotation>
</GameScene>

## How to obtain

Bred from:

| Parents | Result pools | Notes |
|---------|--------------|-------|
| [Waterlily](/crops/waterlily.md) + [Hops](/crops/hops.md) | `BLUE`, `EDIBLE`, `FLOWER`, `POTION_INGREDIENT`, `WATERY` | crop-stick cross |

Exact per-tick chance depends on soil and the parents' shared pools — check the [web calculator](https://crops-nh.netlify.app/calculator.html).

## Used to breed

Water Artichoke is a parent in these mutations:

| Produces | With |
|----------|------|
| [Goldfish](/crops/goldfish.md) | [Waterlily](/crops/waterlily.md) + [Mandrake](/crops/mandrake.md) |
| [Wolfsbane](/crops/wolfsbane.md) | [Belladonna](/crops/belladonna.md) |


