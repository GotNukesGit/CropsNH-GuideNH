---
item_id: 'cropsnh:genericSeed:0:{crop:"cropsnh:transformium"}'
categories:
  - crops
  - tier-12
navigation:
  icon: 'cropsnh:genericSeed:0:{crop:"cropsnh:transformium"}'
  title: Transformium
  parent: /crops.md
  position: 8
  keywords:
    - Transformium
    - Transformium
---

# Transformium

> [!NOTE]
> **Machine-only.** Produced by a machine process, not by breeding on crop sticks.

**Tier:** 12  
**Soil:** [Farmland](/mechanics/soil-and-blocks.md) — Farmland, Enchanted Earth, Ztones Garden Soil, Fertilized Dirt  
**Likes biomes:** END, COLD  
**Alternate seed:** no  

Crop Synthesizer only. Extreme late-game. No pool membership.

## Breeding setup

Full breeding setup — a cross-crop stick in the center on Farmland, with the parents planted around it (**Trollplant** (north), **Bauxia** (south), **Titania** (east)):

<GameScene zoom={4} interactive={true}>
  <Block id="minecraft:dirt" x="0" y="0" z="0" />
  <Block id="minecraft:farmland" x="0" y="1" z="0" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crossCrop:1b}' x="0" y="2" z="0" />
  <Block id="minecraft:brick_block" x="0" y="0" z="-1" />
  <Block id="minecraft:brick_block" x="0" y="1" z="-1" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crop:{crop:"cropsnh:trollplant",amount:1,gr:1b,ga:1b,re:1b,scan:1b},progress:1000}' x="0" y="2" z="-1" />
  <Block id="gregtech:gt.blockmetal1" meta="1" x="0" y="0" z="1" />
  <Block id="minecraft:stone" x="0" y="1" z="1" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crop:{crop:"cropsnh:bauxia",amount:1,gr:1b,ga:1b,re:1b,scan:1b},progress:1000}' x="0" y="2" z="1" />
  <Block id="gregtech:gt.blockmetal7" meta="9" x="1" y="0" z="0" />
  <Block id="minecraft:stone" x="1" y="1" z="0" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crop:{crop:"cropsnh:titania",amount:1,gr:1b,ga:1b,re:1b,scan:1b},progress:1000}' x="1" y="2" z="0" />
  <BlockAnnotation pos="0 2 0" color="#80FFAA00" thickness="2" alwaysOnTop={true}>Transformium — cross-crop (result grows here)</BlockAnnotation>
  <BlockAnnotation pos="0 2 -1" color="#8044DD66" thickness="2" alwaysOnTop={true}>Trollplant (parent)</BlockAnnotation>
  <BlockAnnotation pos="0 2 1" color="#8044DD66" thickness="2" alwaysOnTop={true}>Bauxia (parent)</BlockAnnotation>
  <BlockAnnotation pos="1 2 0" color="#8044DD66" thickness="2" alwaysOnTop={true}>Titania (parent)</BlockAnnotation>
</GameScene>

## How to obtain

Bred from:

| Parents | Result pools | Notes |
|---------|--------------|-------|
| [Trollplant](/crops/trollplant.md) + [Bauxia](/crops/bauxia.md) + [Titania](/crops/titania.md) | — | machine recipe |

Exact per-tick chance depends on soil and the parents' shared pools — check the [web calculator](https://crops-nh.netlify.app/calculator.html).


