---
item_id: 'cropsnh:genericSeed:0:{crop:"cropsnh:sandLily"}'
categories:
  - crops
  - tier-1
navigation:
  icon: 'cropsnh:genericSeed:0:{crop:"cropsnh:sandLily"}'
  title: Sand Lily
  parent: /crops.md
  position: 19
  keywords:
    - Sand Lily
    - SandLily
---

# Sand Lily

> [!WARNING]
> **Buried block required.** This crop needs a `sand` block two spaces below the cross-crop stick (directly under the soil). Without it the crop won't grow — see the setup scene below.

**Tier:** 1  
**Soil:** [Stone](/mechanics/soil-and-blocks.md) — Stone, Cobblestone, Stone Brick, Mossy Cobble + Chisel variants  
**Block under soil:** `sand`  
**Likes biomes:** SANDY, DRY, HOT  
**Alternate seed:** no  
**Pools:** `STONE`, `YELLOW`  

## Breeding setup

Full breeding setup — a cross-crop stick in the center on Stone over a **sand** block, with the parents planted in a line through it (**Stone Lily** (north), **Cactus** (south)):

<GameScene zoom={4} interactive={true}>
  <Block id="minecraft:sand" x="0" y="0" z="0" />
  <Block id="minecraft:stone" x="0" y="1" z="0" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crossCrop:1b}' x="0" y="2" z="0" />
  <Block id="minecraft:stone" x="0" y="0" z="-1" />
  <Block id="minecraft:stone" x="0" y="1" z="-1" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crop:{crop:"cropsnh:stoneLily",amount:1,gr:1b,ga:1b,re:1b,scan:1b},progress:1000}' x="0" y="2" z="-1" />
  <Block id="minecraft:sand" x="0" y="0" z="1" />
  <Block id="minecraft:sand" x="0" y="1" z="1" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crop:{crop:"cropsnh:cactus",amount:1,gr:1b,ga:1b,re:1b,scan:1b},progress:1000}' x="0" y="2" z="1" />
  <BlockAnnotation pos="0 2 0" color="#80FFAA00" thickness="2" alwaysOnTop={true}>Sand Lily — cross-crop (result grows here)</BlockAnnotation>
  <BlockAnnotation pos="0 2 -1" color="#8044DD66" thickness="2" alwaysOnTop={true}>Stone Lily (parent)</BlockAnnotation>
  <BlockAnnotation pos="0 2 1" color="#8044DD66" thickness="2" alwaysOnTop={true}>Cactus (parent)</BlockAnnotation>
</GameScene>

## How to obtain

Bred from:

| Parents | Result pools | Notes |
|---------|--------------|-------|
| [Stone Lily](/crops/stonelily.md) + [Cactus](/crops/cactus.md) | `STONE`, `YELLOW` | crop-stick cross |

Exact per-tick chance depends on soil and the parents' shared pools — check the [web calculator](https://crops-nh.netlify.app/calculator.html).

## Used to breed

Sand Lily is a parent in these mutations:

| Produces | With |
|----------|------|
| [Saguaro Cactus](/crops/saguarocactus.md) | [Cactus](/crops/cactus.md) |
| [Soul Sand Lily](/crops/soulsandlily.md) | [Nether Stone Lily](/crops/netherstonelily.md) |


