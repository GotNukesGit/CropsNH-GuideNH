---
item_id: 'cropsnh:genericSeed:0:{crop:"cropsnh:stoneLily"}'
categories:
  - crops
  - tier-1
navigation:
  icon: 'cropsnh:genericSeed:0:{crop:"cropsnh:stoneLily"}'
  title: Stone Lily
  parent: /crops.md
  position: 19
  keywords:
    - Stone Lily
    - StoneLily
---

# Stone Lily

> [!WARNING]
> **Buried block required.** This crop needs a `stone` block two spaces below the cross-crop stick (directly under the soil). Without it the crop won't grow — see the setup scene below.

**Tier:** 1  
**Soil:** [Stone](/mechanics/soil-and-blocks.md) — Stone, Cobblestone, Stone Brick, Mossy Cobble + Chisel variants  
**Block under soil:** `stone`  
**Likes biomes:** MOUNTAIN, HILLS  
**Alternate seed:** no  
**Pools:** `GRAY`, `STONE`  

## Breeding setup

Full breeding setup — a cross-crop stick in the center on Stone over a **stone** block, with the parents planted in a line through it (**Vine** (north), **Pumpkin** (south)):

<GameScene zoom={4} interactive={true}>
  <Block id="minecraft:stone" x="0" y="0" z="0" />
  <Block id="minecraft:stone" x="0" y="1" z="0" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crossCrop:1b}' x="0" y="2" z="0" />
  <Block id="minecraft:dirt" x="0" y="0" z="-1" />
  <Block id="minecraft:farmland" x="0" y="1" z="-1" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crop:{crop:"cropsnh:vine",amount:1,gr:1b,ga:1b,re:1b,scan:1b},progress:1000}' x="0" y="2" z="-1" />
  <Block id="minecraft:dirt" x="0" y="0" z="1" />
  <Block id="minecraft:farmland" x="0" y="1" z="1" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crop:{crop:"cropsnh:pumpkin",amount:1,gr:1b,ga:1b,re:1b,scan:1b},progress:1000}' x="0" y="2" z="1" />
  <BlockAnnotation pos="0 2 0" color="#80FFAA00" thickness="2" alwaysOnTop={true}>Stone Lily — cross-crop (result grows here)</BlockAnnotation>
  <BlockAnnotation pos="0 2 -1" color="#8044DD66" thickness="2" alwaysOnTop={true}>Vine (parent)</BlockAnnotation>
  <BlockAnnotation pos="0 2 1" color="#8044DD66" thickness="2" alwaysOnTop={true}>Pumpkin (parent)</BlockAnnotation>
</GameScene>

## How to obtain

Bred from:

| Parents | Result pools | Notes |
|---------|--------------|-------|
| [Vine](/crops/vine.md) + [Pumpkin](/crops/pumpkin.md) | `GRAY`, `STONE` | crop-stick cross |

Exact per-tick chance depends on soil and the parents' shared pools — check the [web calculator](https://crops-nh.netlify.app/calculator.html).

## Used to breed

Stone Lily is a parent in these mutations:

| Produces | With |
|----------|------|
| [Andesite Lily](/crops/andesitelily.md) | [Clay Lily](/crops/claylily.md) |
| [Basalt Lily](/crops/basaltlily.md) | [Ink Bloom](/crops/inkbloom.md) |
| [Black Granite Lily](/crops/blackgranitelily.md) | [Basalt Lily](/crops/basaltlily.md) |
| [Cassitine](/crops/cassitine.md) | [Malaxia](/crops/malaxia.md) + [Marble Lily](/crops/marblelily.md) |
| [Clay Lily](/crops/claylily.md) | [Waterlily](/crops/waterlily.md) |
| [Copper Ore Berry](/crops/copperoreberry.md) | [Malaxia](/crops/malaxia.md) + [BoP Berry](/crops/bopberry.md) |
| [Coppon](/crops/coppon.md) | [Nether Stone Lily](/crops/netherstonelily.md) |
| [Diorite Lily](/crops/dioritelily.md) | [Marble Lily](/crops/marblelily.md) |
| [End Stone Lily](/crops/endstonelily.md) | [Enderbloom](/crops/enderbloom.md) |
| [Ferrofern](/crops/ferrofern.md) | [Black Granite Lily](/crops/blackgranitelily.md) |
| [Iron Ore Berry](/crops/ironoreberry.md) | [Tin Ore Berry](/crops/tinoreberry.md) |
| [Lazulia](/crops/lazulia.md) | [Indigo](/crops/indigo.md) |
| [Malaxia](/crops/malaxia.md) | [Orange Tulip](/crops/orangetulip.md) + [Pumpkin](/crops/pumpkin.md) |
| [Marble Lily](/crops/marblelily.md) | [Oxeye Daisy](/crops/oxeyedaisy.md) |
| [Nether Stone Lily](/crops/netherstonelily.md) | [Nether Wart](/crops/netherwart.md) |
| [Red Granite Lily](/crops/redgranitelily.md) | [Poppy](/crops/poppy.md) |
| [Sand Lily](/crops/sandlily.md) | [Cactus](/crops/cactus.md) |
| [Tin Ore Berry](/crops/tinoreberry.md) | [Cassitine](/crops/cassitine.md) + [BoP Berry](/crops/bopberry.md) |
| [Tine](/crops/tine.md) | [Bonsai Spruce](/crops/bonsaispruce.md) |
| [Void Ore Berry](/crops/voidoreberry.md) | [Thaumium Ore Berry](/crops/thaumiumoreberry.md) + [Gold Ore Berry](/crops/goldoreberry.md) |


