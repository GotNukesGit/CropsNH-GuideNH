---
item_id: 'cropsnh:genericSeed:0:{crop:"cropsnh:reactoria"}'
categories:
  - crops
  - tier-12
navigation:
  icon: 'cropsnh:genericSeed:0:{crop:"cropsnh:reactoria"}'
  title: Reactoria
  parent: /crops.md
  position: 8
  keywords:
    - Reactoria
    - Reactoria
---

# Reactoria

> [!NOTE]
> **Machine-only.** Produced by a machine process, not by breeding on crop sticks.

> [!WARNING]
> **Buried block required.** This crop needs a `uranium` block two spaces below the cross-crop stick (directly under the soil). Without it the crop won't grow — see the setup scene below.

**Tier:** 12  
**Soil:** [Stone](/mechanics/soil-and-blocks.md) — Stone, Cobblestone, Stone Brick, Mossy Cobble + Chisel variants  
**Block under soil:** `uranium`  
**Likes biomes:** COLD, HOT  
**Alternate seed:** no  

Crop Synthesizer only. Requires uranium block y-2. ZPM+ machine tier.

## Breeding setup

Full breeding setup — a cross-crop stick in the center on Stone over a **uranium** block, with the parents planted in a line through it (**Titania** (north), **God of Thunder** (south)):

<GameScene zoom={4} interactive={true}>
  <Block id="gregtech:gt.blockmetal7" meta="14" x="0" y="0" z="0" />
  <Block id="minecraft:stone" x="0" y="1" z="0" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crossCrop:1b}' x="0" y="2" z="0" />
  <Block id="gregtech:gt.blockmetal7" meta="9" x="0" y="0" z="-1" />
  <Block id="minecraft:stone" x="0" y="1" z="-1" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crop:{crop:"cropsnh:titania",amount:1,gr:1b,ga:1b,re:1b,scan:1b},progress:1000}' x="0" y="2" z="-1" />
  <Block id="gregtech:gt.blockmetal7" meta="5" x="0" y="0" z="1" />
  <Block id="minecraft:stone" x="0" y="1" z="1" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crop:{crop:"cropsnh:godOfThunder",amount:1,gr:1b,ga:1b,re:1b,scan:1b},progress:1000}' x="0" y="2" z="1" />
  <BlockAnnotation pos="0 2 0" color="#80FFAA00" thickness="2" alwaysOnTop={true}>Reactoria — cross-crop (result grows here)</BlockAnnotation>
  <BlockAnnotation pos="0 2 -1" color="#8044DD66" thickness="2" alwaysOnTop={true}>Titania (parent)</BlockAnnotation>
  <BlockAnnotation pos="0 2 1" color="#8044DD66" thickness="2" alwaysOnTop={true}>God of Thunder (parent)</BlockAnnotation>
</GameScene>

## How to obtain

Bred from:

| Parents | Result pools | Notes |
|---------|--------------|-------|
| [Titania](/crops/titania.md) + [God of Thunder](/crops/godofthunder.md) | — | machine recipe |

Exact per-tick chance depends on soil and the parents' shared pools — check the [web calculator](https://crops-nh.netlify.app/calculator.html).


