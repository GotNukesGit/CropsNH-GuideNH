---
item_id: 'cropsnh:genericSeed:0:{crop:"cropsnh:stargatium"}'
categories:
  - crops
  - tier-12
navigation:
  icon: 'cropsnh:genericSeed:0:{crop:"cropsnh:stargatium"}'
  title: Stargatium
  parent: /crops.md
  position: 8
  keywords:
    - Stargatium
    - Stargatium
---

# Stargatium

> [!NOTE]
> **Machine-only.** Produced by a machine process, not by breeding on crop sticks.

> [!WARNING]
> **Buried block required.** This crop needs a `naquadah` block two spaces below the cross-crop stick (directly under the soil). Without it the crop won't grow — see the setup scene below.

**Tier:** 12  
**Soil:** [Stone](/mechanics/soil-and-blocks.md) — Stone, Cobblestone, Stone Brick, Mossy Cobble + Chisel variants  
**Block under soil:** `naquadah`  
**Likes biomes:** LUSH, WASTELAND  
**Alternate seed:** no  

Crop Synthesizer only. Requires end stone y-2 (naquadah). UV+ machine tier.

## Breeding setup

Full breeding setup — a cross-crop stick in the center on Stone over a **naquadah** block, with the parents planted in a line through it (**Iridine** (north), **Trollplant** (south)):

<GameScene zoom={4} interactive={true}>
  <Block id="gregtech:gt.blockmetal4" meta="12" x="0" y="0" z="0" />
  <Block id="minecraft:stone" x="0" y="1" z="0" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crossCrop:1b}' x="0" y="2" z="0" />
  <Block id="gregtech:gt.blockmetal3" meta="12" x="0" y="0" z="-1" />
  <Block id="minecraft:stone" x="0" y="1" z="-1" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crop:{crop:"cropsnh:iridine",amount:1,gr:1b,ga:1b,re:1b,scan:1b},progress:1000}' x="0" y="2" z="-1" />
  <Block id="minecraft:brick_block" x="0" y="0" z="1" />
  <Block id="minecraft:brick_block" x="0" y="1" z="1" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crop:{crop:"cropsnh:trollplant",amount:1,gr:1b,ga:1b,re:1b,scan:1b},progress:1000}' x="0" y="2" z="1" />
  <BlockAnnotation pos="0 2 0" color="#80FFAA00" thickness="2" alwaysOnTop={true}>Stargatium — cross-crop (result grows here)</BlockAnnotation>
  <BlockAnnotation pos="0 2 -1" color="#8044DD66" thickness="2" alwaysOnTop={true}>Iridine (parent)</BlockAnnotation>
  <BlockAnnotation pos="0 2 1" color="#8044DD66" thickness="2" alwaysOnTop={true}>Trollplant (parent)</BlockAnnotation>
</GameScene>

## How to obtain

Bred from:

| Parents | Result pools | Notes |
|---------|--------------|-------|
| [Iridine](/crops/iridine.md) + [Trollplant](/crops/trollplant.md) | `STONE` | machine recipe |

Exact per-tick chance depends on soil and the parents' shared pools — check the [web calculator](https://crops-nh.netlify.app/calculator.html).


