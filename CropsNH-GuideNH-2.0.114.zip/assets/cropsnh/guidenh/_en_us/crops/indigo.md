---
item_id: 'cropsnh:genericSeed:0:{crop:"cropsnh:indigo"}'
categories:
  - crops
  - tier-2
navigation:
  icon: 'cropsnh:genericSeed:0:{crop:"cropsnh:indigo"}'
  title: Indigo
  parent: /crops.md
  position: 18
  keywords:
    - Indigo
    - Indigo
---

# Indigo

**Tier:** 2  
**Soil:** [Dirt / Grass](/mechanics/soil-and-blocks.md) — Dirt, Grass, Mycelium variants  
**Likes biomes:** WET, LUSH  
**Alternate seed:** yes — plantable without breeding  
**Pools:** `BLUE`, `FLOWER`  

## Breeding setup

Full breeding setup — a cross-crop stick in the center on Dirt / Grass, with the parents planted in a line through it (**Dayflower** (north), **Blue Orchid** (south)):

<GameScene zoom={4} interactive={true}>
  <Block id="minecraft:dirt" x="0" y="0" z="0" />
  <Block id="minecraft:dirt" x="0" y="1" z="0" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crossCrop:1b}' x="0" y="2" z="0" />
  <Block id="minecraft:dirt" x="0" y="0" z="-1" />
  <Block id="minecraft:dirt" x="0" y="1" z="-1" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crop:{crop:"cropsnh:dayflower",amount:1,gr:1b,ga:1b,re:1b,scan:1b},progress:1000}' x="0" y="2" z="-1" />
  <Block id="minecraft:dirt" x="0" y="0" z="1" />
  <Block id="minecraft:dirt" x="0" y="1" z="1" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crop:{crop:"cropsnh:blueOrchid",amount:1,gr:1b,ga:1b,re:1b,scan:1b},progress:1000}' x="0" y="2" z="1" />
  <BlockAnnotation pos="0 2 0" color="#80FFAA00" thickness="2" alwaysOnTop={true}>Indigo — cross-crop (result grows here)</BlockAnnotation>
  <BlockAnnotation pos="0 2 -1" color="#8044DD66" thickness="2" alwaysOnTop={true}>Dayflower (parent)</BlockAnnotation>
  <BlockAnnotation pos="0 2 1" color="#8044DD66" thickness="2" alwaysOnTop={true}>Blue Orchid (parent)</BlockAnnotation>
</GameScene>

## How to obtain

Bred from:

| Parents | Result pools | Notes |
|---------|--------------|-------|
| [Dayflower](/crops/dayflower.md) + [Blue Orchid](/crops/blueorchid.md) | `BLUE`, `FLOWER` | crop-stick cross |

Exact per-tick chance depends on soil and the parents' shared pools — check the [web calculator](https://crops-nh.netlify.app/calculator.html).

## Used to breed

Indigo is a parent in these mutations:

| Produces | With |
|----------|------|
| [Lazulia](/crops/lazulia.md) | [Stone Lily](/crops/stonelily.md) |


