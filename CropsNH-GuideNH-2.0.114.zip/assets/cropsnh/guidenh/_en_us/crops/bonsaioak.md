---
item_id: 'cropsnh:genericSeed:0:{crop:"cropsnh:bonsaiOak"}'
categories:
  - crops
  - tier-1
navigation:
  icon: 'cropsnh:genericSeed:0:{crop:"cropsnh:bonsaiOak"}'
  title: Bonsai Oak
  parent: /crops.md
  position: 19
  keywords:
    - Bonsai Oak
    - BonsaiOak
---

# Bonsai Oak

**Tier:** 1  
**Soil:** [Dirt / Grass](/mechanics/soil-and-blocks.md) — Dirt, Grass, Mycelium variants  
**Likes biomes:** FOREST, HILLS, PLAINS  
**Alternate seed:** no  
**Pools:** `BROWN`, `EDIBLE`, `LEAFY`, `TREE`, `WOODEN`  

## Breeding setup

Full breeding setup — a cross-crop stick in the center on Dirt / Grass, with the parents planted in a line through it (**Wheat** (north), **Brown Mushroom** (south)):

<GameScene zoom={4} interactive={true}>
  <Block id="minecraft:dirt" x="0" y="0" z="0" />
  <Block id="minecraft:dirt" x="0" y="1" z="0" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crossCrop:1b}' x="0" y="2" z="0" />
  <Block id="minecraft:dirt" x="0" y="0" z="-1" />
  <Block id="minecraft:farmland" x="0" y="1" z="-1" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crop:{crop:"cropsnh:wheat",amount:1,gr:1b,ga:1b,re:1b,scan:1b},progress:1000}' x="0" y="2" z="-1" />
  <Block id="minecraft:stone" x="0" y="0" z="1" />
  <Block id="minecraft:stone" x="0" y="1" z="1" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crop:{crop:"cropsnh:brownMushroom",amount:1,gr:1b,ga:1b,re:1b,scan:1b},progress:1000}' x="0" y="2" z="1" />
  <BlockAnnotation pos="0 2 0" color="#80FFAA00" thickness="2" alwaysOnTop={true}>Bonsai Oak — cross-crop (result grows here)</BlockAnnotation>
  <BlockAnnotation pos="0 2 -1" color="#8044DD66" thickness="2" alwaysOnTop={true}>Wheat (parent)</BlockAnnotation>
  <BlockAnnotation pos="0 2 1" color="#8044DD66" thickness="2" alwaysOnTop={true}>Brown Mushroom (parent)</BlockAnnotation>
</GameScene>

## How to obtain

Bred from:

| Parents | Result pools | Notes |
|---------|--------------|-------|
| [Wheat](/crops/wheat.md) + [Brown Mushroom](/crops/brownmushroom.md) | `BROWN`, `EDIBLE`, `LEAFY`, `TREE`, `WOODEN` | crop-stick cross |

Exact per-tick chance depends on soil and the parents' shared pools — check the [web calculator](https://crops-nh.netlify.app/calculator.html).

## Used to breed

Bonsai Oak is a parent in these mutations:

| Produces | With |
|----------|------|
| [Blueberry](/crops/blueberry.md) | [Azure Bluet](/crops/azurebluet.md) |
| [Bonsai Acacia](/crops/bonsaiacacia.md) | [Cactus](/crops/cactus.md) |
| [Bonsai Birch](/crops/bonsaibirch.md) | [Sugar Cane](/crops/sugarcane.md) |
| [Bonsai Dark Oak](/crops/bonsaidarkoak.md) | [Bonsai Spruce](/crops/bonsaispruce.md) |
| [Bonsai Jungle](/crops/bonsaijungle.md) | [Vine](/crops/vine.md) |
| [Bonsai Spruce](/crops/bonsaispruce.md) | [Pumpkin](/crops/pumpkin.md) |
| [Lemon](/crops/lemon.md) | [Bonsai Acacia](/crops/bonsaiacacia.md) |


