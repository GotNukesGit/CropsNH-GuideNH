---
item_id: 'cropsnh:genericSeed:0:{crop:"cropsnh:tearstalks"}'
categories:
  - crops
  - tier-8
navigation:
  icon: 'cropsnh:genericSeed:0:{crop:"cropsnh:tearstalks"}'
  title: Tearstalks
  parent: /crops.md
  position: 12
  keywords:
    - Tearstalks
    - Tearstalks
---

# Tearstalks

**Tier:** 8  
**Soil:** [Farmland](/mechanics/soil-and-blocks.md) — Farmland, Enchanted Earth, Ztones Garden Soil, Fertilized Dirt  
**Likes biomes:** NETHER, DEAD  
**Alternate seed:** no  
**Pools:** `EVIL`, `HEALING`, `NETHER`, `POTION_INGREDIENT`, `STEM`, `WHITE`  

## Breeding setup

Full breeding setup — a cross-crop stick in the center on Farmland, with the parents planted around it (**Goldfish** (north), **Soul Sand Lily** (south), **Nether Stone Lily** (east)):

<GameScene zoom={4} interactive={true}>
  <Block id="minecraft:dirt" x="0" y="0" z="0" />
  <Block id="minecraft:farmland" x="0" y="1" z="0" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crossCrop:1b}' x="0" y="2" z="0" />
  <Block id="minecraft:dirt" x="0" y="0" z="-1" />
  <Block id="minecraft:farmland" x="0" y="1" z="-1" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crop:{crop:"cropsnh:goldfish",amount:1,gr:1b,ga:1b,re:1b,scan:1b},progress:1000}' x="0" y="2" z="-1" />
  <Block id="minecraft:soul_sand" x="0" y="0" z="1" />
  <Block id="minecraft:stone" x="0" y="1" z="1" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crop:{crop:"cropsnh:soulSandLily",amount:1,gr:1b,ga:1b,re:1b,scan:1b},progress:1000}' x="0" y="2" z="1" />
  <Block id="minecraft:netherrack" x="1" y="0" z="0" />
  <Block id="minecraft:stone" x="1" y="1" z="0" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crop:{crop:"cropsnh:netherStoneLily",amount:1,gr:1b,ga:1b,re:1b,scan:1b},progress:1000}' x="1" y="2" z="0" />
  <BlockAnnotation pos="0 2 0" color="#80FFAA00" thickness="2" alwaysOnTop={true}>Tearstalks — cross-crop (result grows here)</BlockAnnotation>
  <BlockAnnotation pos="0 2 -1" color="#8044DD66" thickness="2" alwaysOnTop={true}>Goldfish (parent)</BlockAnnotation>
  <BlockAnnotation pos="0 2 1" color="#8044DD66" thickness="2" alwaysOnTop={true}>Soul Sand Lily (parent)</BlockAnnotation>
  <BlockAnnotation pos="1 2 0" color="#8044DD66" thickness="2" alwaysOnTop={true}>Nether Stone Lily (parent)</BlockAnnotation>
</GameScene>

## How to obtain

Bred from:

| Parents | Result pools | Notes |
|---------|--------------|-------|
| [Goldfish](/crops/goldfish.md) + [Soul Sand Lily](/crops/soulsandlily.md) + [Nether Stone Lily](/crops/netherstonelily.md) | `EVIL`, `HEALING`, `NETHER`, `POTION_INGREDIENT`, `STEM`, `WHITE` | crop-stick cross |

Exact per-tick chance depends on soil and the parents' shared pools — check the [web calculator](https://crops-nh.netlify.app/calculator.html).

## Used to breed

Tearstalks is a parent in these mutations:

| Produces | With |
|----------|------|
| [Essence Ore Berry](/crops/essenceoreberry.md) | [Creeperweed](/crops/creeperweed.md) + [Zomplant](/crops/zomplant.md) + [Spidernip](/crops/spidernip.md) |


