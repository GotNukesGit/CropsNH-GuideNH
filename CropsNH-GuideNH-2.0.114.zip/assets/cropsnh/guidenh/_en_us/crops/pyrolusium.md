---
item_id: 'cropsnh:genericSeed:0:{crop:"cropsnh:pyrolusium"}'
categories:
  - crops
  - tier-12
navigation:
  icon: 'cropsnh:genericSeed:0:{crop:"cropsnh:pyrolusium"}'
  title: Pyrolusium
  parent: /crops.md
  position: 8
  keywords:
    - Pyrolusium
    - Pyrolusium
---

# Pyrolusium

> [!WARNING]
> **Buried block required.** This crop needs a `manganese` block two spaces below the cross-crop stick (directly under the soil). Without it the crop won't grow — see the setup scene below.

**Tier:** 12  
**Soil:** [Stone](/mechanics/soil-and-blocks.md) — Stone, Cobblestone, Stone Brick, Mossy Cobble + Chisel variants  
**Block under soil:** `manganese`  
**Likes biomes:** NETHER, HOT  
**Alternate seed:** no  
**Pools:** `BUSH`, `METALLIC`  

## Breeding setup

Full breeding setup — a cross-crop stick in the center on Stone over a **manganese** block, with the parents planted in a line through it (**Nickelback** (north), **Bauxia** (south)):

<GameScene zoom={4} interactive={true}>
  <Block id="gregtech:gt.blockmetal4" meta="6" x="0" y="0" z="0" />
  <Block id="minecraft:stone" x="0" y="1" z="0" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crossCrop:1b}' x="0" y="2" z="0" />
  <Block id="gregtech:gt.blockmetal5" meta="4" x="0" y="0" z="-1" />
  <Block id="minecraft:stone" x="0" y="1" z="-1" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crop:{crop:"cropsnh:nickelback",amount:1,gr:1b,ga:1b,re:1b,scan:1b},progress:1000}' x="0" y="2" z="-1" />
  <Block id="gregtech:gt.blockmetal1" meta="1" x="0" y="0" z="1" />
  <Block id="minecraft:stone" x="0" y="1" z="1" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crop:{crop:"cropsnh:bauxia",amount:1,gr:1b,ga:1b,re:1b,scan:1b},progress:1000}' x="0" y="2" z="1" />
  <BlockAnnotation pos="0 2 0" color="#80FFAA00" thickness="2" alwaysOnTop={true}>Pyrolusium — cross-crop (result grows here)</BlockAnnotation>
  <BlockAnnotation pos="0 2 -1" color="#8044DD66" thickness="2" alwaysOnTop={true}>Nickelback (parent)</BlockAnnotation>
  <BlockAnnotation pos="0 2 1" color="#8044DD66" thickness="2" alwaysOnTop={true}>Bauxia (parent)</BlockAnnotation>
</GameScene>

## How to obtain

Bred from:

| Parents | Result pools | Notes |
|---------|--------------|-------|
| [Nickelback](/crops/nickelback.md) + [Bauxia](/crops/bauxia.md) | `BUSH`, `METALLIC` | crop-stick cross |

Exact per-tick chance depends on soil and the parents' shared pools — check the [web calculator](https://crops-nh.netlify.app/calculator.html).

## Used to breed

Pyrolusium is a parent in these mutations:

| Produces | With |
|----------|------|
| [Scheelinium](/crops/scheelinium.md) | [Titania](/crops/titania.md) + [End Stone Lily](/crops/endstonelily.md) |


