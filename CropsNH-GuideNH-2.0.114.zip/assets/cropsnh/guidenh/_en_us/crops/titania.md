---
item_id: 'cropsnh:genericSeed:0:{crop:"cropsnh:titania"}'
categories:
  - crops
  - tier-9
navigation:
  icon: 'cropsnh:genericSeed:0:{crop:"cropsnh:titania"}'
  title: Titania
  parent: /crops.md
  position: 11
  keywords:
    - Titania
    - Titania
---

# Titania

> [!NOTE]
> **Machine-only.** Produced by a machine process, not by breeding on crop sticks.

> [!WARNING]
> **Buried block required.** This crop needs a `titanium` block two spaces below the cross-crop stick (directly under the soil). Without it the crop won't grow — see the setup scene below.

**Tier:** 9  
**Soil:** [Stone](/mechanics/soil-and-blocks.md) — Stone, Cobblestone, Stone Brick, Mossy Cobble + Chisel variants  
**Block under soil:** `titanium`  
**Likes biomes:** HOT, SAVANNA  
**Alternate seed:** no  

Crop Synthesizer only. Requires titanium block y-2. EV+ machine tier.

## Breeding setup

Full breeding setup — a cross-crop stick in the center on Stone over a **titanium** block, with the parents planted in a line through it (**Bauxia** (north), **Red Straw** (south)):

<GameScene zoom={4} interactive={true}>
  <Block id="gregtech:gt.blockmetal7" meta="9" x="0" y="0" z="0" />
  <Block id="minecraft:stone" x="0" y="1" z="0" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crossCrop:1b}' x="0" y="2" z="0" />
  <Block id="gregtech:gt.blockmetal1" meta="1" x="0" y="0" z="-1" />
  <Block id="minecraft:stone" x="0" y="1" z="-1" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crop:{crop:"cropsnh:bauxia",amount:1,gr:1b,ga:1b,re:1b,scan:1b},progress:1000}' x="0" y="2" z="-1" />
  <Block id="minecraft:redstone_block" x="0" y="0" z="1" />
  <Block id="minecraft:farmland" x="0" y="1" z="1" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crop:{crop:"cropsnh:redstraw",amount:1,gr:1b,ga:1b,re:1b,scan:1b},progress:1000}' x="0" y="2" z="1" />
  <BlockAnnotation pos="0 2 0" color="#80FFAA00" thickness="2" alwaysOnTop={true}>Titania — cross-crop (result grows here)</BlockAnnotation>
  <BlockAnnotation pos="0 2 -1" color="#8044DD66" thickness="2" alwaysOnTop={true}>Bauxia (parent)</BlockAnnotation>
  <BlockAnnotation pos="0 2 1" color="#8044DD66" thickness="2" alwaysOnTop={true}>Red Straw (parent)</BlockAnnotation>
</GameScene>

## How to obtain

Bred from:

| Parents | Result pools | Notes |
|---------|--------------|-------|
| [Bauxia](/crops/bauxia.md) + [Red Straw](/crops/redstraw.md) | `STONE` | machine recipe |

Exact per-tick chance depends on soil and the parents' shared pools — check the [web calculator](https://crops-nh.netlify.app/calculator.html).

## Used to breed

Titania is a parent in these mutations:

| Produces | With |
|----------|------|
| [Reactoria](/crops/reactoria.md) | [God of Thunder](/crops/godofthunder.md) |
| [Scheelinium](/crops/scheelinium.md) | [Pyrolusium](/crops/pyrolusium.md) + [End Stone Lily](/crops/endstonelily.md) |
| [Space FlowerS](/crops/spaceflower.md) | [End Stone Lily](/crops/endstonelily.md) |
| [Star Wart](/crops/starwart.md) | [Withereed](/crops/withereed.md) + [God of Thunder](/crops/godofthunder.md) |
| [Transformium](/crops/transformium.md) | [Trollplant](/crops/trollplant.md) + [Bauxia](/crops/bauxia.md) |


