---
item_id: 'cropsnh:genericSeed:0:{crop:"cropsnh:carrot"}'
categories:
  - crops
  - tier-2
navigation:
  icon: 'cropsnh:genericSeed:0:{crop:"cropsnh:carrot"}'
  title: Carrot
  parent: /crops.md
  position: 18
  keywords:
    - Carrot
    - Carrot
---

# Carrot

> [!NOTE]
> **Directly obtainable.** No breeding recipe — plant it from a seed you can get by other means.

**Tier:** 2  
**Soil:** [Farmland](/mechanics/soil-and-blocks.md) — Farmland, Enchanted Earth, Ztones Garden Soil, Fertilized Dirt  
**Likes biomes:** PLAINS, HOT, SANDY  
**Alternate seed:** yes — plantable without breeding  
**Pools:** `EDIBLE`, `ORANGE`, `POTION_INGREDIENT`, `ROOT`  

## Setup

Grow **Carrot** on Farmland:

<GameScene zoom={4} interactive={true}>
  <Block id="minecraft:dirt" x="0" y="0" z="0" />
  <Block id="minecraft:farmland" x="0" y="1" z="0" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crop:{crop:"cropsnh:carrot",amount:1,gr:1b,ga:1b,re:1b,scan:1b},progress:1000}' x="0" y="2" z="0" />
  <BlockAnnotation pos="0 2 0" color="#8044DD66" thickness="2" alwaysOnTop={true}>Carrot</BlockAnnotation>
</GameScene>

## How to obtain

No breeding recipe — obtain the seed directly.

## Used to breed

Carrot is a parent in these mutations:

| Produces | With |
|----------|------|
| [Cucumber](/crops/cucumber.md) | [Melon](/crops/melon.md) |
| [Mandrake](/crops/mandrake.md) | [Belladonna](/crops/belladonna.md) |
| [Onion](/crops/onion.md) | [Allium](/crops/allium.md) |
| [Pumpkin](/crops/pumpkin.md) | [Sugar Cane](/crops/sugarcane.md) |
| [Sugar Cane](/crops/sugarcane.md) | [Potato](/crops/potato.md) |
| [Wild Carrot](/crops/wildcarrot.md) | [BoP Berry](/crops/bopberry.md) |


