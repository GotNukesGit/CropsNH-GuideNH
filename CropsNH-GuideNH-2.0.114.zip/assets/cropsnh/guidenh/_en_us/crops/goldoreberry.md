---
item_id: 'cropsnh:genericSeed:0:{crop:"cropsnh:goldOreBerry"}'
categories:
  - crops
  - tier-5
navigation:
  icon: 'cropsnh:genericSeed:0:{crop:"cropsnh:goldOreBerry"}'
  title: Gold Ore Berry
  parent: /crops.md
  position: 15
  keywords:
    - Gold Ore Berry
    - GoldOreBerry
---

# Gold Ore Berry

> [!WARNING]
> **Buried block required.** This crop needs a `gold` block two spaces below the cross-crop stick (directly under the soil). Without it the crop won't grow — see the setup scene below.

**Tier:** 5  
**Soil:** [Stone](/mechanics/soil-and-blocks.md) — Stone, Cobblestone, Stone Brick, Mossy Cobble + Chisel variants  
**Block under soil:** `gold`  
**Likes biomes:** MESA, SANDY  
**Alternate seed:** yes — plantable without breeding  
**Pools:** `DANGEROUS`, `DENSE`, `GOLD`, `METALLIC`, `ORE_BERRY`, `YELLOW`  

TiC req

## Breeding setup

Full breeding setup — a cross-crop stick in the center on Stone over a **gold** block, with the parents planted around it (**Copper Ore Berry** (north), **Iron Ore Berry** (south), **Tin Ore Berry** (east)):

<GameScene zoom={4} interactive={true}>
  <Block id="minecraft:gold_block" x="0" y="0" z="0" />
  <Block id="minecraft:stone" x="0" y="1" z="0" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crossCrop:1b}' x="0" y="2" z="0" />
  <Block id="gregtech:gt.blockmetal2" meta="7" x="0" y="0" z="-1" />
  <Block id="minecraft:stone" x="0" y="1" z="-1" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crop:{crop:"cropsnh:copperOreBerry",amount:1,gr:1b,ga:1b,re:1b,scan:1b},progress:1000}' x="0" y="2" z="-1" />
  <Block id="minecraft:iron_block" x="0" y="0" z="1" />
  <Block id="minecraft:stone" x="0" y="1" z="1" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crop:{crop:"cropsnh:ironOreBerry",amount:1,gr:1b,ga:1b,re:1b,scan:1b},progress:1000}' x="0" y="2" z="1" />
  <Block id="gregtech:gt.blockmetal7" meta="7" x="1" y="0" z="0" />
  <Block id="minecraft:stone" x="1" y="1" z="0" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crop:{crop:"cropsnh:tinOreBerry",amount:1,gr:1b,ga:1b,re:1b,scan:1b},progress:1000}' x="1" y="2" z="0" />
  <BlockAnnotation pos="0 2 0" color="#80FFAA00" thickness="2" alwaysOnTop={true}>Gold Ore Berry — cross-crop (result grows here)</BlockAnnotation>
  <BlockAnnotation pos="0 2 -1" color="#8044DD66" thickness="2" alwaysOnTop={true}>Copper Ore Berry (parent)</BlockAnnotation>
  <BlockAnnotation pos="0 2 1" color="#8044DD66" thickness="2" alwaysOnTop={true}>Iron Ore Berry (parent)</BlockAnnotation>
  <BlockAnnotation pos="1 2 0" color="#8044DD66" thickness="2" alwaysOnTop={true}>Tin Ore Berry (parent)</BlockAnnotation>
</GameScene>

## How to obtain

Bred from:

| Parents | Result pools | Notes |
|---------|--------------|-------|
| [Copper Ore Berry](/crops/copperoreberry.md) + [Iron Ore Berry](/crops/ironoreberry.md) + [Tin Ore Berry](/crops/tinoreberry.md) | `DANGEROUS`, `DENSE`, `GOLD`, `METALLIC`, `ORE_BERRY`, `YELLOW` | crop-stick cross |

Exact per-tick chance depends on soil and the parents' shared pools — check the [web calculator](https://crops-nh.netlify.app/calculator.html).

## Used to breed

Gold Ore Berry is a parent in these mutations:

| Produces | With |
|----------|------|
| [Aluminium Ore Berry](/crops/aluminiumoreberry.md) | [Essence Ore Berry](/crops/essenceoreberry.md) |
| [Cobalt Ore Berry](/crops/cobaltoreberry.md) | [Nether Stone Lily](/crops/netherstonelily.md) + [Ardite Ore Berry](/crops/arditeoreberry.md) + [Lazulia](/crops/lazulia.md) |
| [Void Ore Berry](/crops/voidoreberry.md) | [Thaumium Ore Berry](/crops/thaumiumoreberry.md) + [Stone Lily](/crops/stonelily.md) |


