---
item_id: 'cropsnh:genericSeed:0:{crop:"cropsnh:cinderpearl"}'
categories:
  - crops
  - tier-5
navigation:
  icon: 'cropsnh:genericSeed:0:{crop:"cropsnh:cinderpearl"}'
  title: Cinderpearl
  parent: /crops.md
  position: 15
  keywords:
    - Cinderpearl
    - Cinderpearl
---

# Cinderpearl

> [!WARNING]
> **Buried block required.** This crop needs a `blaze` block two spaces below the cross-crop stick (directly under the soil). Without it the crop won't grow — see the setup scene below.

**Tier:** 5  
**Soil:** [Dirt / Grass](/mechanics/soil-and-blocks.md) — Dirt, Grass, Mycelium variants  
**Block under soil:** `blaze`  
**Likes biomes:** HOT, DRY, MAGICAL  
**Alternate seed:** yes — plantable without breeding  
**Pools:** `BLAZE`, `MAGICAL`, `ORANGE`  

TC req

## Breeding setup

Full breeding setup — a cross-crop stick in the center on Dirt / Grass over a **blaze** block, with the parents planted in a line through it (**Ember Moss** (north), **Glint Weed** (south)):

<GameScene zoom={4} interactive={true}>
  <Block id="gregtech:gt.blockgem3" meta="5" x="0" y="0" z="0" />
  <Block id="minecraft:dirt" x="0" y="1" z="0" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crossCrop:1b}' x="0" y="2" z="0" />
  <Block id="minecraft:dirt" x="0" y="0" z="-1" />
  <Block id="minecraft:farmland" x="0" y="1" z="-1" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crop:{crop:"cropsnh:emberMoss",amount:1,gr:1b,ga:1b,re:1b,scan:1b},progress:1000}' x="0" y="2" z="-1" />
  <Block id="minecraft:dirt" x="0" y="0" z="1" />
  <Block id="minecraft:farmland" x="0" y="1" z="1" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crop:{crop:"cropsnh:glintWeed",amount:1,gr:1b,ga:1b,re:1b,scan:1b},progress:1000}' x="0" y="2" z="1" />
  <BlockAnnotation pos="0 2 0" color="#80FFAA00" thickness="2" alwaysOnTop={true}>Cinderpearl — cross-crop (result grows here)</BlockAnnotation>
  <BlockAnnotation pos="0 2 -1" color="#8044DD66" thickness="2" alwaysOnTop={true}>Ember Moss (parent)</BlockAnnotation>
  <BlockAnnotation pos="0 2 1" color="#8044DD66" thickness="2" alwaysOnTop={true}>Glint Weed (parent)</BlockAnnotation>
</GameScene>

## How to obtain

Bred from:

| Parents | Result pools | Notes |
|---------|--------------|-------|
| [Ember Moss](/crops/embermoss.md) + [Glint Weed](/crops/glintweed.md) | `BLAZE`, `MAGICAL`, `ORANGE` | crop-stick cross |

Exact per-tick chance depends on soil and the parents' shared pools — check the [web calculator](https://crops-nh.netlify.app/calculator.html).

## Used to breed

Cinderpearl is a parent in these mutations:

| Produces | With |
|----------|------|
| [Blazereed](/crops/blazereed.md) | [Sugar Cane](/crops/sugarcane.md) |
| [Mana Bean](/crops/manabean.md) | [Cocoa](/crops/cocoa.md) + [Shimmerleaf](/crops/shimmerleaf.md) |
| [Magical Nightshade](/crops/magicalnightshade.md) | [Primordial Berry](/crops/primordialberry.md) + [Mana Bean](/crops/manabean.md) + [Shimmerleaf](/crops/shimmerleaf.md) |


