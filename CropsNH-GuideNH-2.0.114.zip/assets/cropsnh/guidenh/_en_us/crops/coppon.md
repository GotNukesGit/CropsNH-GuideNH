---
item_id: 'cropsnh:genericSeed:0:{crop:"cropsnh:coppon"}'
categories:
  - crops
  - tier-6
navigation:
  icon: 'cropsnh:genericSeed:0:{crop:"cropsnh:coppon"}'
  title: Coppon
  parent: /crops.md
  position: 14
  keywords:
    - Coppon
    - Coppon
---

# Coppon

> [!WARNING]
> **Buried block required.** This crop needs a `copper` block two spaces below the cross-crop stick (directly under the soil). Without it the crop won't grow — see the setup scene below.

**Tier:** 6  
**Soil:** [Stone](/mechanics/soil-and-blocks.md) — Stone, Cobblestone, Stone Brick, Mossy Cobble + Chisel variants  
**Block under soil:** `copper`  
**Likes biomes:** SAVANNA, HOT, SANDY  
**Alternate seed:** no  
**Pools:** `BUSH`, `COPPER`, `COTTON`, `METALLIC`, `ORANGE`, `SHINY`  

## Breeding setup

Full breeding setup — a cross-crop stick in the center on Stone over a **copper** block, with the parents planted in a line through it (**Stone Lily** (north), **Nether Stone Lily** (south)):

<GameScene zoom={4} interactive={true}>
  <Block id="gregtech:gt.blockmetal2" meta="7" x="0" y="0" z="0" />
  <Block id="minecraft:stone" x="0" y="1" z="0" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crossCrop:1b}' x="0" y="2" z="0" />
  <Block id="minecraft:stone" x="0" y="0" z="-1" />
  <Block id="minecraft:stone" x="0" y="1" z="-1" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crop:{crop:"cropsnh:stoneLily",amount:1,gr:1b,ga:1b,re:1b,scan:1b},progress:1000}' x="0" y="2" z="-1" />
  <Block id="minecraft:netherrack" x="0" y="0" z="1" />
  <Block id="minecraft:stone" x="0" y="1" z="1" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crop:{crop:"cropsnh:netherStoneLily",amount:1,gr:1b,ga:1b,re:1b,scan:1b},progress:1000}' x="0" y="2" z="1" />
  <BlockAnnotation pos="0 2 0" color="#80FFAA00" thickness="2" alwaysOnTop={true}>Coppon — cross-crop (result grows here)</BlockAnnotation>
  <BlockAnnotation pos="0 2 -1" color="#8044DD66" thickness="2" alwaysOnTop={true}>Stone Lily (parent)</BlockAnnotation>
  <BlockAnnotation pos="0 2 1" color="#8044DD66" thickness="2" alwaysOnTop={true}>Nether Stone Lily (parent)</BlockAnnotation>
</GameScene>

## How to obtain

Bred from:

| Parents | Result pools | Notes |
|---------|--------------|-------|
| [Stone Lily](/crops/stonelily.md) + [Nether Stone Lily](/crops/netherstonelily.md) | `BUSH`, `COPPER`, `COTTON`, `METALLIC`, `ORANGE`, `SHINY` | crop-stick cross |

Exact per-tick chance depends on soil and the parents' shared pools — check the [web calculator](https://crops-nh.netlify.app/calculator.html).

## Used to breed

Coppon is a parent in these mutations:

| Produces | With |
|----------|------|
| [Ardite Ore Berry](/crops/arditeoreberry.md) | [Nether Stone Lily](/crops/netherstonelily.md) + [Copper Ore Berry](/crops/copperoreberry.md) + [Malaxia](/crops/malaxia.md) |
| [Auronia](/crops/auronia.md) | [Plumbilia](/crops/plumbilia.md) |
| [Nickelback](/crops/nickelback.md) | [Ferrofern](/crops/ferrofern.md) |
| [Plumbilia](/crops/plumbilia.md) | [Withereed](/crops/withereed.md) |


