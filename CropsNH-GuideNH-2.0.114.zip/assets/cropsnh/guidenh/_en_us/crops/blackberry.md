---
item_id: 'cropsnh:genericSeed:0:{crop:"cropsnh:blackberry"}'
categories:
  - crops
  - tier-2
navigation:
  icon: 'cropsnh:genericSeed:0:{crop:"cropsnh:blackberry"}'
  title: Blackberry
  parent: /crops.md
  position: 18
  keywords:
    - Blackberry
    - Blackberry
---

# Blackberry

**Tier:** 2  
**Soil:** [Farmland](/mechanics/soil-and-blocks.md) — Farmland, Enchanted Earth, Ztones Garden Soil, Fertilized Dirt  
**Likes biomes:** WET, DENSE, LUSH  
**Alternate seed:** yes — plantable without breeding  
**Pools:** `BERRY`, `BLACK`, `BUSH`, `EDIBLE`  

Natura req

## Breeding setup

Full breeding setup — a cross-crop stick in the center on Farmland, with the parents planted in a line through it (**Strawberry** (north), **Blueberry** (south)):

<GameScene zoom={4} interactive={true}>
  <Block id="minecraft:dirt" x="0" y="0" z="0" />
  <Block id="minecraft:farmland" x="0" y="1" z="0" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crossCrop:1b}' x="0" y="2" z="0" />
  <Block id="minecraft:dirt" x="0" y="0" z="-1" />
  <Block id="minecraft:farmland" x="0" y="1" z="-1" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crop:{crop:"cropsnh:strawberry",amount:1,gr:1b,ga:1b,re:1b,scan:1b},progress:1000}' x="0" y="2" z="-1" />
  <Block id="minecraft:dirt" x="0" y="0" z="1" />
  <Block id="minecraft:farmland" x="0" y="1" z="1" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crop:{crop:"cropsnh:blueberry",amount:1,gr:1b,ga:1b,re:1b,scan:1b},progress:1000}' x="0" y="2" z="1" />
  <BlockAnnotation pos="0 2 0" color="#80FFAA00" thickness="2" alwaysOnTop={true}>Blackberry — cross-crop (result grows here)</BlockAnnotation>
  <BlockAnnotation pos="0 2 -1" color="#8044DD66" thickness="2" alwaysOnTop={true}>Strawberry (parent)</BlockAnnotation>
  <BlockAnnotation pos="0 2 1" color="#8044DD66" thickness="2" alwaysOnTop={true}>Blueberry (parent)</BlockAnnotation>
</GameScene>

## How to obtain

Bred from:

| Parents | Result pools | Notes |
|---------|--------------|-------|
| [Strawberry](/crops/strawberry.md) + [Blueberry](/crops/blueberry.md) | `BERRY`, `BLACK`, `BUSH`, `EDIBLE` | crop-stick cross |

Exact per-tick chance depends on soil and the parents' shared pools — check the [web calculator](https://crops-nh.netlify.app/calculator.html).

## Used to breed

Blackberry is a parent in these mutations:

| Produces | With |
|----------|------|
| [BoP Berry](/crops/bopberry.md) | [Poppy](/crops/poppy.md) |
| [Duskberry](/crops/duskberry.md) | [Ink Bloom](/crops/inkbloom.md) |
| [Grape](/crops/grape.md) | [Blueberry](/crops/blueberry.md) |
| [Huckleberry](/crops/huckleberry.md) | [Grape](/crops/grape.md) |
| [Ink Bloom](/crops/inkbloom.md) | [Goldfish](/crops/goldfish.md) |


