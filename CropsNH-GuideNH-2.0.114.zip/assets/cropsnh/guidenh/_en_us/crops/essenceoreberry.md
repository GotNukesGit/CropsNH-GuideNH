---
item_id: 'cropsnh:genericSeed:0:{crop:"cropsnh:essenceOreBerry"}'
categories:
  - crops
  - tier-5
navigation:
  icon: 'cropsnh:genericSeed:0:{crop:"cropsnh:essenceOreBerry"}'
  title: Essence Ore Berry
  parent: /crops.md
  position: 15
  keywords:
    - Essence Ore Berry
    - EssenceOreBerry
---

# Essence Ore Berry

> [!WARNING]
> **Buried block required.** This crop needs a `skull` block two spaces below the cross-crop stick (directly under the soil). Without it the crop won't grow — see the setup scene below.

**Tier:** 5  
**Soil:** [Stone](/mechanics/soil-and-blocks.md) — Stone, Cobblestone, Stone Brick, Mossy Cobble + Chisel variants  
**Block under soil:** `skull`  
**Likes biomes:** MAGICAL, DEAD  
**Alternate seed:** yes — plantable without breeding  
**Pools:** `DANGEROUS`, `EDIBLE`, `GREEN`, `ORE_BERRY`, `UNDEAD`  

TiC req

## Breeding setup

Full breeding setup — a cross-crop stick in the center on Stone over a **skull** block, with the parents planted around it (**Creeperweed** (north), **Zomplant** (south), **Spidernip** (east), **Tearstalks** (west)):

<GameScene zoom={4} interactive={true}>
  <Block id="minecraft:skull" x="0" y="0" z="0" />
  <Block id="minecraft:stone" x="0" y="1" z="0" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crossCrop:1b}' x="0" y="2" z="0" />
  <Block id="minecraft:dirt" x="0" y="0" z="-1" />
  <Block id="minecraft:farmland" x="0" y="1" z="-1" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crop:{crop:"cropsnh:creeperweed",amount:1,gr:1b,ga:1b,re:1b,scan:1b},progress:1000}' x="0" y="2" z="-1" />
  <Block id="tconstruct:CraftedSoil" meta="3" x="0" y="0" z="1" />
  <Block id="tconstruct:CraftedSoil" meta="3" x="0" y="1" z="1" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crop:{crop:"cropsnh:zomplant",amount:1,gr:1b,ga:1b,re:1b,scan:1b},progress:1000}' x="0" y="2" z="1" />
  <Block id="minecraft:dirt" x="1" y="0" z="0" />
  <Block id="minecraft:farmland" x="1" y="1" z="0" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crop:{crop:"cropsnh:spidernip",amount:1,gr:1b,ga:1b,re:1b,scan:1b},progress:1000}' x="1" y="2" z="0" />
  <Block id="minecraft:dirt" x="-1" y="0" z="0" />
  <Block id="minecraft:farmland" x="-1" y="1" z="0" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crop:{crop:"cropsnh:tearstalks",amount:1,gr:1b,ga:1b,re:1b,scan:1b},progress:1000}' x="-1" y="2" z="0" />
  <BlockAnnotation pos="0 2 0" color="#80FFAA00" thickness="2" alwaysOnTop={true}>Essence Ore Berry — cross-crop (result grows here)</BlockAnnotation>
  <BlockAnnotation pos="0 2 -1" color="#8044DD66" thickness="2" alwaysOnTop={true}>Creeperweed (parent)</BlockAnnotation>
  <BlockAnnotation pos="0 2 1" color="#8044DD66" thickness="2" alwaysOnTop={true}>Zomplant (parent)</BlockAnnotation>
  <BlockAnnotation pos="1 2 0" color="#8044DD66" thickness="2" alwaysOnTop={true}>Spidernip (parent)</BlockAnnotation>
  <BlockAnnotation pos="-1 2 0" color="#8044DD66" thickness="2" alwaysOnTop={true}>Tearstalks (parent)</BlockAnnotation>
</GameScene>

## How to obtain

Bred from:

| Parents | Result pools | Notes |
|---------|--------------|-------|
| [Creeperweed](/crops/creeperweed.md) + [Zomplant](/crops/zomplant.md) + [Spidernip](/crops/spidernip.md) + [Tearstalks](/crops/tearstalks.md) | `DANGEROUS`, `EDIBLE`, `GREEN`, `ORE_BERRY`, `UNDEAD` | crop-stick cross |

Exact per-tick chance depends on soil and the parents' shared pools — check the [web calculator](https://crops-nh.netlify.app/calculator.html).

## Used to breed

Essence Ore Berry is a parent in these mutations:

| Produces | With |
|----------|------|
| [Aluminium Ore Berry](/crops/aluminiumoreberry.md) | [Gold Ore Berry](/crops/goldoreberry.md) |


