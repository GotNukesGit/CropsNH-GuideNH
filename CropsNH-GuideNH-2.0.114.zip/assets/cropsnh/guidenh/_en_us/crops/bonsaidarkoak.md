---
item_id: 'cropsnh:genericSeed:0:{crop:"cropsnh:bonsaiDarkOak"}'
categories:
  - crops
  - tier-1
navigation:
  icon: 'cropsnh:genericSeed:0:{crop:"cropsnh:bonsaiDarkOak"}'
  title: Bonsai Dark Oak
  parent: /crops.md
  position: 19
  keywords:
    - Bonsai Dark Oak
    - BonsaiDarkOak
---

# Bonsai Dark Oak

**Tier:** 1  
**Soil:** [Dirt / Grass](/mechanics/soil-and-blocks.md) — Dirt, Grass, Mycelium variants  
**Likes biomes:** DENSE, FOREST, SPOOKY  
**Alternate seed:** no  
**Pools:** `BROWN`, `DARK`, `EDIBLE`, `LEAFY`, `TREE`, `WOODEN`  

## Breeding setup

Full breeding setup — a cross-crop stick in the center on Dirt / Grass, with the parents planted in a line through it (**Bonsai Spruce** (north), **Bonsai Oak** (south)):

<GameScene zoom={4} interactive={true}>
  <Block id="minecraft:dirt" x="0" y="0" z="0" />
  <Block id="minecraft:dirt" x="0" y="1" z="0" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crossCrop:1b}' x="0" y="2" z="0" />
  <Block id="minecraft:dirt" x="0" y="0" z="-1" />
  <Block id="minecraft:dirt" x="0" y="1" z="-1" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crop:{crop:"cropsnh:bonsaiSpruce",amount:1,gr:1b,ga:1b,re:1b,scan:1b},progress:1000}' x="0" y="2" z="-1" />
  <Block id="minecraft:dirt" x="0" y="0" z="1" />
  <Block id="minecraft:dirt" x="0" y="1" z="1" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crop:{crop:"cropsnh:bonsaiOak",amount:1,gr:1b,ga:1b,re:1b,scan:1b},progress:1000}' x="0" y="2" z="1" />
  <BlockAnnotation pos="0 2 0" color="#80FFAA00" thickness="2" alwaysOnTop={true}>Bonsai Dark Oak — cross-crop (result grows here)</BlockAnnotation>
  <BlockAnnotation pos="0 2 -1" color="#8044DD66" thickness="2" alwaysOnTop={true}>Bonsai Spruce (parent)</BlockAnnotation>
  <BlockAnnotation pos="0 2 1" color="#8044DD66" thickness="2" alwaysOnTop={true}>Bonsai Oak (parent)</BlockAnnotation>
</GameScene>

## How to obtain

Bred from:

| Parents | Result pools | Notes |
|---------|--------------|-------|
| [Bonsai Spruce](/crops/bonsaispruce.md) + [Bonsai Oak](/crops/bonsaioak.md) | `BROWN`, `DARK`, `EDIBLE`, `LEAFY`, `TREE`, `WOODEN` | crop-stick cross |

Exact per-tick chance depends on soil and the parents' shared pools — check the [web calculator](https://crops-nh.netlify.app/calculator.html).

## Used to breed

Bonsai Dark Oak is a parent in these mutations:

| Produces | With |
|----------|------|
| [Knightmetal Berry](/crops/knightmetalberry.md) | [Iron Ore Berry](/crops/ironoreberry.md) + [Torchberry](/crops/torchberry.md) |
| [Liveroot](/crops/liveroot.md) | [Torchberry](/crops/torchberry.md) |


