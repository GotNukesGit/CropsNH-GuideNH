---
item_id: 'cropsnh:genericSeed:0:{crop:"cropsnh:nickelback"}'
categories:
  - crops
  - tier-5
navigation:
  icon: 'cropsnh:genericSeed:0:{crop:"cropsnh:nickelback"}'
  title: Nickelback
  parent: /crops.md
  position: 15
  keywords:
    - Nickelback
    - Nickelback
---

# Nickelback

> [!WARNING]
> **Buried block required.** This crop needs a `nickel` block two spaces below the cross-crop stick (directly under the soil). Without it the crop won't grow — see the setup scene below.

**Tier:** 5  
**Soil:** [Stone](/mechanics/soil-and-blocks.md) — Stone, Cobblestone, Stone Brick, Mossy Cobble + Chisel variants  
**Block under soil:** `nickel`  
**Likes biomes:** PLAINS, LUSH  
**Alternate seed:** no  
**Pools:** `FIERY`, `METALLIC`  

## Breeding setup

Full breeding setup — a cross-crop stick in the center on Stone over a **nickel** block, with the parents planted in a line through it (**Ferrofern** (north), **Coppon** (south)):

<GameScene zoom={4} interactive={true}>
  <Block id="gregtech:gt.blockmetal5" meta="4" x="0" y="0" z="0" />
  <Block id="minecraft:stone" x="0" y="1" z="0" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crossCrop:1b}' x="0" y="2" z="0" />
  <Block id="minecraft:iron_block" x="0" y="0" z="-1" />
  <Block id="minecraft:stone" x="0" y="1" z="-1" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crop:{crop:"cropsnh:ferrofern",amount:1,gr:1b,ga:1b,re:1b,scan:1b},progress:1000}' x="0" y="2" z="-1" />
  <Block id="gregtech:gt.blockmetal2" meta="7" x="0" y="0" z="1" />
  <Block id="minecraft:stone" x="0" y="1" z="1" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crop:{crop:"cropsnh:coppon",amount:1,gr:1b,ga:1b,re:1b,scan:1b},progress:1000}' x="0" y="2" z="1" />
  <BlockAnnotation pos="0 2 0" color="#80FFAA00" thickness="2" alwaysOnTop={true}>Nickelback — cross-crop (result grows here)</BlockAnnotation>
  <BlockAnnotation pos="0 2 -1" color="#8044DD66" thickness="2" alwaysOnTop={true}>Ferrofern (parent)</BlockAnnotation>
  <BlockAnnotation pos="0 2 1" color="#8044DD66" thickness="2" alwaysOnTop={true}>Coppon (parent)</BlockAnnotation>
</GameScene>

## How to obtain

Bred from:

| Parents | Result pools | Notes |
|---------|--------------|-------|
| [Ferrofern](/crops/ferrofern.md) + [Coppon](/crops/coppon.md) | `FIERY`, `METALLIC` | crop-stick cross |

Exact per-tick chance depends on soil and the parents' shared pools — check the [web calculator](https://crops-nh.netlify.app/calculator.html).

## Used to breed

Nickelback is a parent in these mutations:

| Produces | With |
|----------|------|
| [Pyrolusium](/crops/pyrolusium.md) | [Bauxia](/crops/bauxia.md) |
| [Bauxia](/crops/bauxia.md) | [Galvania](/crops/galvania.md) |


