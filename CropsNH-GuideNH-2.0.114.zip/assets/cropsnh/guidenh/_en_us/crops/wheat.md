---
item_id: 'cropsnh:genericSeed:0:{crop:"cropsnh:wheat"}'
categories:
  - crops
  - tier-1
navigation:
  icon: 'cropsnh:genericSeed:0:{crop:"cropsnh:wheat"}'
  title: Wheat
  parent: /crops.md
  position: 19
  keywords:
    - Wheat
    - Wheat
---

# Wheat

> [!NOTE]
> **Directly obtainable.** No breeding recipe — plant it from a seed you can get by other means.

**Tier:** 1  
**Soil:** [Farmland](/mechanics/soil-and-blocks.md) — Farmland, Enchanted Earth, Ztones Garden Soil, Fertilized Dirt  
**Likes biomes:** PLAINS, LUSH  
**Alternate seed:** yes — plantable without breeding  
**Pools:** `EDIBLE`, `WHEAT`, `YELLOW`  

## Setup

Grow **Wheat** on Farmland:

<GameScene zoom={4} interactive={true}>
  <Block id="minecraft:dirt" x="0" y="0" z="0" />
  <Block id="minecraft:farmland" x="0" y="1" z="0" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crop:{crop:"cropsnh:wheat",amount:1,gr:1b,ga:1b,re:1b,scan:1b},progress:1000}' x="0" y="2" z="0" />
  <BlockAnnotation pos="0 2 0" color="#8044DD66" thickness="2" alwaysOnTop={true}>Wheat</BlockAnnotation>
</GameScene>

## How to obtain

No breeding recipe — obtain the seed directly.

## Used to breed

Wheat is a parent in these mutations:

| Produces | With |
|----------|------|
| [Barley](/crops/barley.md) | [Bamboo](/crops/bamboo.md) |
| [Bonsai Oak](/crops/bonsaioak.md) | [Brown Mushroom](/crops/brownmushroom.md) |
| [Canola](/crops/canola.md) | [Oxeye Daisy](/crops/oxeyedaisy.md) |
| [Corium](/crops/corium.md) | [Cocoa](/crops/cocoa.md) |
| [Flax](/crops/flax.md) | [Azure Bluet](/crops/azurebluet.md) |
| [Glowheat](/crops/glowheat.md) | [Glowflower](/crops/glowflower.md) |
| [Red Straw](/crops/redstraw.md) | [Nether Stone Lily](/crops/netherstonelily.md) |
| [Strawberry](/crops/strawberry.md) | [Raspberry](/crops/raspberry.md) |


