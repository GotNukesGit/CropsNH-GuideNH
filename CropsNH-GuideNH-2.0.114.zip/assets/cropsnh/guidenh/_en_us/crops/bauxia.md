---
item_id: 'cropsnh:genericSeed:0:{crop:"cropsnh:bauxia"}'
categories:
  - crops
  - tier-6
navigation:
  icon: 'cropsnh:genericSeed:0:{crop:"cropsnh:bauxia"}'
  title: Bauxia
  parent: /crops.md
  position: 14
  keywords:
    - Bauxia
    - Bauxia
---

# Bauxia

> [!NOTE]
> **Machine-only.** Produced by a machine process, not by breeding on crop sticks.

> [!WARNING]
> **Buried block required.** This crop needs a `aluminiumBauxite` block two spaces below the cross-crop stick (directly under the soil). Without it the crop won't grow — see the setup scene below.

**Tier:** 6  
**Soil:** [Stone](/mechanics/soil-and-blocks.md) — Stone, Cobblestone, Stone Brick, Mossy Cobble + Chisel variants  
**Block under soil:** `aluminiumBauxite`  
**Likes biomes:** COLD, DRY  
**Alternate seed:** no  

## Breeding setup

Full breeding setup — a cross-crop stick in the center on Stone over a **aluminiumBauxite** block, with the parents planted in a line through it (**Galvania** (north), **Nickelback** (south)):

<GameScene zoom={4} interactive={true}>
  <Block id="gregtech:gt.blockmetal1" meta="1" x="0" y="0" z="0" />
  <Block id="minecraft:stone" x="0" y="1" z="0" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crossCrop:1b}' x="0" y="2" z="0" />
  <Block id="gregtech:gt.blockmetal8" meta="6" x="0" y="0" z="-1" />
  <Block id="minecraft:stone" x="0" y="1" z="-1" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crop:{crop:"cropsnh:galvania",amount:1,gr:1b,ga:1b,re:1b,scan:1b},progress:1000}' x="0" y="2" z="-1" />
  <Block id="gregtech:gt.blockmetal5" meta="4" x="0" y="0" z="1" />
  <Block id="minecraft:stone" x="0" y="1" z="1" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crop:{crop:"cropsnh:nickelback",amount:1,gr:1b,ga:1b,re:1b,scan:1b},progress:1000}' x="0" y="2" z="1" />
  <BlockAnnotation pos="0 2 0" color="#80FFAA00" thickness="2" alwaysOnTop={true}>Bauxia — cross-crop (result grows here)</BlockAnnotation>
  <BlockAnnotation pos="0 2 -1" color="#8044DD66" thickness="2" alwaysOnTop={true}>Galvania (parent)</BlockAnnotation>
  <BlockAnnotation pos="0 2 1" color="#8044DD66" thickness="2" alwaysOnTop={true}>Nickelback (parent)</BlockAnnotation>
</GameScene>

## How to obtain

Bred from:

| Parents | Result pools | Notes |
|---------|--------------|-------|
| [Galvania](/crops/galvania.md) + [Nickelback](/crops/nickelback.md) | `STONE` | machine recipe |

Exact per-tick chance depends on soil and the parents' shared pools — check the [web calculator](https://crops-nh.netlify.app/calculator.html).

## Used to breed

Bauxia is a parent in these mutations:

| Produces | With |
|----------|------|
| [Pyrolusium](/crops/pyrolusium.md) | [Nickelback](/crops/nickelback.md) |
| [Micadia](/crops/micadia.md) | [Tine](/crops/tine.md) |
| [Titania](/crops/titania.md) | [Red Straw](/crops/redstraw.md) |
| [Transformium](/crops/transformium.md) | [Trollplant](/crops/trollplant.md) + [Titania](/crops/titania.md) |


