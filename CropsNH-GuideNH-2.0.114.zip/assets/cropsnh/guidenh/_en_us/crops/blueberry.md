---
item_id: 'cropsnh:genericSeed:0:{crop:"cropsnh:blueberry"}'
categories:
  - crops
  - tier-2
navigation:
  icon: 'cropsnh:genericSeed:0:{crop:"cropsnh:blueberry"}'
  title: Blueberry
  parent: /crops.md
  position: 18
  keywords:
    - Blueberry
    - Blueberry
---

# Blueberry

**Tier:** 2  
**Soil:** [Farmland](/mechanics/soil-and-blocks.md) — Farmland, Enchanted Earth, Ztones Garden Soil, Fertilized Dirt  
**Likes biomes:** HILLS, FOREST, LUSH  
**Alternate seed:** yes — plantable without breeding  
**Pools:** `BERRY`, `BLUE`, `BUSH`, `EDIBLE`  

Natura req

## Breeding setup

Full breeding setup — a cross-crop stick in the center on Farmland, with the parents planted in a line through it (**Azure Bluet** (north), **Bonsai Oak** (south)):

<GameScene zoom={4} interactive={true}>
  <Block id="minecraft:dirt" x="0" y="0" z="0" />
  <Block id="minecraft:farmland" x="0" y="1" z="0" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crossCrop:1b}' x="0" y="2" z="0" />
  <Block id="minecraft:dirt" x="0" y="0" z="-1" />
  <Block id="minecraft:dirt" x="0" y="1" z="-1" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crop:{crop:"cropsnh:azureBluet",amount:1,gr:1b,ga:1b,re:1b,scan:1b},progress:1000}' x="0" y="2" z="-1" />
  <Block id="minecraft:dirt" x="0" y="0" z="1" />
  <Block id="minecraft:dirt" x="0" y="1" z="1" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crop:{crop:"cropsnh:bonsaiOak",amount:1,gr:1b,ga:1b,re:1b,scan:1b},progress:1000}' x="0" y="2" z="1" />
  <BlockAnnotation pos="0 2 0" color="#80FFAA00" thickness="2" alwaysOnTop={true}>Blueberry — cross-crop (result grows here)</BlockAnnotation>
  <BlockAnnotation pos="0 2 -1" color="#8044DD66" thickness="2" alwaysOnTop={true}>Azure Bluet (parent)</BlockAnnotation>
  <BlockAnnotation pos="0 2 1" color="#8044DD66" thickness="2" alwaysOnTop={true}>Bonsai Oak (parent)</BlockAnnotation>
</GameScene>

## How to obtain

Bred from:

| Parents | Result pools | Notes |
|---------|--------------|-------|
| [Azure Bluet](/crops/azurebluet.md) + [Bonsai Oak](/crops/bonsaioak.md) | `BERRY`, `BLUE`, `BUSH`, `EDIBLE` | crop-stick cross |

Exact per-tick chance depends on soil and the parents' shared pools — check the [web calculator](https://crops-nh.netlify.app/calculator.html).

## Used to breed

Blueberry is a parent in these mutations:

| Produces | With |
|----------|------|
| [Blackberry](/crops/blackberry.md) | [Strawberry](/crops/strawberry.md) |
| [Grape](/crops/grape.md) | [Blackberry](/crops/blackberry.md) |
| [Maloberry](/crops/maloberry.md) | [Orange Tulip](/crops/orangetulip.md) |
| [Skyberry](/crops/skyberry.md) | [Dayflower](/crops/dayflower.md) |
| [Tea](/crops/tea.md) | [Bonsai Jungle](/crops/bonsaijungle.md) |


