---
item_id: 'cropsnh:genericSeed:0:{crop:"cropsnh:whiteTulip"}'
categories:
  - crops
  - tier-2
navigation:
  icon: 'cropsnh:genericSeed:0:{crop:"cropsnh:whiteTulip"}'
  title: White Tulip
  parent: /crops.md
  position: 18
  keywords:
    - White Tulip
    - WhiteTulip
---

# White Tulip

**Tier:** 2  
**Soil:** [Dirt / Grass](/mechanics/soil-and-blocks.md) — Dirt, Grass, Mycelium variants  
**Likes biomes:** PLAINS, COLD  
**Alternate seed:** yes — plantable without breeding  
**Pools:** `FLOWER`, `TULIP`, `WHITE`  

## Breeding setup

Full breeding setup — a cross-crop stick in the center on Dirt / Grass, with the parents planted in a line through it (**Pink Tulip** (north), **Oxeye Daisy** (south)):

<GameScene zoom={4} interactive={true}>
  <Block id="minecraft:dirt" x="0" y="0" z="0" />
  <Block id="minecraft:dirt" x="0" y="1" z="0" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crossCrop:1b}' x="0" y="2" z="0" />
  <Block id="minecraft:dirt" x="0" y="0" z="-1" />
  <Block id="minecraft:dirt" x="0" y="1" z="-1" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crop:{crop:"cropsnh:pinkTulip",amount:1,gr:1b,ga:1b,re:1b,scan:1b},progress:1000}' x="0" y="2" z="-1" />
  <Block id="minecraft:dirt" x="0" y="0" z="1" />
  <Block id="minecraft:dirt" x="0" y="1" z="1" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crop:{crop:"cropsnh:oxeyeDaisy",amount:1,gr:1b,ga:1b,re:1b,scan:1b},progress:1000}' x="0" y="2" z="1" />
  <BlockAnnotation pos="0 2 0" color="#80FFAA00" thickness="2" alwaysOnTop={true}>White Tulip — cross-crop (result grows here)</BlockAnnotation>
  <BlockAnnotation pos="0 2 -1" color="#8044DD66" thickness="2" alwaysOnTop={true}>Pink Tulip (parent)</BlockAnnotation>
  <BlockAnnotation pos="0 2 1" color="#8044DD66" thickness="2" alwaysOnTop={true}>Oxeye Daisy (parent)</BlockAnnotation>
</GameScene>

## How to obtain

Bred from:

| Parents | Result pools | Notes |
|---------|--------------|-------|
| [Pink Tulip](/crops/pinktulip.md) + [Oxeye Daisy](/crops/oxeyedaisy.md) | `FLOWER`, `TULIP`, `WHITE` | crop-stick cross |

Exact per-tick chance depends on soil and the parents' shared pools — check the [web calculator](https://crops-nh.netlify.app/calculator.html).

## Used to breed

White Tulip is a parent in these mutations:

| Produces | With |
|----------|------|
| [Pink Tulip](/crops/pinktulip.md) | [Red Tulip](/crops/redtulip.md) |
| [Red Tulip](/crops/redtulip.md) | [Poppy](/crops/poppy.md) |
| [Shimmerleaf](/crops/shimmerleaf.md) | [Red Straw](/crops/redstraw.md) |


