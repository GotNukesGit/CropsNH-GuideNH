---
item_id: 'cropsnh:genericSeed:0:{crop:"cropsnh:netherwart"}'
categories:
  - crops
  - tier-5
navigation:
  icon: 'cropsnh:genericSeed:0:{crop:"cropsnh:netherwart"}'
  title: Nether Wart
  parent: /crops.md
  position: 15
  keywords:
    - Nether Wart
    - Netherwart
---

# Nether Wart

**Tier:** 5  
**Soil:** [Soul Sand](/mechanics/soil-and-blocks.md) — Soul Sand  
**Likes biomes:** NETHER, HOT  
**Alternate seed:** yes — plantable without breeding  
**Pools:** `NETHER`, `POTION_INGREDIENT`, `RED`  

## Breeding setup

Full breeding setup — a cross-crop stick in the center on Soul Sand, with the parents planted in a line through it (**Red Mushroom** (north), **Brown Mushroom** (south)):

<GameScene zoom={4} interactive={true}>
  <Block id="minecraft:soul_sand" x="0" y="0" z="0" />
  <Block id="minecraft:soul_sand" x="0" y="1" z="0" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crossCrop:1b}' x="0" y="2" z="0" />
  <Block id="minecraft:stone" x="0" y="0" z="-1" />
  <Block id="minecraft:stone" x="0" y="1" z="-1" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crop:{crop:"cropsnh:redMushroom",amount:1,gr:1b,ga:1b,re:1b,scan:1b},progress:1000}' x="0" y="2" z="-1" />
  <Block id="minecraft:stone" x="0" y="0" z="1" />
  <Block id="minecraft:stone" x="0" y="1" z="1" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crop:{crop:"cropsnh:brownMushroom",amount:1,gr:1b,ga:1b,re:1b,scan:1b},progress:1000}' x="0" y="2" z="1" />
  <BlockAnnotation pos="0 2 0" color="#80FFAA00" thickness="2" alwaysOnTop={true}>Nether Wart — cross-crop (result grows here)</BlockAnnotation>
  <BlockAnnotation pos="0 2 -1" color="#8044DD66" thickness="2" alwaysOnTop={true}>Red Mushroom (parent)</BlockAnnotation>
  <BlockAnnotation pos="0 2 1" color="#8044DD66" thickness="2" alwaysOnTop={true}>Brown Mushroom (parent)</BlockAnnotation>
</GameScene>

## How to obtain

Bred from:

| Parents | Result pools | Notes |
|---------|--------------|-------|
| [Red Mushroom](/crops/redmushroom.md) + [Brown Mushroom](/crops/brownmushroom.md) | `NETHER`, `POTION_INGREDIENT`, `RED` | crop-stick cross |

Exact per-tick chance depends on soil and the parents' shared pools — check the [web calculator](https://crops-nh.netlify.app/calculator.html).

## Used to breed

Nether Wart is a parent in these mutations:

| Produces | With |
|----------|------|
| [Milk Wart](/crops/milkwart.md) | [Corium](/crops/corium.md) |
| [Nether Stone Lily](/crops/netherstonelily.md) | [Stone Lily](/crops/stonelily.md) |


