---
item_id: 'cropsnh:genericSeed:0:{crop:"cropsnh:glowshroom"}'
categories:
  - crops
  - tier-3
navigation:
  icon: 'cropsnh:genericSeed:0:{crop:"cropsnh:glowshroom"}'
  title: Glowshroom
  parent: /crops.md
  position: 17
  keywords:
    - Glowshroom
    - Glowshroom
---

# Glowshroom

**Tier:** 3  
**Soil:** [Nether Mushroom Soil](/mechanics/soil-and-blocks.md) — Stone, Dirt, Mycelium, Netherrack  
**Likes biomes:** NETHER, MAGICAL, MUSHROOM  
**Alternate seed:** yes — plantable without breeding  
**Pools:** `EMISSIVE`, `GREEN`, `MUSHROOM`, `NETHER`, `POTION_INGREDIENT`  

BoP req

## Breeding setup

Full breeding setup — a cross-crop stick in the center on Nether Mushroom Soil, with the parents planted around it (**Blue Glowshroom** (north), **Green Glowshroom** (south), **Purple Glowshroom** (east)):

<GameScene zoom={4} interactive={true}>
  <Block id="minecraft:netherrack" x="0" y="0" z="0" />
  <Block id="minecraft:netherrack" x="0" y="1" z="0" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crossCrop:1b}' x="0" y="2" z="0" />
  <Block id="minecraft:netherrack" x="0" y="0" z="-1" />
  <Block id="minecraft:netherrack" x="0" y="1" z="-1" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crop:{crop:"cropsnh:blueGlowshroom",amount:1,gr:1b,ga:1b,re:1b,scan:1b},progress:1000}' x="0" y="2" z="-1" />
  <Block id="minecraft:netherrack" x="0" y="0" z="1" />
  <Block id="minecraft:netherrack" x="0" y="1" z="1" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crop:{crop:"cropsnh:greenGlowshroom",amount:1,gr:1b,ga:1b,re:1b,scan:1b},progress:1000}' x="0" y="2" z="1" />
  <Block id="minecraft:netherrack" x="1" y="0" z="0" />
  <Block id="minecraft:netherrack" x="1" y="1" z="0" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crop:{crop:"cropsnh:purpleGlowshroom",amount:1,gr:1b,ga:1b,re:1b,scan:1b},progress:1000}' x="1" y="2" z="0" />
  <BlockAnnotation pos="0 2 0" color="#80FFAA00" thickness="2" alwaysOnTop={true}>Glowshroom — cross-crop (result grows here)</BlockAnnotation>
  <BlockAnnotation pos="0 2 -1" color="#8044DD66" thickness="2" alwaysOnTop={true}>Blue Glowshroom (parent)</BlockAnnotation>
  <BlockAnnotation pos="0 2 1" color="#8044DD66" thickness="2" alwaysOnTop={true}>Green Glowshroom (parent)</BlockAnnotation>
  <BlockAnnotation pos="1 2 0" color="#8044DD66" thickness="2" alwaysOnTop={true}>Purple Glowshroom (parent)</BlockAnnotation>
</GameScene>

## How to obtain

Bred from:

| Parents | Result pools | Notes |
|---------|--------------|-------|
| [Blue Glowshroom](/crops/blueglowshroom.md) + [Green Glowshroom](/crops/greenglowshroom.md) + [Purple Glowshroom](/crops/purpleglowshroom.md) | `EMISSIVE`, `GREEN`, `MUSHROOM`, `NETHER`, `POTION_INGREDIENT` | crop-stick cross |

Exact per-tick chance depends on soil and the parents' shared pools — check the [web calculator](https://crops-nh.netlify.app/calculator.html).


