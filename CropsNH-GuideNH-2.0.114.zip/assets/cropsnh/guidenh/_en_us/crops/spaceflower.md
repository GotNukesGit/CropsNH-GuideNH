---
item_id: 'cropsnh:genericSeed:0:{crop:"cropsnh:spaceFlower"}'
categories:
  - crops
  - tier-13
navigation:
  icon: 'cropsnh:genericSeed:0:{crop:"cropsnh:spaceFlower"}'
  title: Space FlowerS
  parent: /crops.md
  position: 7
  keywords:
    - Space FlowerS
    - SpaceFlower
---

# Space FlowerS

> [!NOTE]
> **Machine-only.** Produced by a machine process, not by breeding on crop sticks.

> [!WARNING]
> **Buried block required.** This crop needs a `space` block two spaces below the cross-crop stick (directly under the soil). Without it the crop won't grow — see the setup scene below.

**Tier:** 13  
**Soil:** [Farmland](/mechanics/soil-and-blocks.md) — Farmland, Enchanted Earth, Ztones Garden Soil, Fertilized Dirt  
**Block under soil:** `space`  
**Likes biomes:** COLD, DRY, DEAD  
**Alternate seed:** no  

Crop Synthesizer only. Requires space rock y-2. Galacticraft req. UV+ machine tier.

## Breeding setup

Full breeding setup — a cross-crop stick in the center on Farmland over a **space** block, with the parents planted in a line through it (**End Stone Lily** (north), **Titania** (south)):

<GameScene zoom={4} interactive={true}>
  <Block id="GalacticraftCore:tile.moonBlock" meta="4" x="0" y="0" z="0" />
  <Block id="minecraft:farmland" x="0" y="1" z="0" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crossCrop:1b}' x="0" y="2" z="0" />
  <Block id="minecraft:end_stone" x="0" y="0" z="-1" />
  <Block id="minecraft:stone" x="0" y="1" z="-1" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crop:{crop:"cropsnh:endStoneLily",amount:1,gr:1b,ga:1b,re:1b,scan:1b},progress:1000}' x="0" y="2" z="-1" />
  <Block id="gregtech:gt.blockmetal7" meta="9" x="0" y="0" z="1" />
  <Block id="minecraft:stone" x="0" y="1" z="1" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crop:{crop:"cropsnh:titania",amount:1,gr:1b,ga:1b,re:1b,scan:1b},progress:1000}' x="0" y="2" z="1" />
  <BlockAnnotation pos="0 2 0" color="#80FFAA00" thickness="2" alwaysOnTop={true}>Space FlowerS — cross-crop (result grows here)</BlockAnnotation>
  <BlockAnnotation pos="0 2 -1" color="#8044DD66" thickness="2" alwaysOnTop={true}>End Stone Lily (parent)</BlockAnnotation>
  <BlockAnnotation pos="0 2 1" color="#8044DD66" thickness="2" alwaysOnTop={true}>Titania (parent)</BlockAnnotation>
</GameScene>

## How to obtain

Bred from:

| Parents | Result pools | Notes |
|---------|--------------|-------|
| [End Stone Lily](/crops/endstonelily.md) + [Titania](/crops/titania.md) | `FLOWER` | machine recipe |

Exact per-tick chance depends on soil and the parents' shared pools — check the [web calculator](https://crops-nh.netlify.app/calculator.html).


