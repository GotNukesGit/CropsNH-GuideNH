---
navigation:
  icon: 'cropsnh:plantLens'
  title: Core mechanics
  parent: /index.md
  position: 40
---

# Core Mechanics

The rules underneath every crop: what soil and buried block it needs, what its three seed stats
do, and how the growth formula turns nutrients into growth. All verified against the decompiled
`TileEntityCropSticks`.

<SubPages/>

