---
navigation:
  icon: 'minecraft:grass'
  title: Best biomes
  parent: /strategy.md
  position: 4
---

# Best Biomes

> [!TIP]
> **TL;DR.** Crops grow faster in biomes matching their liked tags (up to +28) — and any biome with
> **rainfall ≥ 0.8** hands out **+14 for free**. Set up dedicated farms per crop family. Tags below
> are the real GTNH biome table, not vanilla defaults.

| Biome | Tags | Great for (+28 double-match) |
|---|---|---|
| **Extreme Hills** | MOUNTAIN, HILLS | Ferrofern, Tine, StoneLily, Iron/TinOreBerry — best for ore/metal |
| **The Nether** | HOT, DRY, NETHER | Ardite/CobaltOreBerry, Nether Wart |
| **Jungle** | HOT, DENSE, WET, JUNGLE | BonsaiJungle, Cocoa, StickyCane; most food gets ≥ +14 |
| **Savanna** | HOT, SPARSE, SAVANNA, PLAINS | Coppon, CopperOreBerry, Carrot |
| **Mesa** | MESA, SANDY | GoldOreBerry, Auronia |
| **The End** | COLD, DRY, END | Enderbloom |
| **Roofed Forest** | DENSE, SPOOKY, FOREST | Withereed, Corpseplant, Creeperweed (SPOOKY only, +14) |

<details>
<summary>The humidity bonus — a hidden free nutrient</summary>

Every biome has a rainfall value (0.0–~1.2). `clamp((rainfall−0.5)/0.3, 0, 1) × 14` — so rainfall
≥ 0.8 gives the full +14 regardless of tags, and ≤ 0.5 gives nothing. The game takes
**max(humidity, likedTags)** — they don't stack. A crop with zero matched tags in a wet biome still
gets +14 free.

</details>

> [!CAUTION]
> GTNH mixes vanilla, BoP, and RWG biomes, and many vanilla Overworld biomes don't generate. If a
> biome name here doesn't appear in the calculator, check the in-game name (F3 / a Crop Lens).

