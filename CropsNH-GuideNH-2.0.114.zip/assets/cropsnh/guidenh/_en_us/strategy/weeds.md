---
navigation:
  icon: 'minecraft:tallgrass:1'
  title: Weed management
  parent: /strategy.md
  position: 2
---

# Weed Management

> [!TIP]
> **TL;DR.** Weeds are the main way crops get sick. When a weed spreads onto an occupied stick it
> calls `transferDisease()` — the neighbour goes sick, nothing more. A crop deflects an incoming
> weed only with **WeedEx stocked AND Resistance ≥ Growth** (both). WeedEx never removes existing
> weeds — pull those with the **Spade**.

| Tool / condition | Effect |
|---|---|
| <ItemImage id="cropsnh:weedEX"/> **WeedEx** | Stops weeds spawning in empty sticks (−5) and stops crops going sick when weeds spread (−2). Does **not** remove existing weeds. No stat penalty (that's IC2-only). |
| <ItemImage id="cropsnh:spade"/> **Spade** | Removes weeds manually; returns a seed at res/31 odds on harvest. |
| <ItemImage id="cropsnh:reinforcedSpade"/> **Reinforced Spade** | Guaranteed seed return: `floor(Resistance/10)` + a chance at one more; up to 4 at R31. |
| **Resistance ≥ Growth + WeedEx** | Together, unconditionally deflect incoming spread and stop outward spread. Resistance alone isn't enough. |

> [!CAUTION]
> A mature crop spreads weeds only if **Growth > 24 AND Resistance < Growth**. If a weed has no
> stick to spread onto, it converts the **dirt/farmland beneath into grass** — unchecked weeds eat
> into your terrain.

