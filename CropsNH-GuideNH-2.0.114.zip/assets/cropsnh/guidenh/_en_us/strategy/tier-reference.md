---
navigation:
  icon: 'cropsnh:plantLens'
  title: Tier reference
  parent: /strategy.md
  position: 0
---

# Tier Reference

> [!TIP]
> **TL;DR.** Higher tier = longer to mature and more nutrients needed. **T1–4** are easy anywhere.
> **T5–7** need full water, fertilizer, and ideally a liked biome. **T8+** practically require the
> Industrial Farm.

| Tier | Nutrient need | Growth duration | Example crops |
|:--:|:--:|:--:|---|
| **T1** | 10 | 600 pts | Wheat, Potato, all 7 Bonsai variants*, BrownMushroom |
| **T2** | 20 | 1200 pts | Carrot, Melon, Pumpkin, SugarCane, Vine, Dandelion, Poppy |
| **T3** | 30 | 1800 pts | Cocoa, Cactus, Zomplant, Cotton, FloweringVine |
| **T4** | 40 | 2400 pts | StickyCane, Canola, Rubyne, Sapphirum, Glowheat, Spidernip |
| **T5** | 50 | 3000 pts | Nether Wart, Hemp, Tine, Nickelback, Corpseplant, IronOreBerry |
| **T6** | 60 | 3600 pts | Ferrofern, Coppon, Galvania, Corium, Slimeplant, EggPlant |
| **T7** | 70 | 4200 pts | Argentia, Lazulia, Creeperweed, Meatrose, ThaumiumOreBerry |
| **T8** | 80 | 4800 pts | Withereed, Auronia, Tearstalks, Liveroot |
| **T9** | 90 | 5400 pts | Micadia, Titania, GodOfThunder |
| **T10** | 100 | 6000 pts | Enderbloom, Steeleafranks — practically needs Industrial Farm |
| **T11** | 110 | 6600 pts | Platina |
| **T12** | 120 | 7200 pts | Diareed, Pyrolusium, Reactoria, StarWart — Industrial Farm recommended |
| **T13** | 130 | 7800 pts | SpaceFlower, MagicalNightshade |
| **T16** | 160 | 9600 pts | PrimordialBerry — highest tier |

*Bonsai growth is hardcoded to a flat 1200 regardless of tier.*

> [!IMPORTANT]
> **Tier 5+ checklist:** ☑ full water ☑ full fertilizer ☑ sky access (+2) ☑ at least one liked
> biome tag (+14) ☑ calculator doesn't show SICK.

