---
navigation:
  icon: 'cropsnh:cropSticks'
  title: Automation & tools
  parent: /strategy.md
  position: 1
---

# Automation & Tools

| Machine / tool | Tier | What it does |
|---|---|---|
| **Crop Manager** | LV–UV | Waters, fertilizes, applies WeedEx, harvests. **No** auto-replant or seed removal — always manual. Keep a seed chest adjacent. |
| **Industrial Farm** | MV+ multiblock | Simulates growth internally — no physical sticks, sky/weather irrelevant. Upgrade units (biome, harvesting, fertilization). Best endgame mass production; 4× the seed-bed bonus. |
| **World Accelerator** | any | In Tile-Entity mode on a cross-crop stick, multiplies breeding attempts per second. |
| <ItemImage id="cropsnh:spade"/> **Spade / Reinforced Spade** | CropsNH | Harvest + seed return; also remove weeds. |
| <ItemImage id="cropsnh:plantLens"/> **Crop Lens** | CropsNH | Identify a growing crop's type & stats without harvesting. |
| <ItemImage id="cropsnh:plantCure"/> **Plant Cure** | CropsNH | Right-click a sick (green) crop to cure it. |

> [!NOTE]
> Two drop mechanics exist among metal crops: leaf/fiber/twig crops (Ferrofern, Coppon, Tine…) drop
> a custom CropsNH item (macerate/extract); ore-berry crops drop a TiC "Ore Berries" item (smelt →
> nugget, 9 → ingot). Check NEI for exact recipes.

