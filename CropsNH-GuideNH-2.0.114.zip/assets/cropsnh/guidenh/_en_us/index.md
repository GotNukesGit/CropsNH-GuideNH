---
navigation:
  icon: 'cropsnh:cropSticks'
  title: CropsNH Guide
  position: 0
  required_mod: cropsnh
  recommend: 100
---

# <Color color="#5fd38d">CropsNH</Color> — GTNH 2.9 Breeding Guide

Everything you need to go from your first crop stick to farming **Diareed at tier 12** —
soils, block-under requirements, the breeding tick, the pool system, and every crop's
recipe. Mechanics researched straight from the decompiled mod source.

> [!TIP]
> **How to use this guide.** Every section leads with a plain-English **TL;DR**, then tucks
> the deep detail inside a **Show details** spoiler. Want to just play? The TL;DRs are enough.
> Optimizing or debugging? Open the spoiler.

<Row gap="8">
<Color color="#5fd38d">**GTNH 2.9 Beta 2**</Color>
<Color color="#6db3f2">**AgriCraft fork**</Color>
<Color color="#f2c14e">**Replaces IC2 Crops**</Color>
<Color color="#c39bff">**v2.0.91 · build 609**</Color>
</Row>

## Start here

- [Getting started](/getting-started.md) — before you plant anything, first crop, troubleshooting
- [Core mechanics](/mechanics.md) — soils, seed stats, the growth formula
- [Breeding](/breeding.md) — the per-tick roll, mutations, pools, probability, the graveyard trick
- [Strategy](/strategy.md) — biomes, weeds, automation, tier reference
- [All crops](/crops.md) — 179 crops, grouped by tier, each with its recipe and 3D setup

> [!NOTE]
> This mirrors the interactive web guide at
> [crops-nh.netlify.app](https://crops-nh.netlify.app). The web **calculator** runs live
> probability math; this book covers the same mechanics offline, in-game. Every crop page shows
> its real seed icon.

<SubPages/>

