---
navigation:
  icon: 'cropsnh:cropSticks'
  title: Getting started
  parent: /index.md
  position: 50
  recommend: 80
  keywords:
    - tutorial
    - first crop
    - troubleshooting
---

# Getting Started

This isn't vanilla farming. If the setup is wrong, a crop either does nothing, grows painfully
slowly, or **gets sick and spreads sickness to its neighbours** — with no error message telling
you why. Four things decide whether a crop grows at all:

> [!WARNING]
> **1. Wrong soil = nothing grows.** Most food crops want **Farmland** (hoe the dirt). Ore and
> metal crops need **Stone**. Zomplant and Corpseplant need **TiC Graveyard Soil**. You can't
> plop a Ferrofern on farmland and wonder why it won't sprout.

> [!WARNING]
> **2. Some crops care what's TWO blocks down.** Ore berries won't grow without their matching
> ore block under the soil — iron ore under Ferrofern, a diamond block under Diareed. Stone on
> top alone isn't enough. Each crop page lists its block-under.

> [!IMPORTANT]
> **3. Biome matters more than you'd think.** Crops grow faster in biomes they like. Put a
> tier-6 ore crop in a biome it hates and it gets sick before it matures. If the
> [calculator](https://crops-nh.netlify.app/calculator.html) shows **SICK**, move the farm.

> [!IMPORTANT]
> **4. Set up a Crop Manager before you walk away.** It refills each stick's internal water,
> fertilizer, and WeedEx. That's separate from farmland hydration — farmland crops still need a
> water block within 4 blocks. Without WeedEx, weeds spawn in empty sticks and spread sickness
> to your parents.

Once that's sorted: place two crop sticks on valid soil, plant a parent in each, then
right-click one stick with **another crop stick** to double it into the **cross-crop stick**.
That middle stick is where new mutations appear.

<GameScene zoom={4} interactive={true}>
  <Block id="minecraft:dirt" x="0" y="0" z="0" />
  <Block id="minecraft:farmland" x="0" y="1" z="0" />
  <Block id="minecraft:dirt" x="0" y="0" z="-1" />
  <Block id="minecraft:farmland" x="0" y="1" z="-1" />
  <Block id="minecraft:dirt" x="0" y="0" z="1" />
  <Block id="minecraft:farmland" x="0" y="1" z="1" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crossCrop:1b}' x="0" y="2" z="0" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crop:{crop:"cropsnh:wheat",amount:1,gr:1b,ga:1b,re:1b,scan:1b},progress:1000}' x="0" y="2" z="-1" />
  <Block id="cropsnh:cropSticks" nbt='{id:"cropsnh:cropSticksTE",crop:{crop:"cropsnh:carrot",amount:1,gr:1b,ga:1b,re:1b,scan:1b},progress:1000}' x="0" y="2" z="1" />
  <BlockAnnotation pos="0 2 0" color="#80FFAA00" thickness="2" alwaysOnTop={true}>cross-crop</BlockAnnotation>
  <BlockAnnotation pos="0 2 -1" color="#8044DD66" thickness="2" alwaysOnTop={true}>parent</BlockAnnotation>
  <BlockAnnotation pos="0 2 1" color="#8044DD66" thickness="2" alwaysOnTop={true}>parent</BlockAnnotation>
</GameScene>

The center stick (amber highlight) is the empty **cross-crop** where new crops appear; the two flanking sticks (green) are the **parents** — both must be ≥ 80% grown, and can be the same species (breeds via pools) or different (can hit a deterministic recipe). Rotate and zoom with drag / scroll.

<details>
<summary>Step-by-step setup, with the common mistakes</summary>

**1. Check the soil requirement.** Each crop page shows the required soil (y−1) and block-under
(y−2). Prepare the ground *before* placing anything.

**2. Check your biome.** Enter your biome in the calculator and pick your crop. If the nutrient
score is too low for the tier, it shows SICK — move, or pick a lower-tier crop.

**3. Prepare the soil layers.** Farmland crops: till dirt, keep water within 4 blocks. Stone
crops: stone / cobble / stone brick. Ore berries: stone on top, ore block one layer below.

**4. Place crop sticks and plant.** Craft: 1 log + Saw + File → 2 GT Long Sticks; 4 Long Sticks
→ 4 crop sticks. Place on valid soil, right-click with a seed to plant, plant a second parent one
block away, then right-click a planted stick with another crop stick to create the cross-crop
between them.

**5. Add a Crop Manager and wait.** Stock it with water, fertilizer, and WeedEx. Parents must
reach **≥80% growth** before they breed; once mature they stay and breed indefinitely. The Crop
Manager does **not** auto-replant or remove seeds — that's always manual.

</details>

<details>
<summary>When it's not working — a troubleshooting checklist</summary>

> [!CAUTION]
> **Nothing happening — no growth at all.** Almost always nutrients are too low for the tier. On
> each failed tick the game rolls Resistance against the crop's bad luck: at R31 it sits dormant,
> at lower Resistance it can turn **sick** instead. Also check block-under.

**Got a "wrong soil" message when planting?** CropsNH refuses to plant on wrong soil and tells you
directly. So if planting *worked* but nothing grows, soil is **not** the problem — look at
nutrients and block-under.

**Farmland keeps turning back to dirt?** It needs a water source within 4 blocks. The Crop Manager
fills the stick's water storage but does **not** hydrate farmland.

**Crop turned <Color color="#5fd38d">green</Color> and stopped?** It's sick. Use a <ItemImage id="cropsnh:plantCure"/> **Plant Cure**,
then fix the root cause (nutrients or weed spread). Sickness alone never kills the plant.

> [!WARNING]
> **Weeds appearing.** Weeds spread **sickness** to adjacent crops via `transferDisease()` — they
> don't destroy crops directly. A crop deflects an incoming weed only with **WeedEx stocked AND
> Resistance ≥ Growth** (both, not WeedEx alone). Remove existing weeds by hand with the <ItemImage id="cropsnh:spade"/> **Spade**.
> An unchecked weed with nowhere to spread converts nearby dirt to grass — it can eat into your
> base's terrain.

</details>

